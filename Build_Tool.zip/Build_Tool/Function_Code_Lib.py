class Func_library:
    def Func_GetFaultStatus(self):
        func_code = """
# function must be named 'func'
def func(PD_Faultmem, faultname):
    for value in PD_Faultmem.values():
        if value['FaultName'] == faultname:
            return value['Status']
    return '0x00'
"""
        return func_code
    
    def Func_descryptKeyXpeng4bytes(self):
        func_code = """
# function must be named 'func'
def func(seed):
    key= [0,0,0,0]
    rb_dsa_CalculatedKey4Bytes_u32 = 0
    # Construct Seed_u32 from seed bytes
    Seed_u32 = ((int(seed[0],16) << 24) | (int(seed[1],16) << 16) | (int(seed[2],16) << 8) | int(seed[3],16))

    # XOR with constant
    Calibration_u32 = 0xE94A2291 ^ Seed_u32

    # Extract bytes from Calibration_u32
    Calibration0_u8 = (Calibration_u32 & 0xFF000000) >> 24
    Calibration1_u8 = (Calibration_u32 & 0x00FF0000) >> 16
    Calibration2_u8 = (Calibration_u32 & 0x0000FF00) >> 8
    Calibration3_u8 = (Calibration_u32 & 0x000000FF)

    # Calculate rb_dsa_CalculatedKey4Bytes_u32 using bitwise operations
    rb_dsa_CalculatedKey4Bytes_u32 |= (((Calibration3_u8 & 0x0F) << 4) | (Calibration3_u8 & 0xF0)) << 24
    rb_dsa_CalculatedKey4Bytes_u32 |= (((Calibration1_u8 & 0x0F) << 4) | ((Calibration0_u8 & 0xF0) >> 4)) << 16
    rb_dsa_CalculatedKey4Bytes_u32 |= ((Calibration1_u8 & 0xF0) | ((Calibration2_u8 & 0xF0) >> 4)) << 8
    rb_dsa_CalculatedKey4Bytes_u32 |= ((Calibration0_u8 & 0x0F) << 4) | (Calibration2_u8 & 0x0F)

    # Convert the 32-bit integer to 4 bytes
    key[0] = (rb_dsa_CalculatedKey4Bytes_u32 >> 24) & 0xFF
    key[1] = (rb_dsa_CalculatedKey4Bytes_u32 >> 16) & 0xFF
    key[2] = (rb_dsa_CalculatedKey4Bytes_u32 >> 8) & 0xFF
    key[3] = rb_dsa_CalculatedKey4Bytes_u32 & 0xFF
    result = " ".join(hex(k)[2:] for k in key)
    return result
"""
        return func_code
    
    def Func_Get_ReportFolder(self):
        func_code = """
from application.api.Api import Api
api = Api()
import os, sys
# function must be named 'func'
def func():
    reportpath=api.TestEnvironment.ExecutionInfo.LogFolder
    tracePath = reportpath+'.csv'
    counter = 1
    while os.path.exists(tracePath):
        tracePath = reportpath+ f"_{counter}.csv"
        counter += 1
    return tracePath
"""
        return func_code
    
    def Func_Get_ReportEDRFolder(self):
        func_code = """
from application.api.Api import Api
api = Api()
import os, sys
# function must be named 'func'
def func(crashType):
    reportpath = api.TestEnvironment.ExecutionInfo.LogFolder
    parts = reportpath.split(os.sep)
    parts[-1] = crashType
    newReportPath = os.sep.join(parts)
    
    # Check if the report path exists and add a number if it does
    counter = 1
    uniqueReportPath = newReportPath
    while os.path.exists(uniqueReportPath):
        uniqueReportPath = f"{newReportPath}_{counter}";
        counter += 1
    
    os.makedirs(uniqueReportPath)
    return uniqueReportPath
"""
        return func_code
    
    def Func_Change_DIDData_In_ByteBit_Position(self):
        func_code = """
# function must be named 'func'
def func(dataDID,byte, bit, bitValue):
    newData = dataDID.split()
    byteData = int(newData[byte - 1], 16)
    if bitValue == 1:
        new_byte_val = byteData | (1 << bit)
    elif bitValue == 0:
        new_byte_val = byteData & ~(1 << bit)
    else:
        # If bitValue is neither 0 nor 1, return original data unmodified
        return dataDID
    newData[byte - 1] = f"{new_byte_val:02X}"  # format as 2-digit uppercase hex
    return " ".join(newData)
"""
        return func_code
    
    def Func_EvaluateEdrCDData(self):
        func_code = """
# function must be named 'func'
def func(crashData,expectedData, position, length):
    crashData = crashData[9:].split()
    testState = None
    if type(expectedData) == list:
        for i in range(len(position)):
            if expectedData[i].lower() != ' '.join(crashData[position[i]:position[i]+ length[i]]):              
                testState = False
                return testState
        testState = True
    else:
        if expectedData.lower() == ' '.join(crashData[position:position+ length]):
            testState = True
        else:
            testState = False
    return testState
"""
        return func_code
    
    def Func_EvaluateEdrPDData(self):
        func_code = """
# function must be named 'func'
def func(detectedEDIDvalue,Expected_Data_EDID, position,EDIDIndex=0):
    expected_Data_EDID = Expected_Data_EDID[EDIDIndex]
    testState = None
    if isinstance(detectedEDIDvalue, list):
        if not isinstance(expected_Data_EDID, list):
            expected_Data_EDID = [expected_Data_EDID]
        for i in range(len(expected_Data_EDID)):
            if int(expected_Data_EDID[i],16) == int(detectedEDIDvalue[i+position[EDIDIndex]],16):
                testState = True
            else:
                Log = f"Failed in the EDID Data: {expected_Data_EDID[i]} of index = {EDIDIndex+1}"
                return Log
    else:
        if int(expected_Data_EDID,16) == int(detectedEDIDvalue,16):
            return True
        else:
            return False
    return testState
"""
        return func_code
    
    def get_func_code(self,func_name):
        # Find method base on string name
        method = getattr(self, func_name, None)
        if callable(method):
            return method()
        else:
            raise ValueError(f"Function '{func_name}' not found in Func_library.")