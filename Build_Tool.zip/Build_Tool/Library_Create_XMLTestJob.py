import xml.etree.ElementTree as ET
from xml.dom import minidom
import uuid



class ShareBase:
    mapping_Path_Job_List = []

class LibraryManager:
    def __init__(self):
        self.General_Lib = GENERAL_Library_GenXMLTestStep(self)
        self.Diag_Lib = DIAG_Library_GenXMLTestStep(self)
        self.Helpers_Lib = HELPER_GenXML_Library(self)
        self.Com_Lib = COM_Library_GenXMLTestStep(self)
        self.EDR_Lib = EDR_Library_GenXMLTestStep(self)

class HELPER_GenXML_Library(ShareBase):
    def __init__(self,LibraryManager:'LibraryManager'):
        self.LibraryManager:'LibraryManager' = LibraryManager

    @staticmethod
    def add_action_element(parent, text):
        """Add action element with multilanguage support"""
        action = ET.SubElement(parent, 'ACTION', {'xsi:type': 'I18NItem'})
        multil = ET.SubElement(action, 'MULTILANGDATA')
        
        elem = ET.SubElement(multil, 'ELEMENT', {'dkey': 'en_US'})
        dval = ET.SubElement(elem, 'DVALUE', {'xsi:type': 'string'})
        dval.text = text
        
        ET.SubElement(action, 'INITIAL-LANGUAGE', {'xsi:type': 'string'}).text = 'en_US'
    
    @staticmethod
    def add_parameter_assignment(param_assignments, param_name, value, expr_type, value_type='string'):
        """Add parameter assignment"""
        assignment = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': param_name})
        

        if expr_type == 'valueBaseExpression':
            dvalue = ET.SubElement(assignment, 'DVALUE', {'format-rev': '2', 'xsi:type': expr_type})
            value_elem = ET.SubElement(dvalue, 'VALUE', {'xsi:type': value_type})
            value_elem.text = value
        elif expr_type == 'varBaseExpression':
            dvalue = ET.SubElement(assignment, 'DVALUE', {'xsi:type': expr_type})
            name_elem = ET.SubElement(dvalue, 'NAME', {'xsi:type': value_type})
            name_elem.text = value
    
    @staticmethod
    def add_argument_assignment_convertHexStringToInt(parent, variable):
        dvalue_memory = ET.SubElement(parent, 'DVALUE', {'xsi:type': 'functionBaseExpression'})

        component = ET.SubElement(dvalue_memory, 'COMPONENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(component, 'NAME', {'xsi:type': 'string'}).text = 'int'

        arguments = ET.SubElement(dvalue_memory, 'ARGUMENTS')

        argument1 = ET.SubElement(arguments, 'ARGUMENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(argument1, 'NAME', {'xsi:type': 'string'}).text = variable

        argument2 = ET.SubElement(arguments, 'ARGUMENT', {'format-rev': '2', 'xsi:type': 'valueBaseExpression'})
        ET.SubElement(argument2, 'VALUE', {'xsi:type': 'integer'}).text = '16'

class GENERAL_Library_GenXMLTestStep(ShareBase):
    def __init__(self,LibraryManager:'LibraryManager'):
        self.LibraryManager:'LibraryManager' = LibraryManager
    
    def GenXML_PrepareNoFault(self,parent):
        """Generate GEN_PrepareNoFault test step"""
        test_step = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })

        ET.SubElement(test_step, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'GEN_PrepareNoFault'

        if 'GEN_PrepareNoFault' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('GEN_PrepareNoFault')

        ET.SubElement(test_step, 'PARAM-ASSIGNMENTS')
        ET.SubElement(test_step, 'ALTERNATIVE-MAPPING-SPACE', {'format-rev': '1', 'xsi:type': 'mappingSpace'})

    def GenXML_CheckECUMode(self,parent,var_expectedECUMode):
        """Generate PSDIAG_Read_Memory test step for ecuState"""
        test_step = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })

        ET.SubElement(test_step, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'PSDIAG_Read_Memory'

        if 'PSDIAG_Read_Memory' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('PSDIAG_Read_Memory')

        variable_refs = ET.SubElement(test_step, 'VARIABLE-REFS')
        variable_name = ET.SubElement(variable_refs, 'VARIABLE-NAME', {'dkey': 'R_result'})
        dvalue = ET.SubElement(variable_name, 'DVALUE', {'xsi:type': 'string'})
        dvalue.text = 'ecuState'

        param_assignments = ET.SubElement(test_step, 'PARAM-ASSIGNMENTS')

        assignment = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_labelOrAddress'})
        dvalue = ET.SubElement(assignment, 'DVALUE', {'format-rev': '2', 'xsi:type': 'valueBaseExpression'})
        value = ET.SubElement(dvalue, 'VALUE', {'xsi:type': 'string'})
        value.text = 'rb_bswm_ActualSystemMode_au16(0)'

        assignment = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_memoryContentsAsInteger'})
        dvalue = ET.SubElement(assignment, 'DVALUE', {'format-rev': '2', 'xsi:type': 'valueBaseExpression'})
        value = ET.SubElement(dvalue, 'VALUE', {'xsi:type': 'boolean'})
        value.text = 'True'

        ET.SubElement(test_step, 'ALTERNATIVE-MAPPING-SPACE', {'format-rev': '1', 'xsi:type': 'mappingSpace'})

        """Generate SwitchCase ecuState test step"""
        switch_step = ET.SubElement(parent, 'TESTSTEP', {
            'id': str(uuid.uuid4()),
            'name': 'TsSwitchCase',
            'xsi:type': 'utility-83517ac0-9f53-11dd-9c62-001b24fa84be'
        })

        # CASE 1: ecuState = "Normal", CASE-VALUE = 5
        case_node = ET.SubElement(switch_step, 'TESTSTEP', {
            'id': str(uuid.uuid4()),
            'xsi:type': 'caseNode'
        })

        ts_calc = ET.SubElement(case_node, 'TESTSTEP', {
            'format-rev': '3',
            'id': str(uuid.uuid4()),
            'name': 'TsCalculation',
            'xsi:type': 'utility-4115fa00-5f3c-11df-8a53-001c233b3528'
        })

        var_refs = ET.SubElement(ts_calc, 'VARIABLE-REFS')
        var_name = ET.SubElement(var_refs, 'VARIABLE-NAME', {'dkey': 'default'})
        dvalue = ET.SubElement(var_name, 'DVALUE', {'xsi:type': 'string'})
        dvalue.text = 'ecuState'

        formula = ET.SubElement(ts_calc, 'FORMULA', {'format-rev': '2', 'xsi:type': 'valueBaseExpression'})
        value = ET.SubElement(formula, 'VALUE', {'xsi:type': 'string'})
        value.text = 'Normal'

        case_value = ET.SubElement(case_node, 'CASE-VALUE', {'format-rev': '2', 'xsi:type': 'valueBaseExpression'})
        value = ET.SubElement(case_value, 'VALUE', {'xsi:type': 'integer'})
        value.text = '5'

        is_default = ET.SubElement(case_node, 'IS-DEFAULT', {'xsi:type': 'boolean'})
        is_default.text = 'False'

        # CASE 2: ecuState = "Idle", CASE-VALUE = 4
        case_node = ET.SubElement(switch_step, 'TESTSTEP', {
            'id': str(uuid.uuid4()),
            'xsi:type': 'caseNode'
        })

        ts_calc = ET.SubElement(case_node, 'TESTSTEP', {
            'format-rev': '3',
            'id': str(uuid.uuid4()),
            'name': 'TsCalculation',
            'xsi:type': 'utility-4115fa00-5f3c-11df-8a53-001c233b3528'
        })

        var_refs = ET.SubElement(ts_calc, 'VARIABLE-REFS')
        var_name = ET.SubElement(var_refs, 'VARIABLE-NAME', {'dkey': 'default'})
        dvalue = ET.SubElement(var_name, 'DVALUE', {'xsi:type': 'string'})
        dvalue.text = 'ecuState'

        formula = ET.SubElement(ts_calc, 'FORMULA', {'format-rev': '2', 'xsi:type': 'valueBaseExpression'})
        value = ET.SubElement(formula, 'VALUE', {'xsi:type': 'string'})
        value.text = 'Idle'

        case_value = ET.SubElement(case_node, 'CASE-VALUE', {'format-rev': '2', 'xsi:type': 'valueBaseExpression'})
        value = ET.SubElement(case_value, 'VALUE', {'xsi:type': 'integer'})
        value.text = '4'

        is_default = ET.SubElement(case_node, 'IS-DEFAULT', {'xsi:type': 'boolean'})
        is_default.text = 'False'

        # CASE 3: Default case CASE-VALUE = 0
        case_node = ET.SubElement(switch_step, 'TESTSTEP', {
            'id': str(uuid.uuid4()),
            'xsi:type': 'caseNode'
        })

        case_value = ET.SubElement(case_node, 'CASE-VALUE', {'format-rev': '2', 'xsi:type': 'valueBaseExpression'})
        value = ET.SubElement(case_value, 'VALUE', {'xsi:type': 'integer'})
        value.text = '0'

        is_default = ET.SubElement(case_node, 'IS-DEFAULT', {'xsi:type': 'boolean'})
        is_default.text = 'True'

        # SWITCH-VALUE ecuState
        switch_value = ET.SubElement(switch_step, 'SWITCH-VALUE', {'xsi:type': 'varBaseExpression'})
        name = ET.SubElement(switch_value, 'NAME', {'xsi:type': 'string'})
        name.text = 'ecuState'

        """Generate Evaluate ECU mode test step"""
        test_step = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '3',
            'id': str(uuid.uuid4()),
            'name': 'TsCalculation',
            'xsi:type': 'utility-4115fa00-5f3c-11df-8a53-001c233b3528'
        })

        formula = ET.SubElement(test_step, 'FORMULA', {'xsi:type': 'varBaseExpression'})
        name = ET.SubElement(formula, 'NAME', {'xsi:type': 'string'})
        name.text = 'ecuState'

        expectation = ET.SubElement(test_step, 'EXPECTATION-OPTION', {'xsi:type': 'timelessOption'})
        expr = ET.SubElement(expectation, 'EXPRESSION', {'xsi:type': 'builtStringExpression'})
        case_sensitive = ET.SubElement(expr, 'CASE-SENSITIVE', {'xsi:type': 'boolean'})
        case_sensitive.text = 'False'

        base_expr = ET.SubElement(expr, 'BASE-EXPRESSION', {'xsi:type': 'varBaseExpression'})
        name = ET.SubElement(base_expr, 'NAME', {'xsi:type': 'string'})
        name.text = var_expectedECUMode

        instance_name = ET.SubElement(test_step, 'INSTANCE-NAME', {'xsi:type': 'string'})
        instance_name.text = 'Evaluate the ECU mode'

    def GenXML_OthersTestStep(self, parent):
        """Generate TsComment test step for manual test job notice"""
        test_step = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'name': 'TsComment',
            'xsi:type': 'utility-1f4de951-4fef-11dc-969a-0013728784ee'
        })

        comment_expr = ET.SubElement(test_step, 'COMMENT-EXPRESSION', {
            'format-rev': '2',
            'xsi:type': 'valueBaseExpression'
        })
        value = ET.SubElement(comment_expr, 'VALUE', {'xsi:type': 'string'})
        value.text = 'Please add the test job manually to ensure it runs successfully, because this test step is not covered in the Library of the Automation Tool Generator'

        comment_verdict = ET.SubElement(test_step, 'COMMENT-VERDICT', {'xsi:type': 'string'})
        comment_verdict.text = 'ERROR'

    def GenXML_Set_SquibResistance(self, parent , varDevice , varValue):

        # Generate job DEVICE_SetSquibResistance package
        ts = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })

        ET.SubElement(ts, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'DEVICE_SetSquibResistance'
        if 'DEVICE_SetSquibResistance' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('DEVICE_SetSquibResistance')

        param_assignments = ET.SubElement(ts, 'PARAM-ASSIGNMENTS')

        param_assignments = ET.SubElement(ts, 'PARAM-ASSIGNMENTS')
        self.LibraryManager.Helpers_Lib.add_parameter_assignment(param_assignments, 'P_squibName',varDevice , 'varBaseExpression')
        self.LibraryManager.Helpers_Lib.add_parameter_assignment(param_assignments, 'P_value', varValue, 'varBaseExpression')

        ET.SubElement(ts, 'ALTERNATIVE-MAPPING-SPACE', {
            'format-rev': '1',
            'xsi:type': 'mappingSpace'
        })

    def GenXML_SetVoltage(self,parent, varVoltage):
        # Generate job LC12_SetVoltage
        ts = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })
        ET.SubElement(ts, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'LC12_SetVoltage'
        if 'LC12_SetVoltage' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('LC12_SetVoltage')

        param_assignments = ET.SubElement(ts, 'PARAM-ASSIGNMENTS')

        param_assignments = ET.SubElement(ts, 'PARAM-ASSIGNMENTS')
        self.LibraryManager.Helpers_Lib.add_parameter_assignment(param_assignments, 'P_Vbat',varVoltage , 'varBaseExpression')
        ET.SubElement(ts, 'ALTERNATIVE-MAPPING-SPACE', {
            'format-rev': '1',
            'xsi:type': 'mappingSpace'
        })


class DIAG_Library_GenXMLTestStep(ShareBase):

    def __init__(self,LibraryManager:'LibraryManager'):
        self.LibraryManager:'LibraryManager' = LibraryManager
  
    def GenXML_Set_Session(self,parent,var_name):
        switchCase_step = ET.SubElement(parent, 'TESTSTEP', {'id': str(uuid.uuid4()),'name': 'TsSwitchCase','xsi:type': 'utility-83517ac0-9f53-11dd-9c62-001b24fa84be'})

        case1 = ET.SubElement(switchCase_step, 'TESTSTEP', {'id': str(uuid.uuid4()),'xsi:type': 'caseNode'})

        self.GenXML_Diag_Request(
            parent=case1,
            request='10 01',
            response='50 01',
            mode='relax',
            use_variables=False                                                                                     
        )

        case1_value = ET.SubElement(case1, 'CASE-VALUE', {
            'format-rev': '2',
            'xsi:type': 'valueBaseExpression'
        })
        ET.SubElement(case1_value, 'VALUE', {'xsi:type': 'string'}).text = 'DefaultSession'

        ET.SubElement(case1, 'IS-DEFAULT', {'xsi:type': 'boolean'}).text = 'False'

        # === Case 2: ExtendedSession ===
        case2 = ET.SubElement(switchCase_step, 'TESTSTEP', {
            'id': str(uuid.uuid4()),
            'xsi:type': 'caseNode'
        })

        self.GenXML_Diag_Request(
            parent=case2,
            request='10 03',
            response='50 03',
            mode='relax',
            use_variables=False
        )

        case2_value = ET.SubElement(case2, 'CASE-VALUE', {
            'format-rev': '2',
            'xsi:type': 'valueBaseExpression'
        })
        ET.SubElement(case2_value, 'VALUE', {'xsi:type': 'string'}).text = 'ExtendedSession'

        ET.SubElement(case2, 'IS-DEFAULT', {'xsi:type': 'boolean'}).text = 'False'

        # === Case 3: Default (no inner test step) ===
        case3 = ET.SubElement(switchCase_step, 'TESTSTEP', {
            'id': str(uuid.uuid4()),
            'xsi:type': 'caseNode'
        })

        case3_value = ET.SubElement(case3, 'CASE-VALUE', {
            'format-rev': '2',
            'xsi:type': 'valueBaseExpression'
        })
        ET.SubElement(case3_value, 'VALUE', {'xsi:type': 'integer'}).text = '0'

        ET.SubElement(case3, 'IS-DEFAULT', {'xsi:type': 'boolean'}).text = 'True'

        # === SWITCH-VALUE ===
        switch_value = ET.SubElement(switchCase_step, 'SWITCH-VALUE', {
            'xsi:type': 'varBaseExpression'
        })
        ET.SubElement(switch_value, 'NAME', {'xsi:type': 'string'}).text = var_name
    
    def GenXML_Diag_Request_Binary_Add(self, parent, request_params: list, var_response, var_Result='',mode ='relax'):
        diag_step = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })

        ET.SubElement(diag_step, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'DIAG_Request'
        if 'DIAG_Request' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('DIAG_Request')

        if var_Result != '':
            # VARIABLE-REFS
            variable_refs = ET.SubElement(diag_step, "VARIABLE-REFS")
            var_name = ET.SubElement(variable_refs, "VARIABLE-NAME", {"dkey": "R_detected_response"})
            ET.SubElement(var_name, "DVALUE", {"xsi:type": "string"}).text = var_Result

        param_assignments = ET.SubElement(diag_step, 'PARAM-ASSIGNMENTS')

        # === P_Mode ===
        self.LibraryManager.Helpers_Lib.add_parameter_assignment(param_assignments, 'P_Mode', mode, 'valueBaseExpression')

        # === P_expected_response ===
        self.LibraryManager.Helpers_Lib.add_parameter_assignment(param_assignments, 'P_expected_response', var_response, 'varBaseExpression')

        # === P_request_data ===
        request_expr = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_request_data'})

        var_list = []
        for var in request_params:
            var_list.append(('varBaseExpression',var))
            var_list.append(('valueBaseExpression', ' '))
        if var_list:            
            var_list.pop()

        dvalue = self.build_binary_add_expression(var_list)
        request_expr.append(dvalue)

        # === ALTERNATIVE-MAPPING-SPACE ===
        ET.SubElement(diag_step, 'ALTERNATIVE-MAPPING-SPACE', {
            'format-rev': '1',
            'xsi:type': 'mappingSpace'
        })

    def GenXML_Diag_Request_Read_DID_Variable(self, parent, var_request,var_response, var_did, varDataLength, varData ):
        teststep = ET.SubElement(parent, 'TESTSTEP', {
        "id": str(uuid.uuid4()),
        "name": "TsIfThenElse",
        "xsi:type": "utility-3609c41e-4fef-11dc-899a-0013728784ee"
        })

        condition = ET.SubElement(teststep, "CONDITION", {"xsi:type": "compareOpBaseExpression"})
        ET.SubElement(condition, "NAME", {"xsi:type": "string"}).text = "!="
        fc = ET.SubElement(condition, "FIRST-COMPONENT", {"xsi:type": "varBaseExpression"})
        ET.SubElement(fc, "NAME", {"xsi:type": "string"}).text = varData
        sc = ET.SubElement(condition, "SECOND-COMPONENT", {"format-rev": "2", "xsi:type": "valueBaseExpression"})
        ET.SubElement(sc, "VALUE", {"xsi:type": "string"}).text = "NA"

        then_node = ET.SubElement(teststep, "THEN", {
            "id": str(uuid.uuid4()),
            "xsi:type": "ifThenElseNode"
        })

        self.LibraryManager.EDR_Lib.GenXML_Diag_Request_Binary_Add(then_node,[var_request,var_did],[var_response,varData], var_Result='responseData')

        # <ELSE>
        else_step = ET.SubElement(teststep, "ELSE", {
            "id": str(uuid.uuid4()),
            "xsi:type": "ifThenElseNode"
        })

        self.GenXML_Diag_Request_Binary_Add(else_step,[var_request,var_did],var_response, var_Result='responseData')

        teststep1 = ET.SubElement(parent, 'TESTSTEP', {
        "id": str(uuid.uuid4()),
        "name": "TsIfThenElse",
        "xsi:type": "utility-3609c41e-4fef-11dc-899a-0013728784ee"
        })

        condition = ET.SubElement(teststep1, "CONDITION", {"xsi:type": "compareOpBaseExpression"})
        ET.SubElement(condition, "NAME", {"xsi:type": "string"}).text = "!="
        fc = ET.SubElement(condition, "FIRST-COMPONENT", {"xsi:type": "varBaseExpression"})
        ET.SubElement(fc, "NAME", {"xsi:type": "string"}).text = varDataLength
        sc = ET.SubElement(condition, "SECOND-COMPONENT", {"format-rev": "2", "xsi:type": "valueBaseExpression"})
        ET.SubElement(sc, "VALUE", {"xsi:type": "string"}).text = "NA"

        then_node = ET.SubElement(teststep1, "THEN", {
            "id": str(uuid.uuid4()),
            "xsi:type": "ifThenElseNode"
        })

        teststep = ET.SubElement(then_node, 'TESTSTEP', {
        'format-rev': "3",
        'id': str(uuid.uuid4()),
        'name': "TsCalculation",
        'xsi:type': "utility-4115fa00-5f3c-11df-8a53-001c233b3528"
        })

        formula = ET.SubElement(teststep, 'FORMULA', {'xsi:type': 'functionBaseExpression'})
        component_len = ET.SubElement(formula, 'COMPONENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(component_len, 'NAME', {'xsi:type': 'string'}).text = 'len'

        arguments = ET.SubElement(formula, 'ARGUMENTS')
        argument = ET.SubElement(arguments, 'ARGUMENT', {'xsi:type': 'functionBaseExpression'})
        arg_component = ET.SubElement(argument, 'COMPONENT', {'xsi:type': 'attributeBaseExpression'})

        slice_expr = ET.SubElement(arg_component, 'COMPONENT', {'xsi:type': 'sliceBaseExpression'})
        base_var = ET.SubElement(slice_expr, 'COMPONENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(base_var, 'NAME', {'xsi:type': 'string'}).text = 'responseData'

        start_expr = ET.SubElement(slice_expr, 'START', {'format-rev': '2', 'xsi:type': 'valueBaseExpression'})
        ET.SubElement(start_expr, 'VALUE', {'xsi:type': 'integer'}).text = '9'

        ET.SubElement(arg_component, 'ATTR-NAME', {'xsi:type': 'string'}).text = 'split'

        expectation = ET.SubElement(teststep, 'EXPECTATION-OPTION', {'xsi:type': 'timelessOption'})
        expression = ET.SubElement(expectation, 'EXPRESSION', {'xsi:type': 'builtNumericExpression'})
        ET.SubElement(expression, 'RELATION', {'xsi:type': 'string'}).text = '=='

        val_expr = ET.SubElement(expression, 'VALUE', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(val_expr, 'NAME', {'xsi:type': 'string'}).text = varDataLength

        ET.SubElement(teststep, 'INSTANCE-NAME', {'xsi:type': 'string'}).text = 'Evaluate the data length of the response'

        # ELSE block (empty)
        ET.SubElement(teststep1, 'ELSE', {
            'id': str(uuid.uuid4()),
            'xsi:type': 'ifThenElseNode'
        })

    def GenXML_Diag_Request_Write_DID_Variable(self, parent, var_request,var_response, var_did,var_data ):
        self.GenXML_Diag_Request_Binary_Add(parent,[var_request,var_did,var_data],var_response)

    def build_binary_add_expression(self, parts):
        """
        Builds the required nested XML structure for BINARY_ADD, matching your specification.
        - Only the outermost uses <DVALUE>
        - All inner nodes are nested by adding <NAME>, <FIRST-COMPONENT>, <SECOND-COMPONENT> directly.
        """
        def make_component(tag, xsi_type, value):
            attrib={}
            if xsi_type == 'valueBaseExpression':
                attrib['format-rev'] = '2'
            attrib['xsi:type'] = xsi_type
            comp = ET.Element(tag, attrib)
            if xsi_type == 'valueBaseExpression':
                ET.SubElement(comp, 'VALUE', {'xsi:type': 'string'}).text = value
            else:
                ET.SubElement(comp, 'NAME', {'xsi:type': 'string'}).text = value
            return comp

         #Base level: combine parts[0] and parts[1]
        node = ET.Element('NAME', {'xsi:type': 'string'})
        node.text = 'BINARY_ADD'
        parent = ET.Element('dummy')  # temporary root
        parent.append(node)
        parent.append(make_component('FIRST-COMPONENT', parts[0][0], parts[0][1]))
        parent.append(make_component('SECOND-COMPONENT', parts[1][0], parts[1][1]))

        # Now, for each next part, nest one level up
        for i in range(2, len(parts)):
            new_parent = ET.Element('dummy')
            node = ET.Element('NAME', {'xsi:type': 'string'})
            node.text = 'BINARY_ADD'
            new_parent.append(node)
            fc = ET.Element('FIRST-COMPONENT', {'xsi:type': 'binaryOpBaseExpression'})
            # Move all from parent into fc
            for child in list(parent):
                fc.append(child)
            new_parent.append(fc)
            new_parent.append(make_component('SECOND-COMPONENT', parts[i][0], parts[i][1]))
            parent = new_parent

        # The outermost should be <DVALUE>
        dvalue = ET.Element('DVALUE', {'xsi:type': 'binaryOpBaseExpression'})
        for child in parent:
            dvalue.append(child)
        return dvalue
                               
    def GenXML_Diag_Request(self,parent,request, response, mode='relax', use_variables=True):
        """Add diagnostic request step"""
        diag_step = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '1', 'id': str(uuid.uuid4()), 'xsi:type': 'tsPackageCall'
        })
        
        ET.SubElement(diag_step, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'DIAG_Request'
        if 'DIAG_Request' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('DIAG_Request')
        
        param_assignments = ET.SubElement(diag_step, 'PARAM-ASSIGNMENTS')
        
        # Mode parameter
        self.LibraryManager.Helpers_Lib.add_parameter_assignment(param_assignments, 'P_Mode', mode, 'valueBaseExpression')
        
        # Request and response parameters
        expr_type = 'varBaseExpression' if use_variables else 'valueBaseExpression'
        self.LibraryManager.Helpers_Lib.add_parameter_assignment(param_assignments, 'P_request_data', request, expr_type)
        self.LibraryManager.Helpers_Lib.add_parameter_assignment(param_assignments, 'P_expected_response', response, expr_type)
        
        ET.SubElement(diag_step, 'ALTERNATIVE-MAPPING-SPACE', {'format-rev': '1', 'xsi:type': 'mappingSpace'})
    
    def GenXML_Enter_Extended_Session(self,parent, mode='relax', use_variables=False):
        """Add diagnostic request step"""
        diag_step = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '1', 'id': str(uuid.uuid4()), 'xsi:type': 'tsPackageCall'
        })
        
        ET.SubElement(diag_step, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'DIAG_Request'
        if 'DIAG_Request' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('DIAG_Request')
        
        param_assignments = ET.SubElement(diag_step, 'PARAM-ASSIGNMENTS')
        
        # Mode parameter
        self.LibraryManager.Helpers_Lib.add_parameter_assignment(param_assignments, 'P_Mode', mode, 'valueBaseExpression')
        
        # Request and response parameters
        expr_type = 'varBaseExpression' if use_variables else 'valueBaseExpression'
        self.LibraryManager.Helpers_Lib.add_parameter_assignment(param_assignments, 'P_request_data', "10 03", expr_type)
        self.LibraryManager.Helpers_Lib.add_parameter_assignment(param_assignments, 'P_expected_response', "50 03", expr_type)
        
        ET.SubElement(diag_step, 'ALTERNATIVE-MAPPING-SPACE', {'format-rev': '1', 'xsi:type': 'mappingSpace'})
    
    def GenXML_Enter_Default_Session(self,parent, mode='relax', use_variables=False):
        """Add diagnostic request step"""
        diag_step = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '1', 'id': str(uuid.uuid4()), 'xsi:type': 'tsPackageCall'
        })
        
        ET.SubElement(diag_step, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'DIAG_Request'
        if 'DIAG_Request' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('DIAG_Request')
        
        param_assignments = ET.SubElement(diag_step, 'PARAM-ASSIGNMENTS')
        
        # Mode parameter
        self.LibraryManager.Helpers_Lib.add_parameter_assignment(param_assignments, 'P_Mode', mode, 'valueBaseExpression')
        
        # Request and response parameters
        expr_type = 'varBaseExpression' if use_variables else 'valueBaseExpression'
        self.LibraryManager.Helpers_Lib.add_parameter_assignment(param_assignments, 'P_request_data', "10 01", expr_type)
        self.LibraryManager.Helpers_Lib.add_parameter_assignment(param_assignments, 'P_expected_response', "50 01", expr_type)
        
        ET.SubElement(diag_step, 'ALTERNATIVE-MAPPING-SPACE', {'format-rev': '1', 'xsi:type': 'mappingSpace'})
    
    def GenXML_GEN_wait_ms(self, parent,wait_time='500'):
        """Generate a GEN_wait_ms test step"""
        wait_step = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })

        ET.SubElement(wait_step, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'GEN_wait_ms'
        if 'GEN_wait_ms' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('GEN_wait_ms')

        param_assignments = ET.SubElement(wait_step, 'PARAM-ASSIGNMENTS')
        self.LibraryManager.Helpers_Lib.add_parameter_assignment(param_assignments, 'P_waitTime', wait_time, 'valueBaseExpression', value_type='integer')

        ET.SubElement(wait_step, 'ALTERNATIVE-MAPPING-SPACE', {
            'format-rev': '1',
            'xsi:type': 'mappingSpace'
        })

    def GenXML_GEN_wait_ms_var(self, parent,wait_time='500'):
        """Generate a GEN_wait_ms test step"""
        wait_step = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })

        ET.SubElement(wait_step, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'GEN_wait_ms'
        if 'GEN_wait_ms' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('GEN_wait_ms')

        param_assignments = ET.SubElement(wait_step, 'PARAM-ASSIGNMENTS')
        self.LibraryManager.Helpers_Lib.add_parameter_assignment(param_assignments, 'P_waitTime', wait_time, 'varBaseExpression', value_type='string')

        ET.SubElement(wait_step, 'ALTERNATIVE-MAPPING-SPACE', {
            'format-rev': '1',
            'xsi:type': 'mappingSpace'
        })
    
    def GenXML_PSDIAG_Reset_Ecu(self, parent, reset_type='HARDRESET'):
        teststep = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })

        # Add MAPPING-REF
        ET.SubElement(teststep, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'PSDIAG_Reset_Ecu'
        if 'PSDIAG_Reset_Ecu' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('PSDIAG_Reset_Ecu')

        # Add PARAM-ASSIGNMENTS
        param_assignments = ET.SubElement(teststep, 'PARAM-ASSIGNMENTS')
        assignment = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_resetType'})
        dvalue = ET.SubElement(assignment, 'DVALUE', {'format-rev': '2', 'xsi:type': 'valueBaseExpression'})
        ET.SubElement(dvalue, 'VALUE', {'xsi:type': 'string'}).text = reset_type

        # Add ALTERNATIVE-MAPPING-SPACE
        ET.SubElement(teststep, 'ALTERNATIVE-MAPPING-SPACE', {
            'format-rev': '1',
            'xsi:type': 'mappingSpace'
        })
    
    def GenXML_Wait_ECU_NormalDriving(self, parent):
        """Generate GEN_WaitECUReady test step"""
        teststep = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })

        # Add MAPPING-REF
        ET.SubElement(teststep, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'GEN_WaitECUReady'
        # Register mapping path job
        if 'GEN_WaitECUReady' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('GEN_WaitECUReady')

        # Empty PARAM-ASSIGNMENTS
        ET.SubElement(teststep, 'PARAM-ASSIGNMENTS')

        # Add ALTERNATIVE-MAPPING-SPACE
        ET.SubElement(teststep, 'ALTERNATIVE-MAPPING-SPACE', {
            'format-rev': '1',
            'xsi:type': 'mappingSpace'
        })
    
    def GenXML_LC12_ECU_Off(self, parent):
        step = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })
        ET.SubElement(step, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'LC12_ECU_Off'
        if 'LC12_ECU_Off' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('LC12_ECU_Off')
        ET.SubElement(step, 'PARAM-ASSIGNMENTS')
        ET.SubElement(step, 'ALTERNATIVE-MAPPING-SPACE', {'format-rev': '1', 'xsi:type': 'mappingSpace'})

    def GenXML_LC12_ECU_On(self, parent, voltage = 13):
        step = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })
        ET.SubElement(step, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'LC12_ECU_On'
        if 'LC12_ECU_On' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('LC12_ECU_On')

        param = ET.SubElement(step, 'PARAM-ASSIGNMENTS')
        assignment = ET.SubElement(param, 'ASSIGNMENT', {'dkey': 'P_Voltage'})
        dval = ET.SubElement(assignment, 'DVALUE', {'format-rev': '2', 'xsi:type': 'valueBaseExpression'})
        ET.SubElement(dval, 'VALUE', {'xsi:type': 'integer'}).text = str(voltage)

        ET.SubElement(step, 'ALTERNATIVE-MAPPING-SPACE', {'format-rev': '1', 'xsi:type': 'mappingSpace'})

    def GenXML_DSM_getSecurityAccessXpeng(self, parent):
        step = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'})
        ET.SubElement(step, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'DSM_getSecurityAccessXpeng'
        if 'DSM_getSecurityAccessXpeng' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('DSM_getSecurityAccessXpeng')
        ET.SubElement(step, 'PARAM-ASSIGNMENTS')
        ET.SubElement(step, 'ALTERNATIVE-MAPPING-SPACE', {'format-rev': '1', 'xsi:type': 'mappingSpace'})

    def GenXML_Start_Tester_present(self,parent):
        """Generate a DIAG_Start_CyclicTesterPresent test step"""
        step = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })

        ET.SubElement(step, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'DIAG_Start_CyclicTesterPresent'

        if 'DIAG_Start_CyclicTesterPresent' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('DIAG_Start_CyclicTesterPresent')

        ET.SubElement(step, 'PARAM-ASSIGNMENTS')
        ET.SubElement(step, 'ALTERNATIVE-MAPPING-SPACE', {
            'format-rev': '1',
            'xsi:type': 'mappingSpace'
        })

    def GenXML_Stop_Tester_present(self,parent):
        """Generate a DIAG_Start_CyclicTesterPresent test step"""
        step = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })

        ET.SubElement(step, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'DIAG_Stop_CyclicTesterPresent'

        if 'DIAG_Stop_CyclicTesterPresent' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('DIAG_Stop_CyclicTesterPresent')

        ET.SubElement(step, 'PARAM-ASSIGNMENTS')
        ET.SubElement(step, 'ALTERNATIVE-MAPPING-SPACE', {
            'format-rev': '1',
            'xsi:type': 'mappingSpace'
        })
    
    def GenXML_Set_AddressingMode(self, parent, addressing_mode="Addressing_Mode"):
        """Generate a DIAG_Set_AddressingMode test step"""
        step = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })

        ET.SubElement(step, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'DIAG_Set_AddressingMode'

        if 'DIAG_Set_AddressingMode' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('DIAG_Set_AddressingMode')

        # PARAM-ASSIGNMENTS
        param_assignments = ET.SubElement(step, 'PARAM-ASSIGNMENTS')
        self.LibraryManager.Helpers_Lib.add_parameter_assignment(
            param_assignments,
            param_name='P_mode',
            value=addressing_mode,
            expr_type='varBaseExpression',
            value_type='string'
        )

        # ALTERNATIVE-MAPPING-SPACE
        ET.SubElement(step, 'ALTERNATIVE-MAPPING-SPACE', {
            'format-rev': '1',
            'xsi:type': 'mappingSpace'
        })

    def GenXML_Send_request_invalid_key(self, parent, var_request="Request",expected_response="NRC_Response", var_key="key"):
        self.GenXML_Diag_Request_Binary_Add(parent,[var_request,var_key],expected_response, mode="strict")
    
    def GenXML_Diag_Request_Seed(self,parent,request, response, mode='relax', use_variables=True):
        """Add diagnostic request step"""
        diag_step = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '1', 'id': str(uuid.uuid4()), 'xsi:type': 'tsPackageCall'
        })
        
        ET.SubElement(diag_step, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'DIAG_Request'
        if 'DIAG_Request' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('DIAG_Request')
        # <VARIABLE-REFS>
        variable_refs = ET.SubElement(diag_step, 'VARIABLE-REFS')
        variable_name = ET.SubElement(variable_refs, 'VARIABLE-NAME', {'dkey': 'R_detected_response'})
        ET.SubElement(variable_name, 'DVALUE', {'xsi:type': 'string'}).text = 'Seed'
        
        param_assignments = ET.SubElement(diag_step, 'PARAM-ASSIGNMENTS')
        
        # Mode parameter
        self.LibraryManager.Helpers_Lib.add_parameter_assignment(param_assignments, 'P_Mode', mode, 'valueBaseExpression')
        
        # Request and response parameters
        expr_type = 'varBaseExpression' if use_variables else 'valueBaseExpression'
        self.LibraryManager.Helpers_Lib.add_parameter_assignment(param_assignments, 'P_request_data', request, expr_type)
        self.LibraryManager.Helpers_Lib.add_parameter_assignment(param_assignments, 'P_expected_response', response, expr_type)
        
        ET.SubElement(diag_step, 'ALTERNATIVE-MAPPING-SPACE', {'format-rev': '1', 'xsi:type': 'mappingSpace'})
    
    def GenXML_Diag_Request_Key_Split_Seed(self,parent):
        req_key = ET.SubElement(parent, 'TESTSTEP', {
        'format-rev': '3',
        'id': str(uuid.uuid4()),
        'name': 'TsCalculation',
        'xsi:type': 'utility-4115fa00-5f3c-11df-8a53-001c233b3528'
        })

        # <VARIABLE-REFS>
        variable_refs = ET.SubElement(req_key, 'VARIABLE-REFS')
        var_name = ET.SubElement(variable_refs, 'VARIABLE-NAME', {'dkey': 'default'})
        ET.SubElement(var_name, 'DVALUE', {'xsi:type': 'string'}).text = 'tempData'

        # <FORMULA>
        formula = ET.SubElement(req_key, 'FORMULA', {'xsi:type': 'functionBaseExpression'})
        comp_attr = ET.SubElement(formula, 'COMPONENT', {'xsi:type': 'attributeBaseExpression'})
        comp_var = ET.SubElement(comp_attr, 'COMPONENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(comp_var, 'NAME', {'xsi:type': 'string'}).text = 'Seed'
        ET.SubElement(comp_attr, 'ATTR-NAME', {'xsi:type': 'string'}).text = 'split'

        # <ARGUMENTS>
        args = ET.SubElement(formula, 'ARGUMENTS')
        arg = ET.SubElement(args, 'ARGUMENT', {'format-rev': '2', 'xsi:type': 'valueBaseExpression'})
        ET.SubElement(arg, 'VALUE', {'xsi:type': 'string'}).text = ' '

        # <INSTANCE-NAME>
        ET.SubElement(req_key, 'INSTANCE-NAME', {'xsi:type': 'string'}).text = 'split the response to list'
    
    def GenXML_Diag_Request_Key_Get_Seed(self,parent):
        get_seed = ET.SubElement(parent, 'TESTSTEP', {
        'format-rev': '3',
        'id': str(uuid.uuid4()),
        'name': 'TsCalculation',
        'xsi:type': 'utility-4115fa00-5f3c-11df-8a53-001c233b3528'
        })

        variable_refs = ET.SubElement(get_seed, 'VARIABLE-REFS')
        var_name = ET.SubElement(variable_refs, 'VARIABLE-NAME', {'dkey': 'default'})
        ET.SubElement(var_name, 'DVALUE', {'xsi:type': 'string'}).text = 'seedData'

        formula = ET.SubElement(get_seed, 'FORMULA', {'xsi:type': 'sliceBaseExpression'})
        comp = ET.SubElement(formula, 'COMPONENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(comp, 'NAME', {'xsi:type': 'string'}).text = 'tempData'

        start = ET.SubElement(formula, 'START', {'format-rev': '2', 'xsi:type': 'valueBaseExpression'})
        ET.SubElement(start, 'VALUE', {'xsi:type': 'integer'}).text = str(2)

    def GenXML_Diag_Request_Key_Calculate_Key(self,parent):
        calc_step = ET.SubElement(parent, 'TESTSTEP', {
        'format-rev': '3',
        'id': str(uuid.uuid4()),
        'name': 'TsCalculation',
        'xsi:type': 'utility-4115fa00-5f3c-11df-8a53-001c233b3528'
        })

        variable_refs = ET.SubElement(calc_step, 'VARIABLE-REFS')
        var_name = ET.SubElement(variable_refs, 'VARIABLE-NAME', {'dkey': 'default'})
        ET.SubElement(var_name, 'DVALUE', {'xsi:type': 'string'}).text = 'Valid_Key'

        formula = ET.SubElement(calc_step, 'FORMULA', {'xsi:type': 'functionBaseExpression'})
        comp = ET.SubElement(formula, 'COMPONENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(comp, 'NAME', {'xsi:type': 'string'}).text = 'Func_descryptKeyXpeng4bytes'

        args = ET.SubElement(formula, 'ARGUMENTS')
        arg = ET.SubElement(args, 'ARGUMENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(arg, 'NAME', {'xsi:type': 'string'}).text = 'seedData'

        ET.SubElement(calc_step, 'INSTANCE-NAME', {'xsi:type': 'string'}).text = 'Descrypt for security key'

    def GenXML_Diag_Request_Key_With_ValidKey(self,parent,var_request, var_response):
        diag_step = ET.SubElement(parent, 'TESTSTEP', {
        'format-rev': '1',
        'id': str(uuid.uuid4()),
        'xsi:type': 'tsPackageCall'
        })

        ET.SubElement(diag_step, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'DIAG_Request'
        if 'DIAG_Request' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('DIAG_Request')

        param_assignments = ET.SubElement(diag_step, 'PARAM-ASSIGNMENTS')
        self.LibraryManager.Helpers_Lib.add_parameter_assignment(param_assignments, 'P_Mode', 'relax', 'valueBaseExpression')
        self.LibraryManager.Helpers_Lib.add_parameter_assignment(param_assignments, 'P_expected_response', var_response, 'varBaseExpression')

        assign = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_request_data'})
        dvalue = self.build_binary_add_expression([
            ('varBaseExpression', var_request),
            ('valueBaseExpression', ' '),
            ('varBaseExpression', 'Valid_Key')
        ])
        assign.append(dvalue)

        ET.SubElement(diag_step, 'ALTERNATIVE-MAPPING-SPACE', {
            'format-rev': '1',
            'xsi:type': 'mappingSpace'
        })

    def GenXML_Diag_Request_Read_DID(self, parent, var_request, var_did ,var_response):
        self.GenXML_Diag_Request_Binary_Add(parent,[var_request,var_did],var_response)

    def GenXML_DEVICE_SetDeviceState(self, parent, var_device='Device', var_state='State'):
        """Generate a TESTSTEP for DEVICE_SetDeviceState with P_deviceName and P_state as varBaseExpression"""
        step = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })

        ET.SubElement(step, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'DEVICE_SetDeviceState'
        if 'DEVICE_SetDeviceState' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('DEVICE_SetDeviceState')

        param_assignments = ET.SubElement(step, 'PARAM-ASSIGNMENTS')

        # === P_deviceName ===
        self.LibraryManager.Helpers_Lib.add_parameter_assignment(param_assignments, 'P_deviceName', var_device, 'varBaseExpression')

        # === P_state ===
        self.LibraryManager.Helpers_Lib.add_parameter_assignment(param_assignments, 'P_state', var_state, 'varBaseExpression')

        # === ALTERNATIVE-MAPPING-SPACE ===
        ET.SubElement(step, 'ALTERNATIVE-MAPPING-SPACE', {
            'format-rev': '1',
            'xsi:type': 'mappingSpace'
        })
    
    def GenXML_DEVICE_ResetDeviceState(self, parent, var_device='Device', var_state='State'):
        """Generate a TESTSTEP for DEVICE_ResetDeviceState with P_deviceName and P_state as varBaseExpression"""
        step = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })

        ET.SubElement(step, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'DEVICE_ResetDeviceState'
        if 'DEVICE_ResetDeviceState' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('DEVICE_ResetDeviceState')

        param_assignments = ET.SubElement(step, 'PARAM-ASSIGNMENTS')

        # === P_deviceName ===
        self.LibraryManager.Helpers_Lib.add_parameter_assignment(param_assignments, 'P_deviceName', var_device, 'varBaseExpression')

        # === P_state ===
        self.LibraryManager.Helpers_Lib.add_parameter_assignment(param_assignments, 'P_state', var_state, 'varBaseExpression')

        # === ALTERNATIVE-MAPPING-SPACE ===
        ET.SubElement(step, 'ALTERNATIVE-MAPPING-SPACE', {
            'format-rev': '1',
            'xsi:type': 'mappingSpace'
        })

    def GenXML_PSDIAG_Get_State_Device(self, parent, var_device ='Device', var_expect_state='Expect_State'):
        ############# Generate job get device configuration to get state of behivior of static bit ######################
        teststep = ET.SubElement(parent, "TESTSTEP", {
        "format-rev": "1",
        "id": str(uuid.uuid4()),
        "xsi:type": "tsPackageCall"
        })

        # MAPPING-REF
        ET.SubElement(teststep, "MAPPING-REF", {"xsi:type": "string"}).text = "PSDIAG_Get_Device_Configuration"
        if "PSDIAG_Get_Device_Configuration" not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append("PSDIAG_Get_Device_Configuration")

        # VARIABLE-REFS
        var_refs = ET.SubElement(teststep, "VARIABLE-REFS")
        var_name = ET.SubElement(var_refs, "VARIABLE-NAME", {"dkey": "R_result"})
        dvalue = ET.SubElement(var_name, "DVALUE", {"xsi:type": "string"})
        dvalue.text = 'stateDevice'

        # PARAM-ASSIGNMENTS
        param_assignments = ET.SubElement(teststep, "PARAM-ASSIGNMENTS")

        # Assignment for P_devices
        assignment = ET.SubElement(param_assignments, "ASSIGNMENT", {"dkey": "P_devices"})
        dvalue = ET.SubElement(assignment, "DVALUE", {"xsi:type": "listOrTupleBaseExpression"})

        ET.SubElement(dvalue, "IS-LIST", {"xsi:type": "boolean"}).text = "True"

        expr_list = ET.SubElement(dvalue, "EXPRESSION-LIST")
        base_expr = ET.SubElement(expr_list, "BASE-EXPRESSION", {"xsi:type": "varBaseExpression"})
        ET.SubElement(base_expr, "NAME", {"xsi:type": "string"}).text = var_device

        # ALTERNATIVE-MAPPING-SPACE
        ET.SubElement(teststep, "ALTERNATIVE-MAPPING-SPACE", {
            "format-rev": "1",
            "xsi:type": "mappingSpace"
        })

        ############ Generate the calculation convert the expected state to boolean #################
        teststep = ET.SubElement(parent, 'TESTSTEP', {
        'format-rev': '3',
        'id': str(uuid.uuid4()),
        'name': 'TsCalculation',
        'xsi:type': 'utility-4115fa00-5f3c-11df-8a53-001c233b3528'
        })

        variable_refs = ET.SubElement(teststep, 'VARIABLE-REFS')
        var_name = ET.SubElement(variable_refs, 'VARIABLE-NAME', {'dkey': 'default'})
        dval = ET.SubElement(var_name, 'DVALUE', {'xsi:type': 'string'})
        dval.text = 'ExpectedState'

        formula = ET.SubElement(teststep, 'FORMULA', {'xsi:type': 'unaryOpBaseExpression'})
        ET.SubElement(formula, 'NAME', {'xsi:type': 'string'}).text = 'UNARY_NOT'

        component_function = ET.SubElement(formula, 'COMPONENT', {'xsi:type': 'functionBaseExpression'})
        component_attr = ET.SubElement(component_function, 'COMPONENT', {'xsi:type': 'attributeBaseExpression'})
        component_var = ET.SubElement(component_attr, 'COMPONENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(component_var, 'NAME', {'xsi:type': 'string'}).text = var_expect_state
        ET.SubElement(component_attr, 'ATTR-NAME', {'xsi:type': 'string'}).text = 'startswith'

        arguments = ET.SubElement(component_function, 'ARGUMENTS')
        argument = ET.SubElement(arguments, 'ARGUMENT', {'format-rev': '2', 'xsi:type': 'valueBaseExpression'})
        ET.SubElement(argument, 'VALUE', {'xsi:type': 'string'}).text = 'startswith'

        ET.SubElement(teststep, 'INSTANCE-NAME', {'xsi:type': 'string'}).text = 'Convert the expected state to boolean'
        
        ################ Generate calculation to remove prefix 'de' ####################### 
        teststep = ET.SubElement(parent, 'TESTSTEP', {
        'format-rev': '3',
        'id': str(uuid.uuid4()),
        'name': 'TsCalculation',
        'xsi:type': 'utility-4115fa00-5f3c-11df-8a53-001c233b3528'
        })

        # VARIABLE-REFS
        variable_refs = ET.SubElement(teststep, 'VARIABLE-REFS')
        var_name = ET.SubElement(variable_refs, 'VARIABLE-NAME', {'dkey': 'default'})
        dval = ET.SubElement(var_name, 'DVALUE', {'xsi:type': 'string'})
        dval.text = "stateType"

        # FORMULA
        formula = ET.SubElement(teststep, 'FORMULA', {'xsi:type': 'functionBaseExpression'})
        component_attr = ET.SubElement(formula, 'COMPONENT', {'xsi:type': 'attributeBaseExpression'})
        component_var = ET.SubElement(component_attr, 'COMPONENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(component_var, 'NAME', {'xsi:type': 'string'}).text = var_expect_state
        ET.SubElement(component_attr, 'ATTR-NAME', {'xsi:type': 'string'}).text = 'removeprefix'

        arguments = ET.SubElement(formula, 'ARGUMENTS')
        argument = ET.SubElement(arguments, 'ARGUMENT', {'format-rev': '2', 'xsi:type': 'valueBaseExpression'})
        ET.SubElement(argument, 'VALUE', {'xsi:type': 'string'}).text = 'de'

        # INSTANCE NAME
        ET.SubElement(teststep, 'INSTANCE-NAME', {'xsi:type': 'string'}).text = 'Remove prefix "de"'

        ############## Generate calculation to uppercase first letter ####################### 
        teststep = ET.SubElement(parent, 'TESTSTEP', {
        'format-rev': '3',
        'id': str(uuid.uuid4()),
        'name': 'TsCalculation',
        'xsi:type': 'utility-4115fa00-5f3c-11df-8a53-001c233b3528'
        })

        # VARIABLE-REFS
        variable_refs = ET.SubElement(teststep, 'VARIABLE-REFS')
        var_name = ET.SubElement(variable_refs, 'VARIABLE-NAME', {'dkey': 'default'})
        dval = ET.SubElement(var_name, 'DVALUE', {'xsi:type': 'string'})
        dval.text = 'stateType'

        # FORMULA
        formula = ET.SubElement(teststep, 'FORMULA', {'xsi:type': 'functionBaseExpression'})
        component_attr = ET.SubElement(formula, 'COMPONENT', {'xsi:type': 'attributeBaseExpression'})
        component_var = ET.SubElement(component_attr, 'COMPONENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(component_var, 'NAME', {'xsi:type': 'string'}).text = 'stateType'
        ET.SubElement(component_attr, 'ATTR-NAME', {'xsi:type': 'string'}).text = 'capitalize'

        # INSTANCE NAME
        ET.SubElement(teststep, 'INSTANCE-NAME', {'xsi:type': 'string'}).text = 'First letter uppercase'

        ################ Generate calculation to evaluate state of static bit ####################### 
        teststep = ET.SubElement(parent, "TESTSTEP", {
        "format-rev": "3",
        "id": str(uuid.uuid4()),
        "name": "TsCalculation",
        "xsi:type": "utility-4115fa00-5f3c-11df-8a53-001c233b3528"
        })

        # === FORMULA ===
        formula = ET.SubElement(teststep, "FORMULA", {"xsi:type": "binaryOpBaseExpression"})
        ET.SubElement(formula, "NAME", {"xsi:type": "string"}).text = "BINARY_SUBSCR"

        # FIRST-COMPONENT (stateBit[Static_Bit])
        first_level = ET.SubElement(formula, "FIRST-COMPONENT", {"xsi:type": "binaryOpBaseExpression"})
        ET.SubElement(first_level, "NAME", {"xsi:type": "string"}).text = "BINARY_SUBSCR"

        fc_1 = ET.SubElement(first_level, "FIRST-COMPONENT", {"xsi:type": "varBaseExpression"})
        ET.SubElement(fc_1, "NAME", {"xsi:type": "string"}).text = "stateDevice"

        sc_1 = ET.SubElement(first_level, "SECOND-COMPONENT", {"xsi:type": "varBaseExpression"})
        ET.SubElement(sc_1, "NAME", {"xsi:type": "string"}).text = var_device

        second_component = ET.SubElement(formula, 'SECOND-COMPONENT', {'xsi:type': 'varBaseExpression'})

        ET.SubElement(second_component, "NAME", {"xsi:type": "string"}).text = 'stateType'

        # === EXPECTATION-OPTION ===
        expectation = ET.SubElement(teststep, "EXPECTATION-OPTION", {"xsi:type": "timelessOption"})
        expression = ET.SubElement(expectation, "EXPRESSION", {"xsi:type": "builtNumericExpression"})
        ET.SubElement(expression, "RELATION", {"xsi:type": "string"}).text = "=="

        value = ET.SubElement(expression, "VALUE", {"xsi:type": "varBaseExpression"})
        ET.SubElement(value, "NAME", {"xsi:type": "string"}).text = 'ExpectedState'

        # INSTANCE NAME
        ET.SubElement(teststep, 'INSTANCE-NAME', {'xsi:type': 'string'}).text = 'Get state of device'

    def GenXML_PSDIAG_Set_State_StaticBit(self, parent, var_device='Device', var_state='State'):
        """Generate a TESTSTEP for PSDIAG_Set_Device_Configuration with dictBaseExpression"""
        step = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })

        ET.SubElement(step, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'PSDIAG_Set_Device_Configuration'
        if 'PSDIAG_Set_Device_Configuration' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('PSDIAG_Set_Device_Configuration')

        param_assignments = ET.SubElement(step, 'PARAM-ASSIGNMENTS')

        # === ASSIGNMENT dkey="P_devicesModesDict" ===
        assign = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_devicesModesDict'})
        dvalue = ET.SubElement(assign, 'DVALUE', {'xsi:type': 'dictBaseExpression'})
        expr_dict = ET.SubElement(dvalue, 'EXPRESSION-DICT')
        item = ET.SubElement(expr_dict, 'ITEM', {'xsi:type': 'expressionDictItem'})

        key_elem = ET.SubElement(item, 'KEY', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(key_elem, 'NAME', {'xsi:type': 'string'}).text = var_device

        val_elem = ET.SubElement(item, 'VALUE', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(val_elem, 'NAME', {'xsi:type': 'string'}).text = var_state

        # === ALTERNATIVE-MAPPING-SPACE ===
        ET.SubElement(step, 'ALTERNATIVE-MAPPING-SPACE', {
            'format-rev': '1',
            'xsi:type': 'mappingSpace'
        })
    
    def GenXML_PSDIAG_Get_State_StaticBit(self, parent, var_static_bit ='Static_Bit', var_expect_state='Expect_State'):
        ################ Generate the calculation to get the name of static behivior bit with string have uppered ########################
        teststep = ET.SubElement(parent, "TESTSTEP", {
        "format-rev": "3",
        "id": str(uuid.uuid4()),
        "name": "TsCalculation",
        "xsi:type": "utility-4115fa00-5f3c-11df-8a53-001c233b3528"
        })

        # VARIABLE-REFS
        var_refs = ET.SubElement(teststep, "VARIABLE-REFS")
        var_name = ET.SubElement(var_refs, "VARIABLE-NAME", {"dkey": "default"})
        dvalue = ET.SubElement(var_name, "DVALUE", {"xsi:type": "string"})
        dvalue.text = var_static_bit

        # FORMULA
        formula = ET.SubElement(teststep, "FORMULA", {"xsi:type": "functionBaseExpression"})

        # Outer most COMPONENT (upper)
        outer_attr = ET.SubElement(formula, "COMPONENT", {"xsi:type": "attributeBaseExpression"})

        # BINARY_SUBSCR
        binary_subscr = ET.SubElement(outer_attr, "COMPONENT", {"xsi:type": "binaryOpBaseExpression"})
        ET.SubElement(binary_subscr, "NAME", {"xsi:type": "string"}).text = "BINARY_SUBSCR"

        # First Component: Static_Bit.split('_')
        fc_func = ET.SubElement(binary_subscr, "FIRST-COMPONENT", {"xsi:type": "functionBaseExpression"})
        attr = ET.SubElement(fc_func, "COMPONENT", {"xsi:type": "attributeBaseExpression"})
        var = ET.SubElement(attr, "COMPONENT", {"xsi:type": "varBaseExpression"})
        ET.SubElement(var, "NAME", {"xsi:type": "string"}).text = var_static_bit
        ET.SubElement(attr, "ATTR-NAME", {"xsi:type": "string"}).text = "split"

        args = ET.SubElement(fc_func, "ARGUMENTS")
        arg = ET.SubElement(args, "ARGUMENT", {"format-rev": "2", "xsi:type": "valueBaseExpression"})
        ET.SubElement(arg, "VALUE", {"xsi:type": "string"}).text = "_"

        # Second Component: -2
        second_comp = ET.SubElement(binary_subscr, "SECOND-COMPONENT", {"xsi:type": "unaryOpBaseExpression"})
        ET.SubElement(second_comp, "NAME", {"xsi:type": "string"}).text = "UNARY_NEGATIVE"
        component = ET.SubElement(second_comp, "COMPONENT", {"format-rev": "2", "xsi:type": "valueBaseExpression"})
        ET.SubElement(component, "VALUE", {"xsi:type": "integer"}).text = "2"

        # ATTR-NAME for outer_attr
        ET.SubElement(outer_attr, "ATTR-NAME", {"xsi:type": "string"}).text = "upper"

        # INSTANCE-NAME
        ET.SubElement(teststep, "INSTANCE-NAME", {"xsi:type": "string"}).text = "Extract name of static bit"

        ############# Generate job get device configuration to get state of behivior of static bit ######################
        teststep = ET.SubElement(parent, "TESTSTEP", {
        "format-rev": "1",
        "id": str(uuid.uuid4()),
        "xsi:type": "tsPackageCall"
        })

        # MAPPING-REF
        ET.SubElement(teststep, "MAPPING-REF", {"xsi:type": "string"}).text = "PSDIAG_Get_Device_Configuration"
        if "PSDIAG_Get_Device_Configuration" not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append("PSDIAG_Get_Device_Configuration")

        # VARIABLE-REFS
        var_refs = ET.SubElement(teststep, "VARIABLE-REFS")
        var_name = ET.SubElement(var_refs, "VARIABLE-NAME", {"dkey": "R_result"})
        dvalue = ET.SubElement(var_name, "DVALUE", {"xsi:type": "string"})
        dvalue.text = 'stateBit'

        # PARAM-ASSIGNMENTS
        param_assignments = ET.SubElement(teststep, "PARAM-ASSIGNMENTS")

        # Assignment for P_devices
        assignment = ET.SubElement(param_assignments, "ASSIGNMENT", {"dkey": "P_devices"})
        dvalue = ET.SubElement(assignment, "DVALUE", {"xsi:type": "listOrTupleBaseExpression"})

        ET.SubElement(dvalue, "IS-LIST", {"xsi:type": "boolean"}).text = "True"

        expr_list = ET.SubElement(dvalue, "EXPRESSION-LIST")
        base_expr = ET.SubElement(expr_list, "BASE-EXPRESSION", {"xsi:type": "varBaseExpression"})
        ET.SubElement(base_expr, "NAME", {"xsi:type": "string"}).text = var_static_bit

        # ALTERNATIVE-MAPPING-SPACE
        ET.SubElement(teststep, "ALTERNATIVE-MAPPING-SPACE", {
            "format-rev": "1",
            "xsi:type": "mappingSpace"
        })

        ################ Generate calculation to evaluate state of static bit ####################### 
        teststep = ET.SubElement(parent, "TESTSTEP", {
        "format-rev": "3",
        "id": str(uuid.uuid4()),
        "name": "TsCalculation",
        "xsi:type": "utility-4115fa00-5f3c-11df-8a53-001c233b3528"
        })

        # === FORMULA ===
        formula = ET.SubElement(teststep, "FORMULA", {"xsi:type": "binaryOpBaseExpression"})
        ET.SubElement(formula, "NAME", {"xsi:type": "string"}).text = "BINARY_SUBSCR"

        # FIRST-COMPONENT (stateBit[Static_Bit])
        first_level = ET.SubElement(formula, "FIRST-COMPONENT", {"xsi:type": "binaryOpBaseExpression"})
        ET.SubElement(first_level, "NAME", {"xsi:type": "string"}).text = "BINARY_SUBSCR"

        fc_1 = ET.SubElement(first_level, "FIRST-COMPONENT", {"xsi:type": "varBaseExpression"})
        ET.SubElement(fc_1, "NAME", {"xsi:type": "string"}).text = "stateBit"

        sc_1 = ET.SubElement(first_level, "SECOND-COMPONENT", {"xsi:type": "varBaseExpression"})
        ET.SubElement(sc_1, "NAME", {"xsi:type": "string"}).text = var_static_bit

        # SECOND-COMPONENT (['Behavior'])
        second_component = ET.SubElement(formula, "SECOND-COMPONENT", {
            "format-rev": "2",
            "xsi:type": "valueBaseExpression"
        })
        ET.SubElement(second_component, "VALUE", {"xsi:type": "string"}).text = "Behavior"

        # === EXPECTATION-OPTION ===
        expectation = ET.SubElement(teststep, "EXPECTATION-OPTION", {"xsi:type": "timelessOption"})
        expression = ET.SubElement(expectation, "EXPRESSION", {"xsi:type": "builtNumericExpression"})
        ET.SubElement(expression, "RELATION", {"xsi:type": "string"}).text = "=="

        value = ET.SubElement(expression, "VALUE", {"xsi:type": "varBaseExpression"})
        ET.SubElement(value, "NAME", {"xsi:type": "string"}).text = var_expect_state
        # INSTANCE NAME
        ET.SubElement(teststep, 'INSTANCE-NAME', {'xsi:type': 'string'}).text = 'Get state of behivior bit'

    def GenXML_PSDIAG_Read_Fault_Memory(self, parent, var_fault,var_mask_checkfault = "Ftl_State_Q" ):
        """
        Generate a PSDIAG_Read_Fault_Memory test step
        """
        step = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })

        ET.SubElement(step, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'PSDIAG_Read_Fault_Memory'
        if 'PSDIAG_Read_Fault_Memory' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('PSDIAG_Read_Fault_Memory')

        # === VARIABLE-REFS ===
        variable_refs = ET.SubElement(step, 'VARIABLE-REFS')
        var_name = ET.SubElement(variable_refs, 'VARIABLE-NAME', {'dkey': 'R_faultMemory_Obj'})
        dvalue = ET.SubElement(var_name, 'DVALUE', {'xsi:type': 'string'})
        dvalue.text = 'Flt_PD_Obj'

        # === PARAM-ASSIGNMENTS ===
        param_assignments = ET.SubElement(step, 'PARAM-ASSIGNMENTS')

        assignment = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_memoryType'})
        dvalue = ET.SubElement(assignment, 'DVALUE', {
            'format-rev': '2',
            'xsi:type': 'valueBaseExpression'
        })
        ET.SubElement(dvalue, 'VALUE', {'xsi:type': 'string'}).text = 'PRIMARY'

        # === ALTERNATIVE-MAPPING-SPACE ===
        ET.SubElement(step, 'ALTERNATIVE-MAPPING-SPACE', {
            'format-rev': '1',
            'xsi:type': 'mappingSpace'
        })

        """
        Generate a TsCalculation step to get fault status using Func_GetFaultStatus
        """
        step = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '3',
            'id': str(uuid.uuid4()),
            'name': 'TsCalculation',
            'xsi:type': 'utility-4115fa00-5f3c-11df-8a53-001c233b3528'
        })

        # === VARIABLE-REFS ===
        variable_refs = ET.SubElement(step, 'VARIABLE-REFS')
        var_name = ET.SubElement(variable_refs, 'VARIABLE-NAME', {'dkey': 'default'})
        dvalue = ET.SubElement(var_name, 'DVALUE', {'xsi:type': 'string'})
        dvalue.text = 'statusFault'

        # === FORMULA ===
        formula = ET.SubElement(step, 'FORMULA', {'xsi:type': 'functionBaseExpression'})
        component = ET.SubElement(formula, 'COMPONENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(component, 'NAME', {'xsi:type': 'string'}).text = 'Func_GetFaultStatus'

        arguments = ET.SubElement(formula, 'ARGUMENTS')
        arg1 = ET.SubElement(arguments, 'ARGUMENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(arg1, 'NAME', {'xsi:type': 'string'}).text = 'Flt_PD_Obj'
        arg2 = ET.SubElement(arguments, 'ARGUMENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(arg2, 'NAME', {'xsi:type': 'string'}).text = var_fault

        # === INSTANCE-NAME ===
        ET.SubElement(step, 'INSTANCE-NAME', {'xsi:type': 'string'}).text = 'Get fault status after creation'

        """
        Generate a TsCalculation step for evaluating fault after creation (BINARY_AND + Expectation)
        """
        step = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '3',
            'id': str(uuid.uuid4()),
            'name': 'TsCalculation',
            'xsi:type': 'utility-4115fa00-5f3c-11df-8a53-001c233b3528'
        })

        # === FORMULA ===
        formula = ET.SubElement(step, 'FORMULA', {'xsi:type': 'binaryOpBaseExpression'})
        ET.SubElement(formula, 'NAME', {'xsi:type': 'string'}).text = 'BINARY_AND'

        # First Component (function int(statusFault, 16))
        first_component = ET.SubElement(formula, 'FIRST-COMPONENT', {'xsi:type': 'functionBaseExpression'})
        component1 = ET.SubElement(first_component, 'COMPONENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(component1, 'NAME', {'xsi:type': 'string'}).text = 'int'
        arguments1 = ET.SubElement(first_component, 'ARGUMENTS')

        arg1 = ET.SubElement(arguments1, 'ARGUMENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(arg1, 'NAME', {'xsi:type': 'string'}).text = 'statusFault'

        arg2 = ET.SubElement(arguments1, 'ARGUMENT', {'format-rev': '2', 'xsi:type': 'valueBaseExpression'})
        ET.SubElement(arg2, 'VALUE', {'xsi:type': 'integer'}).text = '16'

        # Second Component (function int(MASK, 2))
        second_component = ET.SubElement(formula, 'SECOND-COMPONENT', {'xsi:type': 'functionBaseExpression'})
        component2 = ET.SubElement(second_component, 'COMPONENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(component2, 'NAME', {'xsi:type': 'string'}).text = 'int'
        arguments2 = ET.SubElement(second_component, 'ARGUMENTS')

        arg3 = ET.SubElement(arguments2, 'ARGUMENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(arg3, 'NAME', {'xsi:type': 'string'}).text = 'MASK'

        arg4 = ET.SubElement(arguments2, 'ARGUMENT', {'format-rev': '2', 'xsi:type': 'valueBaseExpression'})
        ET.SubElement(arg4, 'VALUE', {'xsi:type': 'integer'}).text = '2'

        # === EXPECTATION-OPTION ===
        expectation = ET.SubElement(step, 'EXPECTATION-OPTION', {'xsi:type': 'timelessOption'})
        expression = ET.SubElement(expectation, 'EXPRESSION', {'xsi:type': 'builtNumericExpression'})
        ET.SubElement(expression, 'RELATION', {'xsi:type': 'string'}).text = '=='

        if "Ftl_State" not in var_mask_checkfault:
            value = ET.SubElement(expression, 'VALUE', {'xsi:type': 'functionBaseExpression'})
            comp_val = ET.SubElement(value, 'COMPONENT', {'xsi:type': 'varBaseExpression'})
            ET.SubElement(comp_val, 'NAME', {'xsi:type': 'string'}).text = 'int'
            args_val = ET.SubElement(value, 'ARGUMENTS')

            arg_v1 = ET.SubElement(args_val, 'ARGUMENT', {'xsi:type': 'varBaseExpression'})
            ET.SubElement(arg_v1, 'NAME', {'xsi:type': 'string'}).text = var_mask_checkfault

            arg_v2 = ET.SubElement(args_val, 'ARGUMENT', {'format-rev': '2', 'xsi:type': 'valueBaseExpression'})
            val_v2 = ET.SubElement(arg_v2, 'VALUE', {'xsi:type': 'integer'})
            val_v2.text = str(2)
        else:
            value = ET.SubElement(expression, 'VALUE', {'xsi:type': 'varBaseExpression'})
            ET.SubElement(value, 'NAME', {'xsi:type': 'string'}).text = var_mask_checkfault

        # === INSTANCE-NAME ===
        ET.SubElement(step, 'INSTANCE-NAME', {'xsi:type': 'string'}).text = 'Evaluation fault after creation'
 
    def GenXML_Qualify_Fault(self, parent,var_fault):
        """
        Generate a PSDIAG_Manipulate_Fault_Memory test step
        """
        step = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })

        ET.SubElement(step, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'PSDIAG_Manipulate_Fault_Memory'
        if 'PSDIAG_Manipulate_Fault_Memory' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('PSDIAG_Manipulate_Fault_Memory')

        param_assignments = ET.SubElement(step, 'PARAM-ASSIGNMENTS')

        # === P_action ===
        assignment_action = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_action'})
        dvalue_action = ET.SubElement(assignment_action, 'DVALUE', {
            'format-rev': '2',
            'xsi:type': 'valueBaseExpression'
        })
        ET.SubElement(dvalue_action, 'VALUE', {'xsi:type': 'string'}).text = 'qualify'

        # === P_faultName ===
        assignment_fault = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_faultName'})
        dvalue_fault = ET.SubElement(assignment_fault, 'DVALUE', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(dvalue_fault, 'NAME', {'xsi:type': 'string'}).text = var_fault

        # === ALTERNATIVE-MAPPING-SPACE ===
        ET.SubElement(step, 'ALTERNATIVE-MAPPING-SPACE', {
            'format-rev': '1',
            'xsi:type': 'mappingSpace'
        })

        #Generate a PSDIAG_Read_Fault_Memory test step
        self.GenXML_PSDIAG_Read_Fault_Memory(parent,var_fault,'Ftl_State_Q')

    def GenXML_Dequalify_Fault(self, parent,var_fault):
        """
        Generate a PSDIAG_Manipulate_Fault_Memory test step
        """
        step = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })

        ET.SubElement(step, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'PSDIAG_Manipulate_Fault_Memory'
        if 'PSDIAG_Manipulate_Fault_Memory' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('PSDIAG_Manipulate_Fault_Memory')

        param_assignments = ET.SubElement(step, 'PARAM-ASSIGNMENTS')

        # === P_action ===
        assignment_action = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_action'})
        dvalue_action = ET.SubElement(assignment_action, 'DVALUE', {
            'format-rev': '2',
            'xsi:type': 'valueBaseExpression'
        })
        ET.SubElement(dvalue_action, 'VALUE', {'xsi:type': 'string'}).text = 'dequalify'

        # === P_faultName ===
        assignment_fault = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_faultName'})
        dvalue_fault = ET.SubElement(assignment_fault, 'DVALUE', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(dvalue_fault, 'NAME', {'xsi:type': 'string'}).text = var_fault

        # === ALTERNATIVE-MAPPING-SPACE ===
        ET.SubElement(step, 'ALTERNATIVE-MAPPING-SPACE', {
            'format-rev': '1',
            'xsi:type': 'mappingSpace'
        })

        #Generate a PSDIAG_Read_Fault_Memory test step
        self.GenXML_PSDIAG_Read_Fault_Memory(parent,var_fault,'Ftl_State_DQ')
        
    def GenXML_Observe_Fault_In_PSDiag(self, parent,var_fault,var_expected_state):
        #Generate a PSDIAG_Read_Fault_Memory test step
        self.GenXML_PSDIAG_Read_Fault_Memory(parent,var_fault,var_expected_state)

    def GenXML_Read_Variable_In_PSDiag(self, parent, var_name, var_expected_value):
        """Generate PSDIAG_Read_Memory test step"""
        test_step = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })

        ET.SubElement(test_step, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'PSDIAG_Read_Memory'

        if 'PSDIAG_Read_Memory' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('PSDIAG_Read_Memory')

        # VARIABLE-REFS
        variable_refs = ET.SubElement(test_step, 'VARIABLE-REFS')
        variable_name = ET.SubElement(variable_refs, 'VARIABLE-NAME', {'dkey': 'R_result'})
        dvalue = ET.SubElement(variable_name, 'DVALUE', {'xsi:type': 'string'})
        dvalue.text = 'valueVar'

        # PARAM-ASSIGNMENTS
        param_assignments = ET.SubElement(test_step, 'PARAM-ASSIGNMENTS')
        assign_label_or_addr = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_labelOrAddress'})
        dvalue = ET.SubElement(assign_label_or_addr, 'DVALUE', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(dvalue, 'NAME', {'xsi:type': 'string'}).text = var_name

        # P_memoryContentsAsInteger
        assignment2 = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_memoryContentsAsInteger'})
        dvalue2 = ET.SubElement(assignment2, 'DVALUE', {'format-rev': '2', 'xsi:type': 'valueBaseExpression'})
        ET.SubElement(dvalue2, 'VALUE', {'xsi:type': 'boolean'}).text = 'True'

        # ALTERNATIVE-MAPPING-SPACE
        ET.SubElement(test_step, 'ALTERNATIVE-MAPPING-SPACE', {
            'format-rev': '1',
            'xsi:type': 'mappingSpace'
        })

        """Generate TsCalculation test step to compare variable with expected value"""
        test_step = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '3',
            'id': str(uuid.uuid4()),
            'name': 'TsCalculation',
            'xsi:type': 'utility-4115fa00-5f3c-11df-8a53-001c233b3528'
        })

        # FORMULA
        formula = ET.SubElement(test_step, 'FORMULA', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(formula, 'NAME', {'xsi:type': 'string'}).text = 'valueVar'

        # EXPECTATION-OPTION
        expectation = ET.SubElement(test_step, 'EXPECTATION-OPTION', {'xsi:type': 'timelessOption'})
        expr = ET.SubElement(expectation, 'EXPRESSION', {'xsi:type': 'builtNumericExpression'})
        ET.SubElement(expr, 'RELATION', {'xsi:type': 'string'}).text = '=='

        value = ET.SubElement(expr, 'VALUE', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(value, 'NAME', {'xsi:type': 'string'}).text = var_expected_value

        # INSTANCE-NAME
        ET.SubElement(test_step, 'INSTANCE-NAME', {'xsi:type': 'string'}).text = 'Evaluate the value of variable in memory PSDiag'

    def GenXML_Write_Variable_In_PSDiag(self, parent, var_name, var_value):
        """Generate PSDIAG_Set_Memory test step"""
        """Generate PSDIAG_Write_Memory test step"""
        test_step = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })

        ET.SubElement(test_step, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'PSDIAG_Write_Memory'

        if 'PSDIAG_Write_Memory' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('PSDIAG_Write_Memory')

        param_assignments = ET.SubElement(test_step, 'PARAM-ASSIGNMENTS')

        # P_labelOrAddress = Variable_Name
        assignment_label = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_labelOrAddress'})
        dvalue_label = ET.SubElement(assignment_label, 'DVALUE', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(dvalue_label, 'NAME', {'xsi:type': 'string'}).text = var_name

        # P_memoryContents = int(Value, 16)
        assignment_memory = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_memoryContents'})
        dvalue_memory = ET.SubElement(assignment_memory, 'DVALUE', {'xsi:type': 'functionBaseExpression'})

        component = ET.SubElement(dvalue_memory, 'COMPONENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(component, 'NAME', {'xsi:type': 'string'}).text = 'int'

        arguments = ET.SubElement(dvalue_memory, 'ARGUMENTS')

        argument1 = ET.SubElement(arguments, 'ARGUMENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(argument1, 'NAME', {'xsi:type': 'string'}).text = var_value

        argument2 = ET.SubElement(arguments, 'ARGUMENT', {'format-rev': '2', 'xsi:type': 'valueBaseExpression'})
        ET.SubElement(argument2, 'VALUE', {'xsi:type': 'integer'}).text = '16'

        ET.SubElement(test_step, 'ALTERNATIVE-MAPPING-SPACE', {'format-rev': '1', 'xsi:type': 'mappingSpace'})

    def GenXML_Wait_FaultQualify(self, parent,var_fault):
        #Generate a PSDIAG_Read_Fault_Memory test step
        self.GenXML_PSDIAG_Read_Fault_Memory(parent,var_fault,'Ftl_State_Q')

    def GenXML_Read_All_Fault_In_PSDiag_With_Expected_No_Fault_Store(self,parent):
        ###### Generate job read fault memory ##################
        teststep = ET.SubElement(parent, 'TESTSTEP', {
        'format-rev': '1',
        'id': str(uuid.uuid4()),
        'xsi:type': 'tsPackageCall'
        })

        mapping_ref = ET.SubElement(teststep, 'MAPPING-REF', {'xsi:type': 'string'})
        mapping_ref.text = 'PSDIAG_Read_Fault_Memory'
        if 'PSDIAG_Read_Fault_Memory' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('PSDIAG_Read_Fault_Memory')

        var_refs = ET.SubElement(teststep, 'VARIABLE-REFS')
        var_name = ET.SubElement(var_refs, 'VARIABLE-NAME', {'dkey': 'R_faultMemory_Obj'})
        dvalue = ET.SubElement(var_name, 'DVALUE', {'xsi:type': 'string'})
        dvalue.text = 'FaultMem_Obj'

        param_assignments = ET.SubElement(teststep, 'PARAM-ASSIGNMENTS')
        assignment = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_memoryType'})
        dvalue2 = ET.SubElement(assignment, 'DVALUE', {'format-rev': '2', 'xsi:type': 'valueBaseExpression'})
        value = ET.SubElement(dvalue2, 'VALUE', {'xsi:type': 'string'})
        value.text = 'PRIMARY'

        ET.SubElement(teststep, 'ALTERNATIVE-MAPPING-SPACE', {'format-rev': '1', 'xsi:type': 'mappingSpace'})

        ##### Generate tets job evaluate fault ###########
        teststep = ET.SubElement(parent, 'TESTSTEP', {
        'format-rev': '1',
        'id': str(uuid.uuid4()),
        'xsi:type': 'tsPackageCall'
        })

        mapping_ref = ET.SubElement(teststep, 'MAPPING-REF', {'xsi:type': 'string'})
        mapping_ref.text = 'PSDIAG_Evaluate_Fault'
        if 'PSDIAG_Evaluate_Fault' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('PSDIAG_Evaluate_Fault')

        param_assignments = ET.SubElement(teststep, 'PARAM-ASSIGNMENTS')

        # P_Mandatory_Faults
        assignment1 = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_Mandatory_Faults'})
        dvalue1 = ET.SubElement(assignment1, 'DVALUE', {'xsi:type': 'listOrTupleBaseExpression'})
        ET.SubElement(dvalue1, 'IS-LIST', {'xsi:type': 'boolean'}).text = 'True'
        ET.SubElement(dvalue1, 'EXPRESSION-LIST')

        # P_Optional_Faults
        assignment2 = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_Optional_Faults'})
        dvalue2 = ET.SubElement(assignment2, 'DVALUE', {'xsi:type': 'listOrTupleBaseExpression'})
        ET.SubElement(dvalue2, 'IS-LIST', {'xsi:type': 'boolean'}).text = 'True'
        ET.SubElement(dvalue2, 'EXPRESSION-LIST')

        # P_PSDIAG_FaultMem_Obj
        assignment3 = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_PSDIAG_FaultMem_Obj'})
        dvalue3 = ET.SubElement(assignment3, 'DVALUE', {'xsi:type': 'varBaseExpression'})
        name3 = ET.SubElement(dvalue3, 'NAME', {'xsi:type': 'string'})
        name3.text = 'FaultMem_Obj'

        ET.SubElement(teststep, 'ALTERNATIVE-MAPPING-SPACE', {'format-rev': '1', 'xsi:type': 'mappingSpace'})

    def GenXML_Read_FaultMemory_With_Type(self,parent, varMemType):
        """Generate PSDIAG_Read_Fault_Memory test step"""
        test_step = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })

        ET.SubElement(test_step, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'PSDIAG_Read_Fault_Memory'

        if 'PSDIAG_Read_Fault_Memory' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('PSDIAG_Read_Fault_Memory')

        variable_refs = ET.SubElement(test_step, 'VARIABLE-REFS')
        variable_name = ET.SubElement(variable_refs, 'VARIABLE-NAME', {'dkey': 'R_faultMemory_Obj'})
        dvalue = ET.SubElement(variable_name, 'DVALUE', {'xsi:type': 'string'})
        dvalue.text = 'FaultMem_Obj'

        param_assignments = ET.SubElement(test_step, 'PARAM-ASSIGNMENTS')
        assignment = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_memoryType'})
        dvalue = ET.SubElement(assignment, 'DVALUE', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(dvalue, 'NAME', {'xsi:type': 'string'}).text = varMemType

        ET.SubElement(test_step, 'ALTERNATIVE-MAPPING-SPACE', {'format-rev': '1', 'xsi:type': 'mappingSpace'})

    def GenXML_Set_Voltage(self,parent,voltage):
        test_step = ET.SubElement(parent, 'TESTSTEP', {
        'format-rev': '1',
        'id': str(uuid.uuid4()),
        'xsi:type': 'tsPackageCall'
        })
        ET.SubElement(test_step, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'LC12_SetVoltage'
        if 'LC12_SetVoltage' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('LC12_SetVoltage')

        param_assign = ET.SubElement(test_step, 'PARAM-ASSIGNMENTS')
        assign = ET.SubElement(param_assign, 'ASSIGNMENT', {'dkey': 'P_Vbat'})
        dvalue = ET.SubElement(assign, 'DVALUE', {'format-rev': '2', 'xsi:type': 'valueBaseExpression'})
        ET.SubElement(dvalue, 'VALUE', {'xsi:type': 'integer'}).text = voltage
        ET.SubElement(test_step, 'ALTERNATIVE-MAPPING-SPACE', {'format-rev': '1', 'xsi:type': 'mappingSpace'})

    def GenXML_Set_Precondition(self, parent,var_precondition):
        precondition_step = ET.SubElement(parent, 'TESTSTEP', {
        'id': str(uuid.uuid4()),
        'name': 'TsSwitchCase',
        'xsi:type': 'utility-83517ac0-9f53-11dd-9c62-001b24fa84be'
        })

        case_node1 = ET.SubElement(precondition_step, 'TESTSTEP', {
            'id': str(uuid.uuid4()),
            'xsi:type': 'caseNode'
        })

        # Case 1: Set low Voltage
        self.GenXML_Set_Voltage(case_node1,'6')
        self.GenXML_GEN_wait_ms(case_node1,'5000')
        # CASE-VALUE
        case_value = ET.SubElement(case_node1, 'CASE-VALUE', {'format-rev': '2', 'xsi:type': 'valueBaseExpression'})
        ET.SubElement(case_value, 'VALUE', {'xsi:type': 'string'}).text = 'low_voltage'

        # IS-DEFAULT
        ET.SubElement(case_node1, 'IS-DEFAULT', {'xsi:type': 'boolean'}).text = 'False'

        case_node2 = ET.SubElement(precondition_step, 'TESTSTEP', {
            'id': str(uuid.uuid4()),
            'xsi:type': 'caseNode'
        })
        # Case 2: Set high Voltage
        self.GenXML_Set_Voltage(case_node2,'18')
        self.GenXML_GEN_wait_ms(case_node2,'5000')
        # CASE-VALUE
        case_value = ET.SubElement(case_node2, 'CASE-VALUE', {'format-rev': '2', 'xsi:type': 'valueBaseExpression'})
        ET.SubElement(case_value, 'VALUE', {'xsi:type': 'string'}).text = 'high_voltage'

        # IS-DEFAULT
        ET.SubElement(case_node2, 'IS-DEFAULT', {'xsi:type': 'boolean'}).text = 'False'

        case_node3 = ET.SubElement(precondition_step, 'TESTSTEP', {
            'id': str(uuid.uuid4()),
            'xsi:type': 'caseNode'
        })
        case_value = ET.SubElement(case_node3, 'CASE-VALUE', {
        'format-rev': '2',
        'xsi:type': 'valueBaseExpression'
        })
        ET.SubElement(case_value, 'VALUE', {'xsi:type': 'integer'}).text = '0'

        ET.SubElement(case_node3, 'IS-DEFAULT', {'xsi:type': 'boolean'}).text = 'True'

        # SWITCH-VALUE
        precondition_value = ET.SubElement(precondition_step, 'SWITCH-VALUE', {'xsi:type': 'functionBaseExpression'})
        component = ET.SubElement(precondition_value, 'COMPONENT', {'xsi:type': 'attributeBaseExpression'})
        sub_component = ET.SubElement(component, 'COMPONENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(sub_component, 'NAME', {'xsi:type': 'string'}).text = var_precondition
        ET.SubElement(component, 'ATTR-NAME', {'xsi:type': 'string'}).text = 'lower'

    def GenXML_Clear_Precondition(self, parent,var_precondition):
        precondition_step = ET.SubElement(parent, 'TESTSTEP', {
        'id': str(uuid.uuid4()),
        'name': 'TsSwitchCase',
        'xsi:type': 'utility-83517ac0-9f53-11dd-9c62-001b24fa84be'
        })

        case_node1 = ET.SubElement(precondition_step, 'TESTSTEP', {
            'id': str(uuid.uuid4()),
            'xsi:type': 'caseNode'
        })

        # Case 1: Set low Voltage
        self.GenXML_Set_Voltage(case_node1,'13')
        self.GenXML_GEN_wait_ms(case_node1,'5000')
        # CASE-VALUE
        case_value = ET.SubElement(case_node1, 'CASE-VALUE', {'format-rev': '2', 'xsi:type': 'valueBaseExpression'})
        ET.SubElement(case_value, 'VALUE', {'xsi:type': 'string'}).text = 'low_voltage'

        # IS-DEFAULT
        ET.SubElement(case_node1, 'IS-DEFAULT', {'xsi:type': 'boolean'}).text = 'False'

        case_node2 = ET.SubElement(precondition_step, 'TESTSTEP', {
            'id': str(uuid.uuid4()),
            'xsi:type': 'caseNode'
        })
        # Case 2: Set high Voltage
        self.GenXML_Set_Voltage(case_node2,'13')
        self.GenXML_GEN_wait_ms(case_node2,'5000')
        # CASE-VALUE
        case_value = ET.SubElement(case_node2, 'CASE-VALUE', {'format-rev': '2', 'xsi:type': 'valueBaseExpression'})
        ET.SubElement(case_value, 'VALUE', {'xsi:type': 'string'}).text = 'high_voltage'

        # IS-DEFAULT
        ET.SubElement(case_node2, 'IS-DEFAULT', {'xsi:type': 'boolean'}).text = 'False'

        case_node3 = ET.SubElement(precondition_step, 'TESTSTEP', {
            'id': str(uuid.uuid4()),
            'xsi:type': 'caseNode'
        })
        case_value = ET.SubElement(case_node3, 'CASE-VALUE', {
        'format-rev': '2',
        'xsi:type': 'valueBaseExpression'
        })
        ET.SubElement(case_value, 'VALUE', {'xsi:type': 'integer'}).text = '0'

        ET.SubElement(case_node3, 'IS-DEFAULT', {'xsi:type': 'boolean'}).text = 'True'

        # SWITCH-VALUE
        precondition_value = ET.SubElement(precondition_step, 'SWITCH-VALUE', {'xsi:type': 'functionBaseExpression'})
        component = ET.SubElement(precondition_value, 'COMPONENT', {'xsi:type': 'attributeBaseExpression'})
        sub_component = ET.SubElement(component, 'COMPONENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(sub_component, 'NAME', {'xsi:type': 'string'}).text = var_precondition
        ET.SubElement(component, 'ATTR-NAME', {'xsi:type': 'string'}).text = 'lower'

    def GenXML_Evaluate_Squib_Value(self,parent, varDID ,varExpectedValue ):
        self.LibraryManager.EDR_Lib.GenXML_Diag_Request_Binary_Add(parent,['22',varDID],['62',varDID], var_Result='squibValue')

        ET.SubElement(parent, 'TESTSTEP', {
        'format-rev': '3',
        'id': str(uuid.uuid4()),
        'name': 'TsCalculation',
        'xsi:type': 'utility-4115fa00-5f3c-11df-8a53-001c233b3528'
        })

        var_refs = ET.SubElement(parent[-1], 'VARIABLE-REFS')
        var_name_node = ET.SubElement(var_refs, 'VARIABLE-NAME', {'dkey': 'default'})
        ET.SubElement(var_name_node, 'DVALUE', {'xsi:type': 'string'}).text = 'value_squib'

        formula = ET.SubElement(parent[-1], 'FORMULA', {'xsi:type': 'functionBaseExpression'})

        component_attr = ET.SubElement(formula, 'COMPONENT', {'xsi:type': 'attributeBaseExpression'})
        component_slice = ET.SubElement(component_attr, 'COMPONENT', {'xsi:type': 'sliceBaseExpression'})
        component_var = ET.SubElement(component_slice, 'COMPONENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(component_var, 'NAME', {'xsi:type': 'string'}).text = 'squibValue'

        start_node = ET.SubElement(component_slice, 'START', {'format-rev': '2', 'xsi:type': 'valueBaseExpression'})
        ET.SubElement(start_node, 'VALUE', {'xsi:type': 'integer'}).text = '9'

        stop_node = ET.SubElement(component_slice, 'STOP', {'format-rev': '2', 'xsi:type': 'valueBaseExpression'})
        ET.SubElement(stop_node, 'VALUE', {'xsi:type': 'integer'}).text = '15'

        ET.SubElement(component_attr, 'ATTR-NAME', {'xsi:type': 'string'}).text = 'replace'

        args = ET.SubElement(formula, 'ARGUMENTS')

        arg1 = ET.SubElement(args, 'ARGUMENT', {'format-rev': '2', 'xsi:type': 'valueBaseExpression'})
        ET.SubElement(arg1, 'VALUE', {'xsi:type': 'string'}).text = " "

        arg2 = ET.SubElement(args, 'ARGUMENT', {'format-rev': '2', 'xsi:type': 'valueBaseExpression'})
        ET.SubElement(arg2, 'VALUE', {'xsi:type': 'string'}).text = ""

        # Generate Evaluate response for squib resistance
        ET.SubElement(parent, 'TESTSTEP', {
        'format-rev': '3',
        'id': str(uuid.uuid4()),
        'name': 'TsCalculation',
        'xsi:type': 'utility-4115fa00-5f3c-11df-8a53-001c233b3528'
        })

        formula = ET.SubElement(parent[-1], 'FORMULA', {'xsi:type': 'functionBaseExpression'})
        component = ET.SubElement(formula, 'COMPONENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(component, 'NAME', {'xsi:type': 'string'}).text = 'int'

        arguments = ET.SubElement(formula, 'ARGUMENTS')
        arg1 = ET.SubElement(arguments, 'ARGUMENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(arg1, 'NAME', {'xsi:type': 'string'}).text = 'value_squib'

        arg2 = ET.SubElement(arguments, 'ARGUMENT', {
            'format-rev': '2',
            'xsi:type': 'valueBaseExpression'
        })
        ET.SubElement(arg2, 'VALUE', {'xsi:type': 'integer'}).text = '16'

        expect = ET.SubElement(parent[-1], 'EXPECTATION-OPTION', {'xsi:type': 'timelessOption'})
        expr = ET.SubElement(expect, 'EXPRESSION', {'xsi:type': 'builtNumericExpression'})
        ET.SubElement(expr, 'RELATION', {'xsi:type': 'string'}).text = '=='

        value = ET.SubElement(expr, 'VALUE', {'xsi:type': 'binaryOpBaseExpression'})
        ET.SubElement(value, 'NAME', {'xsi:type': 'string'}).text = 'BINARY_MULTIPLY'

        first = ET.SubElement(value, 'FIRST-COMPONENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(first, 'NAME', {'xsi:type': 'string'}).text = varExpectedValue

        second = ET.SubElement(value, 'SECOND-COMPONENT', {
            'format-rev': '2',
            'xsi:type': 'valueBaseExpression'
        })
        ET.SubElement(second, 'VALUE', {'xsi:type': 'integer'}).text = '1000'

        tolerance = ET.SubElement(expr, 'TOLERANCE', {
            'style': 'percentage',
            'xsi:type': 'Tolerance'
        })
        tol_value = ET.SubElement(tolerance, 'VALUE', {
            'format-rev': '2',
            'xsi:type': 'valueBaseExpression'
        })
        ET.SubElement(tol_value, 'VALUE', {'xsi:type': 'integer'}).text = '10'

        ET.SubElement(parent[-1], 'INSTANCE-NAME', {'xsi:type': 'string'}).text = 'Evaluate response for squib resistance'
        

class COM_Library_GenXMLTestStep(ShareBase):

    def __init__(self,LibraryManager:'LibraryManager'):
        self.LibraryManager:'LibraryManager' = LibraryManager

    def GenXML_Set_Signal(self,parent, var_signal, var_value, raw_value = 'True'):
        """Generate COM_SetSignal test step"""
        test_step = ET.SubElement(parent, 'TESTSTEP', {
        'format-rev': '1',
        'id': str(uuid.uuid4()),
        'xsi:type': 'tsPackageCall'
        })

        ET.SubElement(test_step, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'COM_SetSignal'

        if 'COM_SetSignal' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('COM_SetSignal')

        param_assignments = ET.SubElement(test_step, 'PARAM-ASSIGNMENTS')

        # P_setRawValue = True (boolean type)
        assign_setRawValue = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_setRawValue'})
        dvalue = ET.SubElement(assign_setRawValue, 'DVALUE', {
            'format-rev': '2',
            'xsi:type': 'valueBaseExpression'
        })
        ET.SubElement(dvalue, 'VALUE', {'xsi:type': 'boolean'}).text = raw_value

        # P_signalName = var_signal (variable reference)
        assign_signalName = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_signalName'})
        dvalue = ET.SubElement(assign_signalName, 'DVALUE', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(dvalue, 'NAME', {'xsi:type': 'string'}).text = var_signal

        # P_signalValue = int(Value_Signal, 16)
        assignment_signal_value = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_signalValue'})
        dvalue_signal_value = ET.SubElement(assignment_signal_value, 'DVALUE', {'xsi:type': 'functionBaseExpression'})

        component = ET.SubElement(dvalue_signal_value, 'COMPONENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(component, 'NAME', {'xsi:type': 'string'}).text = 'int'

        arguments = ET.SubElement(dvalue_signal_value, 'ARGUMENTS')

        argument1 = ET.SubElement(arguments, 'ARGUMENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(argument1, 'NAME', {'xsi:type': 'string'}).text = var_value

        argument2 = ET.SubElement(arguments, 'ARGUMENT', {'format-rev': '2', 'xsi:type': 'valueBaseExpression'})
        ET.SubElement(argument2, 'VALUE', {'xsi:type': 'integer'}).text = '16'

        # ALTERNATIVE-MAPPING-SPACE
        ET.SubElement(test_step, 'ALTERNATIVE-MAPPING-SPACE', {
            'format-rev': '1',
            'xsi:type': 'mappingSpace'
        })
        
    def GenXML_Start_Message(self, parent, var_msgID):
        """Generate COM_StartMessage test step"""
        test_step = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })

        ET.SubElement(test_step, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'COM_StartMessage'

        if 'COM_StartMessage' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('COM_StartMessage')

        # PARAM-ASSIGNMENTS
        param_assignments = ET.SubElement(test_step, 'PARAM-ASSIGNMENTS')

        assignment = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_id'})

        self.LibraryManager.Helpers_Lib.add_argument_assignment_convertHexStringToInt(assignment, var_msgID)

        ET.SubElement(test_step, 'ALTERNATIVE-MAPPING-SPACE', {'format-rev': '1', 'xsi:type': 'mappingSpace'})

    def GenXML_Stop_Message(self, parent, var_msgID):
        """Generate COM_StopMessage test step"""
        test_step = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })

        ET.SubElement(test_step, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'COM_StopMessage'

        if 'COM_StopMessage' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('COM_StopMessage')

        # PARAM-ASSIGNMENTS
        param_assignments = ET.SubElement(test_step, 'PARAM-ASSIGNMENTS')

        assignment = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_id'})
        self.LibraryManager.Helpers_Lib.add_argument_assignment_convertHexStringToInt(assignment, var_msgID)

        ET.SubElement(test_step, 'ALTERNATIVE-MAPPING-SPACE', {'format-rev': '1', 'xsi:type': 'mappingSpace'})

    def GenXML_GEN_waitcom_ms(self, parent,wait_time='1000'):
        """Generate a GEN_wait_ms test step"""
        wait_step = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })

        ET.SubElement(wait_step, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'GEN_wait_ms'
        if 'GEN_wait_ms' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('GEN_wait_ms')

        param_assignments = ET.SubElement(wait_step, 'PARAM-ASSIGNMENTS')
        self.LibraryManager.Helpers_Lib.add_parameter_assignment(param_assignments, 'P_waitTime', wait_time, 'valueBaseExpression', value_type='integer')

        ET.SubElement(wait_step, 'ALTERNATIVE-MAPPING-SPACE', {
            'format-rev': '1',
            'xsi:type': 'mappingSpace'
        })

    def GenXML_Evaluate_COMSignal_Value(self,parent, varSignal, varExpectedValue):
        """Generate COM_GetSignal test step"""
        test_step = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })

        ET.SubElement(test_step, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'COM_GetSignal'

        if 'COM_GetSignal' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('COM_GetSignal')

        # VARIABLE-REFS
        variable_refs = ET.SubElement(test_step, 'VARIABLE-REFS')
        variable_name = ET.SubElement(variable_refs, 'VARIABLE-NAME', {'dkey': 'R_result'})
        dvalue = ET.SubElement(variable_name, 'DVALUE', {'xsi:type': 'string'})
        dvalue.text = 'signalValue'

        # PARAM-ASSIGNMENTS
        param_assignments = ET.SubElement(test_step, 'PARAM-ASSIGNMENTS')

        # P_getRawValue = True
        assignment1 = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_getRawValue'})
        dvalue1 = ET.SubElement(assignment1, 'DVALUE', {
            'format-rev': '2',
            'xsi:type': 'valueBaseExpression'
        })
        value1 = ET.SubElement(dvalue1, 'VALUE', {'xsi:type': 'boolean'})
        value1.text = 'True'

        # P_signalName = Signal
        assignment2 = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_signalName'})
        dvalue2 = ET.SubElement(assignment2, 'DVALUE', {'xsi:type': 'varBaseExpression'})
        name2 = ET.SubElement(dvalue2, 'NAME', {'xsi:type': 'string'})
        name2.text = varSignal

        # ALTERNATIVE-MAPPING-SPACE
        ET.SubElement(test_step, 'ALTERNATIVE-MAPPING-SPACE', {
            'format-rev': '1',
            'xsi:type': 'mappingSpace'
        })

        """Generate TsCalculation to evaluate signal value"""
        test_step = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '3',
            'id': str(uuid.uuid4()),
            'name': 'TsCalculation',
            'xsi:type': 'utility-4115fa00-5f3c-11df-8a53-001c233b3528'
        })

        # FORMULA
        formula = ET.SubElement(test_step, 'FORMULA', {'xsi:type': 'varBaseExpression'})
        name_elem = ET.SubElement(formula, 'NAME', {'xsi:type': 'string'})
        name_elem.text = 'signalValue'

        # EXPECTATION-OPTION
        expectation = ET.SubElement(test_step, 'EXPECTATION-OPTION', {'xsi:type': 'timelessOption'})
        expression = ET.SubElement(expectation, 'EXPRESSION', {'xsi:type': 'builtNumericExpression'})
        relation = ET.SubElement(expression, 'RELATION', {'xsi:type': 'string'})
        relation.text = '=='

        value = ET.SubElement(expression, 'VALUE', {'xsi:type': 'functionBaseExpression'})
        component = ET.SubElement(value, 'COMPONENT', {'xsi:type': 'varBaseExpression'})
        name_component = ET.SubElement(component, 'NAME', {'xsi:type': 'string'})
        name_component.text = 'int'

        arguments = ET.SubElement(value, 'ARGUMENTS')

        argument1 = ET.SubElement(arguments, 'ARGUMENT', {'xsi:type': 'varBaseExpression'})
        name_arg1 = ET.SubElement(argument1, 'NAME', {'xsi:type': 'string'})
        name_arg1.text = varExpectedValue

        argument2 = ET.SubElement(arguments, 'ARGUMENT', {
            'format-rev': '2',
            'xsi:type': 'valueBaseExpression'
        })
        value_arg2 = ET.SubElement(argument2, 'VALUE', {'xsi:type': 'integer'})
        value_arg2.text = '16'

        # INSTANCE-NAME
        ET.SubElement(test_step, 'INSTANCE-NAME', {'xsi:type': 'string'}).text = 'Evaluate the signal value'
        
    def GenXML_Start_COMTrace(self, parent):
        """Generate COM_StartTrace test step"""
        test_step = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })

        ET.SubElement(test_step, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'COM_StartTrace'

        if 'COM_StartTrace' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('COM_StartTrace')

        # Empty PARAM-ASSIGNMENTS
        ET.SubElement(test_step, 'PARAM-ASSIGNMENTS')

        # ALTERNATIVE-MAPPING-SPACE
        ET.SubElement(test_step, 'ALTERNATIVE-MAPPING-SPACE', {'format-rev': '1', 'xsi:type': 'mappingSpace'})

    def GenXML_Stop_COMTrace(self, parent):
        """Generate COM_StopTrace test step"""
        test_step = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })

        ET.SubElement(test_step, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'COM_StopTrace'

        if 'COM_StopTrace' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('COM_StopTrace')

        # Empty PARAM-ASSIGNMENTS
        ET.SubElement(test_step, 'PARAM-ASSIGNMENTS')

        # ALTERNATIVE-MAPPING-SPACE
        ET.SubElement(test_step, 'ALTERNATIVE-MAPPING-SPACE', {'format-rev': '1', 'xsi:type': 'mappingSpace'})
        
    def GenXML_Clear_COMTrace(self, parent):
        """Generate COM_ClearTrace test step"""
        test_step = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })

        ET.SubElement(test_step, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'COM_ClearTrace'

        if 'COM_ClearTrace' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('COM_ClearTrace')

        # Empty PARAM-ASSIGNMENTS
        ET.SubElement(test_step, 'PARAM-ASSIGNMENTS')

        # ALTERNATIVE-MAPPING-SPACE
        ET.SubElement(test_step, 'ALTERNATIVE-MAPPING-SPACE', {'format-rev': '1', 'xsi:type': 'mappingSpace'})

    def GenXML_COM_ControlChecksum(self,parent, varMsgID, varStatusCRC):
        """Generate COM_ControlChecksum test step"""
        test_step = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })

        ET.SubElement(test_step, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'COM_ControlChecksum'

        if 'COM_ControlChecksum' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('COM_ControlChecksum')

        param_assignments = ET.SubElement(test_step, 'PARAM-ASSIGNMENTS')

        assignment1 = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_ControlType'})
        dvalue1 = ET.SubElement(assignment1, 'DVALUE', {'xsi:type': 'varBaseExpression'})
        name1 = ET.SubElement(dvalue1, 'NAME', {'xsi:type': 'string'})
        name1.text = varStatusCRC

        assignment2 = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_MessageName'})
        self.LibraryManager.Helpers_Lib.add_argument_assignment_convertHexStringToInt(assignment2, varMsgID)

        ET.SubElement(test_step, 'ALTERNATIVE-MAPPING-SPACE', {'format-rev': '1', 'xsi:type': 'mappingSpace'})
    
    def GenXML_COM_CheckSignalValue_InitMode(self, parent, varSignal, varExpectedSignalValue):
        """Generate TsCalculation for Get Report Folder"""
        test_step = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '3',
            'id': str(uuid.uuid4()),
            'name': 'TsCalculation',
            'xsi:type': 'utility-4115fa00-5f3c-11df-8a53-001c233b3528'
        })

        variable_refs = ET.SubElement(test_step, 'VARIABLE-REFS')
        variable_name = ET.SubElement(variable_refs, 'VARIABLE-NAME', {'dkey': 'default'})
        dvalue = ET.SubElement(variable_name, 'DVALUE', {'xsi:type': 'string'})
        dvalue.text = 'COM_file'

        formula = ET.SubElement(test_step, 'FORMULA', {'xsi:type': 'functionBaseExpression'})
        component = ET.SubElement(formula, 'COMPONENT', {'xsi:type': 'varBaseExpression'})
        name = ET.SubElement(component, 'NAME', {'xsi:type': 'string'})
        name.text = 'Func_Get_ReportFolder'

        instance_name = ET.SubElement(test_step, 'INSTANCE-NAME', {'xsi:type': 'string'})
        instance_name.text = 'Get Report Folder'

        """Generate COM_ExportCSVTraceLogging test step"""
        test_step = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })

        ET.SubElement(test_step, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'COM_ExportCSVTraceLogging'

        if 'COM_ExportCSVTraceLogging' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('COM_ExportCSVTraceLogging')

        param_assignments = ET.SubElement(test_step, 'PARAM-ASSIGNMENTS')
        assignment = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_fileDirectory'})
        dvalue = ET.SubElement(assignment, 'DVALUE', {'xsi:type': 'varBaseExpression'})
        name = ET.SubElement(dvalue, 'NAME', {'xsi:type': 'string'})
        name.text = 'COM_file'

        ET.SubElement(test_step, 'ALTERNATIVE-MAPPING-SPACE', {
            'format-rev': '1',
            'xsi:type': 'mappingSpace'
        })

        """Generate COM_AnalyzeTraceFile test step"""
        test_step = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })

        ET.SubElement(test_step, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'COM_AnalyzeTraceFile'

        if 'COM_AnalyzeTraceFile' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('COM_AnalyzeTraceFile')

        variable_refs = ET.SubElement(test_step, 'VARIABLE-REFS')
        variable_name = ET.SubElement(variable_refs, 'VARIABLE-NAME', {'dkey': 'R_Data_dict'})
        dvalue = ET.SubElement(variable_name, 'DVALUE', {'xsi:type': 'string'})
        dvalue.text = 'AllDataSignal_AfterReset_dict'

        param_assignments = ET.SubElement(test_step, 'PARAM-ASSIGNMENTS')

        assignment_msg = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_MsgOrSignal'})
        dvalue_msg = ET.SubElement(assignment_msg, 'DVALUE', {'xsi:type': 'listOrTupleBaseExpression'})
        ET.SubElement(dvalue_msg, 'IS-LIST', {'xsi:type': 'boolean'}).text = 'True'
        expr_list = ET.SubElement(dvalue_msg, 'EXPRESSION-LIST')
        base_expr = ET.SubElement(expr_list, 'BASE-EXPRESSION', {'xsi:type': 'varBaseExpression'})
        name = ET.SubElement(base_expr, 'NAME', {'xsi:type': 'string'})
        name.text = varSignal

        assignment_trace = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_tracePath'})
        dvalue_trace = ET.SubElement(assignment_trace, 'DVALUE', {'xsi:type': 'varBaseExpression'})
        name_trace = ET.SubElement(dvalue_trace, 'NAME', {'xsi:type': 'string'})
        name_trace.text = 'COM_file'

        ET.SubElement(test_step, 'ALTERNATIVE-MAPPING-SPACE', {
            'format-rev': '1',
            'xsi:type': 'mappingSpace'
        })

        """Generate TsCalculation test step to get init value of signal in trace"""
        test_step = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '3',
            'id': str(uuid.uuid4()),
            'name': 'TsCalculation',
            'xsi:type': 'utility-4115fa00-5f3c-11df-8a53-001c233b3528'
        })

        formula = ET.SubElement(test_step, 'FORMULA', {'xsi:type': 'binaryOpBaseExpression'})
        ET.SubElement(formula, 'NAME', {'xsi:type': 'string'}).text = 'BINARY_SUBSCR'

        first_component = ET.SubElement(formula, 'FIRST-COMPONENT', {'xsi:type': 'binaryOpBaseExpression'})
        ET.SubElement(first_component, 'NAME', {'xsi:type': 'string'}).text = 'BINARY_SUBSCR'

        first_first_component = ET.SubElement(first_component, 'FIRST-COMPONENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(first_first_component, 'NAME', {'xsi:type': 'string'}).text = 'AllDataSignal_AfterReset_dict'

        first_second_component = ET.SubElement(first_component, 'SECOND-COMPONENT', {'xsi:type': 'functionBaseExpression'})
        component_min = ET.SubElement(first_second_component, 'COMPONENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(component_min, 'NAME', {'xsi:type': 'string'}).text = 'min'

        arguments_min = ET.SubElement(first_second_component, 'ARGUMENTS')
        argument_keys = ET.SubElement(arguments_min, 'ARGUMENT', {'xsi:type': 'functionBaseExpression'})
        component_keys = ET.SubElement(argument_keys, 'COMPONENT', {'xsi:type': 'attributeBaseExpression'})
        component_var = ET.SubElement(component_keys, 'COMPONENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(component_var, 'NAME', {'xsi:type': 'string'}).text = 'AllDataSignal_AfterReset_dict'
        ET.SubElement(component_keys, 'ATTR-NAME', {'xsi:type': 'string'}).text = 'keys'

        second_component = ET.SubElement(formula, 'SECOND-COMPONENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(second_component, 'NAME', {'xsi:type': 'string'}).text = varSignal

        expectation = ET.SubElement(test_step, 'EXPECTATION-OPTION', {'xsi:type': 'timelessOption'})
        expression = ET.SubElement(expectation, 'EXPRESSION', {'xsi:type': 'builtNumericExpression'})
        ET.SubElement(expression, 'RELATION', {'xsi:type': 'string'}).text = '=='

        value = ET.SubElement(expression, 'VALUE', {'xsi:type': 'functionBaseExpression'})
        component_int = ET.SubElement(value, 'COMPONENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(component_int, 'NAME', {'xsi:type': 'string'}).text = 'int'

        arguments_int = ET.SubElement(value, 'ARGUMENTS')
        argument1 = ET.SubElement(arguments_int, 'ARGUMENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(argument1, 'NAME', {'xsi:type': 'string'}).text = varExpectedSignalValue
        argument2 = ET.SubElement(arguments_int, 'ARGUMENT', {'format-rev': '2', 'xsi:type': 'valueBaseExpression'})
        ET.SubElement(argument2, 'VALUE', {'xsi:type': 'integer'}).text = '16'

        ET.SubElement(test_step, 'INSTANCE-NAME', {'xsi:type': 'string'}).text = 'Get init value of signal in trace'

    def GenXML_CheckCRC(self,parent, varMsg):
        # Generate a TESTSTEP that calls the COM_EvaluateChecksum mapping job
        test_step = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })

        ET.SubElement(test_step, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'COM_EvaluateChecksum'

        if 'COM_EvaluateChecksum' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('COM_EvaluateChecksum')

        param_assignments = ET.SubElement(test_step, 'PARAM-ASSIGNMENTS')

        assignment = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_MessageName'})
        self.LibraryManager.Helpers_Lib.add_argument_assignment_convertHexStringToInt(assignment, varMsg)

        self.LibraryManager.Helpers_Lib.add_parameter_assignment(
            param_assignments, 'P_NbrOfMsg', '16', 'valueBaseExpression',value_type='integer'
        )

        ET.SubElement(test_step, 'ALTERNATIVE-MAPPING-SPACE', {
            'format-rev': '1',
            'xsi:type': 'mappingSpace'
        })

    def GenXML_ControlAliveCounter(self, parent,varMsg , varStatusAliveCounter):
        # Generate a TESTSTEP that calls the COM_ControlCounter mapping job
        test_step = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })

        ET.SubElement(test_step, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'COM_ControlCounter'

        if 'COM_ControlCounter' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('COM_ControlCounter')

        param_assignments = ET.SubElement(test_step, 'PARAM-ASSIGNMENTS')

        self.LibraryManager.Helpers_Lib.add_parameter_assignment(
            param_assignments, 'P_ControlType', varStatusAliveCounter, 'varBaseExpression'
        )
        assignment = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_MessageName'})
        self.LibraryManager.Helpers_Lib.add_argument_assignment_convertHexStringToInt(assignment, varMsg)

        ET.SubElement(test_step, 'ALTERNATIVE-MAPPING-SPACE', {
            'format-rev': '1',
            'xsi:type': 'mappingSpace'
        })

    def GenXML_CheckAliveCounter(self, parent, varMsg, varSignal):
        
        step = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })

        ET.SubElement(step, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'COM_EvaluateCounter'
        if 'COM_EvaluateCounter' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('COM_EvaluateCounter')

        param_assignments = ET.SubElement(step, 'PARAM-ASSIGNMENTS')

        assignment = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_MessageName'})
        self.LibraryManager.Helpers_Lib.add_argument_assignment_convertHexStringToInt(assignment, varMsg)

        self.LibraryManager.Helpers_Lib.add_parameter_assignment(
            param_assignments, 'P_NbrOfMsg', "10", 'valueBaseExpression', value_type='integer')
        self.LibraryManager.Helpers_Lib.add_parameter_assignment(
            param_assignments, 'P_SignalName', varSignal, 'varBaseExpression')

        ET.SubElement(step, 'ALTERNATIVE-MAPPING-SPACE', {
            'format-rev': '1',
            'xsi:type': 'mappingSpace'
        })

    def GenXML_COM_SetDLC(self, parent, varMsg, varDLCValue):
        # Generate a TESTSTEP that calls the COM_SetDataLength mapping job
        test_step = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })

        ET.SubElement(test_step, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'COM_SetDataLength'

        if 'COM_SetDataLength' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('COM_SetDataLength')

        param_assignments = ET.SubElement(test_step, 'PARAM-ASSIGNMENTS')

        self.LibraryManager.Helpers_Lib.add_parameter_assignment(
            param_assignments, 'P_DataLength', varDLCValue, 'varBaseExpression'
        )
        assignment = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_MessageName'})
        self.LibraryManager.Helpers_Lib.add_argument_assignment_convertHexStringToInt(assignment, varMsg)

        ET.SubElement(test_step, 'ALTERNATIVE-MAPPING-SPACE', {
            'format-rev': '1',
            'xsi:type': 'mappingSpace'
        })

    def GenXML_CheckDLC(self, parent, varMsg, varExpectDLC):
        # Generate a TESTSTEP that calls the COM_GetDataLength mapping job
        test_step = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })

        ET.SubElement(test_step, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'COM_GetDataLength'

        if 'COM_GetDataLength' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('COM_GetDataLength')

        var_refs = ET.SubElement(test_step, 'VARIABLE-REFS')
        var_name = ET.SubElement(var_refs, 'VARIABLE-NAME', {'dkey': 'R_datalength'})
        ET.SubElement(var_name, 'DVALUE', {'xsi:type': 'string'}).text = "dlcValue"

        param_assignments = ET.SubElement(test_step, 'PARAM-ASSIGNMENTS')

        assignment = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_MessageName'})
        self.LibraryManager.Helpers_Lib.add_argument_assignment_convertHexStringToInt(assignment, varMsg)

        ET.SubElement(test_step, 'ALTERNATIVE-MAPPING-SPACE', {
            'format-rev': '1',
            'xsi:type': 'mappingSpace'
        })

        # Generate a TESTSTEP for comparing two DLC values using TsCalculation
        test_step2 = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '3',
            'id': str(uuid.uuid4()),
            'name': 'TsCalculation',
            'xsi:type': 'utility-4115fa00-5f3c-11df-8a53-001c233b3528'
        })

        formula = ET.SubElement(test_step2, 'FORMULA', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(formula, 'NAME', {'xsi:type': 'string'}).text = "dlcValue"

        expectation = ET.SubElement(test_step2, 'EXPECTATION-OPTION', {'xsi:type': 'timelessOption'})
        expr = ET.SubElement(expectation, 'EXPRESSION', {'xsi:type': 'builtNumericExpression'})
        ET.SubElement(expr, 'RELATION', {'xsi:type': 'string'}).text = '=='

        value = ET.SubElement(expr, 'VALUE', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(value, 'NAME', {'xsi:type': 'string'}).text = varExpectDLC

        ET.SubElement(test_step2, 'INSTANCE-NAME', {'xsi:type': 'string'}).text = 'Evaluate the data length of message'
    
    def GenXML_ReadCurrentValueDID(self, parent, varDID):
        # Generate the Diag request job
        self.LibraryManager.EDR_Lib.GenXML_Diag_Request_Binary_Add(parent,['22',varDID],['62',varDID], var_Result='dataDID')

        # Generate the step to split the data response 
        teststep = ET.SubElement(parent, 'TESTSTEP', {
        'format-rev': '3',
        'id': str(uuid.uuid4()),
        'name': 'TsCalculation',
        'xsi:type': 'utility-4115fa00-5f3c-11df-8a53-001c233b3528'
        })

        var_refs = ET.SubElement(teststep, 'VARIABLE-REFS')
        var_name = ET.SubElement(var_refs, 'VARIABLE-NAME', {'dkey': 'default'})
        dvalue = ET.SubElement(var_name, 'DVALUE', {'xsi:type': 'string'})
        dvalue.text = 'dataDID'

        formula = ET.SubElement(teststep, 'FORMULA', {'xsi:type': 'sliceBaseExpression'})

        component = ET.SubElement(formula, 'COMPONENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(component, 'NAME', {'xsi:type': 'string'}).text = 'dataDID'

        start = ET.SubElement(formula, 'START', {'format-rev': '2', 'xsi:type': 'valueBaseExpression'})
        ET.SubElement(start, 'VALUE', {'xsi:type': 'integer'}).text = '9'

        ET.SubElement(teststep, 'INSTANCE-NAME', {'xsi:type': 'string'}).text = 'Get data from response'

    def GenXML_WriteCurrentValueDID(self, parent, varDID):
        # Generate the Diag request job
        self.LibraryManager.EDR_Lib.GenXML_Diag_Request_Binary_Add(parent,['2E',varDID,'dataDID'],['6E',varDID])

    def GenXML_WriteDID_with_ByteBit(self, parent, varDID, varByte, varBit, varBitValue):
        teststep = ET.SubElement(parent, 'TESTSTEP', {
        'format-rev': '3',
        'id': str(uuid.uuid4()),
        'name': 'TsCalculation',
        'xsi:type': 'utility-4115fa00-5f3c-11df-8a53-001c233b3528'
        })

        var_refs = ET.SubElement(teststep, 'VARIABLE-REFS')
        var_name = ET.SubElement(var_refs, 'VARIABLE-NAME', {'dkey': 'default'})
        ET.SubElement(var_name, 'DVALUE', {'xsi:type': 'string'}).text = 'dataWrite'

        formula = ET.SubElement(teststep, 'FORMULA', {'xsi:type': 'functionBaseExpression'})

        component = ET.SubElement(formula, 'COMPONENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(component, 'NAME', {'xsi:type': 'string'}).text = 'Func_Change_DIDData_In_ByteBit_Position'

        arguments = ET.SubElement(formula, 'ARGUMENTS')
        for arg in ['dataDID', varByte, varBit, varBitValue]:
            arg_elem = ET.SubElement(arguments, 'ARGUMENT', {'xsi:type': 'varBaseExpression'})
            ET.SubElement(arg_elem, 'NAME', {'xsi:type': 'string'}).text = arg

        ET.SubElement(teststep, 'INSTANCE-NAME', {'xsi:type': 'string'}).text = 'Prepare the data value to write DID at correct the Byte and Bit'

        # Generate the Diag request job
        self.LibraryManager.EDR_Lib.GenXML_Diag_Request_Binary_Add(parent,['2E',varDID,'dataWrite'],['6E',varDID])

    def GenXML_WriteNVM_with_Byte(self, parent, varNvm,varDataNvm,varByte):
        teststep = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })

        ET.SubElement(teststep, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'PSDIAG_Read_ECU_NVM'
        if 'PSDIAG_Read_ECU_NVM' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('PSDIAG_Read_ECU_NVM')

        var_refs = ET.SubElement(teststep, 'VARIABLE-REFS')
        var_name = ET.SubElement(var_refs, 'VARIABLE-NAME', {'dkey': 'R_result'})
        ET.SubElement(var_name, 'DVALUE', {'xsi:type': 'string'}).text = 'dataNvm'

        param_assign = ET.SubElement(teststep, 'PARAM-ASSIGNMENTS')
        assignment = ET.SubElement(param_assign, 'ASSIGNMENT', {'dkey': 'P_nvmConfigDict'})
        dvalue = ET.SubElement(assignment, 'DVALUE', {'xsi:type': 'dictBaseExpression'})
        expr_dict = ET.SubElement(dvalue, 'EXPRESSION-DICT')
        item = ET.SubElement(expr_dict, 'ITEM', {'xsi:type': 'expressionDictItem'})

        key = ET.SubElement(item, 'KEY', {
            'format-rev': '2',
            'xsi:type': 'valueBaseExpression'
        })
        ET.SubElement(key, 'VALUE', {'xsi:type': 'string'}).text = 'block_name'

        val = ET.SubElement(item, 'VALUE', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(val, 'NAME', {'xsi:type': 'string'}).text = varNvm

        ET.SubElement(teststep, 'ALTERNATIVE-MAPPING-SPACE', {
            'format-rev': '1',
            'xsi:type': 'mappingSpace'
        })   

        teststep1 = ET.SubElement(parent, 'TESTSTEP', {
        'format-rev': '3',
        'id': str(uuid.uuid4()),
        'name': 'TsCalculation',
        'xsi:type': 'utility-4115fa00-5f3c-11df-8a53-001c233b3528'
        })
        # Variable Reference Assignment
        variable_refs = ET.SubElement(teststep1, 'VARIABLE-REFS')
        variable_name = ET.SubElement(variable_refs, 'VARIABLE-NAME', {'dkey': 'default'})
        dvalue = ET.SubElement(variable_name, 'DVALUE', {'xsi:type': 'string'})
        dvalue.text = 'dataNvm[Byte]'

        # Formula
        formula = ET.SubElement(teststep1, 'FORMULA', {'xsi:type': 'functionBaseExpression'})

        component = ET.SubElement(formula, 'COMPONENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(component, 'NAME', {'xsi:type': 'string'}).text = 'int'

        arguments = ET.SubElement(formula, 'ARGUMENTS')

        # First argument (variable)
        arg1 = ET.SubElement(arguments, 'ARGUMENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(arg1, 'NAME', {'xsi:type': 'string'}).text = varDataNvm

        # Second argument (integer value)
        arg2 = ET.SubElement(arguments, 'ARGUMENT', {
            'format-rev': '2',
            'xsi:type': 'valueBaseExpression'
        })
        ET.SubElement(arg2, 'VALUE', {'xsi:type': 'integer'}).text = '16'

        ET.SubElement(teststep1, 'INSTANCE-NAME', {'xsi:type': 'string'}).text = 'Chang NVM data at byte position'

        if 'PSDIAG_Write_ECU_NVM' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('PSDIAG_Write_ECU_NVM')

        teststep = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })

        ET.SubElement(teststep, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'PSDIAG_Write_ECU_NVM'
        if 'PSDIAG_Write_ECU_NVM' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('PSDIAG_Write_ECU_NVM')

        param_assignments = ET.SubElement(teststep, 'PARAM-ASSIGNMENTS')

        # P_nvmConfigDict assignment
        assignment_dict = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_nvmConfigDict'})
        dvalue_dict = ET.SubElement(assignment_dict, 'DVALUE', {'xsi:type': 'dictBaseExpression'})
        expr_dict = ET.SubElement(dvalue_dict, 'EXPRESSION-DICT')
        item = ET.SubElement(expr_dict, 'ITEM', {'xsi:type': 'expressionDictItem'})

        key = ET.SubElement(item, 'KEY', {'format-rev': '2', 'xsi:type': 'valueBaseExpression'})
        ET.SubElement(key, 'VALUE', {'xsi:type': 'string'}).text = 'block_name'

        value = ET.SubElement(item, 'VALUE', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(value, 'NAME', {'xsi:type': 'string'}).text = varNvm

        # P_nvmMemoryContentsList assignment
        assignment_mem = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_nvmMemoryContentsList'})
        dvalue_mem = ET.SubElement(assignment_mem, 'DVALUE', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(dvalue_mem, 'NAME', {'xsi:type': 'string'}).text = "dataNvm"

        # Alternative mapping
        ET.SubElement(teststep, 'ALTERNATIVE-MAPPING-SPACE', {
            'format-rev': '1',
            'xsi:type': 'mappingSpace'
        })


class EDR_Library_GenXMLTestStep(ShareBase):

    def __init__(self,LibraryManager:'LibraryManager'):
        self.LibraryManager:'LibraryManager' = LibraryManager

    def GenXML_EDR_Initialize(self,parent):

        teststep1 = ET.SubElement(parent, "TESTSTEP", attrib={
        "format-rev": "1",
        "id": str(uuid.uuid4()),
        "xsi:type": "tsPackageCall"
        })

        ET.SubElement(teststep1, "MAPPING-REF", attrib={"xsi:type": "string"}).text = "PSDIAG_Read_Memory"
        if 'PSDIAG_Read_Memory' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('PSDIAG_Read_Memory')

        # VARIABLE-REFS
        var_refs = ET.SubElement(teststep1, "VARIABLE-REFS")
        var_name = ET.SubElement(var_refs, "VARIABLE-NAME", attrib={"dkey": "R_result"})
        ET.SubElement(var_name, "DVALUE", attrib={"xsi:type": "string"}).text = "edr_expected_init_value"

        # PARAM-ASSIGNMENTS
        param_assign = ET.SubElement(teststep1, "PARAM-ASSIGNMENTS")

        assign1 = ET.SubElement(param_assign, "ASSIGNMENT", attrib={"dkey": "P_labelOrAddress"})
        dval1 = ET.SubElement(assign1, "DVALUE", attrib={"format-rev": "2", "xsi:type": "valueBaseExpression"})
        ET.SubElement(dval1, "VALUE", attrib={"xsi:type": "string"}).text = 'rb_dcbm_FirstStartUpIndication_u16'

        assign2 = ET.SubElement(param_assign, "ASSIGNMENT", attrib={"dkey": "P_memoryContentsAsInteger"})
        dval2 = ET.SubElement(assign2, "DVALUE", attrib={"format-rev": "2", "xsi:type": "valueBaseExpression"})
        ET.SubElement(dval2, "VALUE", attrib={"xsi:type": "boolean"}).text = 'True'

        # ALTERNATIVE-MAPPING-SPACE
        ET.SubElement(teststep1, "ALTERNATIVE-MAPPING-SPACE", attrib={
            "format-rev": "1",
            "xsi:type": "mappingSpace"
        })

        """Generate a TsIfThenElse test step with a conditional check and block action"""
        else_step1 = ET.SubElement(parent, 'TESTSTEP', {
            'id': str(uuid.uuid4()),
            'name': 'TsIfThenElse',
            'xsi:type': 'utility-3609c41e-4fef-11dc-899a-0013728784ee'
        })

        # CONDITION
        condition = ET.SubElement(else_step1, 'CONDITION', {'xsi:type': 'andBaseExpression'})

        # FIRST-COMPONENT (is not)
        first_cmp = ET.SubElement(condition, 'FIRST-COMPONENT', {'xsi:type': 'compareOpBaseExpression'})
        ET.SubElement(first_cmp, 'NAME', {'xsi:type': 'string'}).text = 'is not'
        first_var = ET.SubElement(first_cmp, 'FIRST-COMPONENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(first_var, 'NAME', {'xsi:type': 'string'}).text = 'edr_expected_init_value'
        ET.SubElement(first_cmp, 'SECOND-COMPONENT', {
            'format-rev': '2',
            'xsi:type': 'valueBaseExpression'
        })

        # SECOND-COMPONENT (!= 0x5555)
        second_cmp = ET.SubElement(condition, 'SECOND-COMPONENT', {'xsi:type': 'compareOpBaseExpression'})
        ET.SubElement(second_cmp, 'NAME', {'xsi:type': 'string'}).text = '!='
        second_first = ET.SubElement(second_cmp, 'FIRST-COMPONENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(second_first, 'NAME', {'xsi:type': 'string'}).text = 'edr_expected_init_value'
        second_value = ET.SubElement(second_cmp, 'SECOND-COMPONENT', {
            'format-rev': '2',
            'xsi:type': 'valueBaseExpression'
        })
        ET.SubElement(second_value, 'VALUE', {'xsi:type': 'integer'}).text = '0x5555'

        # THEN block
        then_block = ET.SubElement(else_step1, 'THEN', {
            'id': str(uuid.uuid4()),
            'xsi:type': 'ifThenElseNode'
        })

        block_step = ET.SubElement(then_block, 'TESTSTEP', {
            'format-rev': '3',
            'id': str(uuid.uuid4()),
            'name': 'TsBlock',
            'xsi:type': 'utility-2752ad1e-4fef-11dc-81d4-0013728784ee'
        })

        # ACTION       
        self.LibraryManager.Helpers_Lib.add_action_element(block_step,'Set Plant Mode')

        """Generate a GEN_SetEcuMode test step with P_EcuMode and P_EcuState assignments"""
        test_step_else = ET.SubElement(block_step, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })

        # MAPPING-REF
        ET.SubElement(test_step_else, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'GEN_SetEcuMode'

        # PARAM-ASSIGNMENTS
        param_assignments = ET.SubElement(test_step_else, 'PARAM-ASSIGNMENTS')

        # P_EcuMode assignment
        assignment_mode = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_EcuMode'})
        dvalue_mode = ET.SubElement(assignment_mode, 'DVALUE', {
            'format-rev': '2',
            'xsi:type': 'valueBaseExpression'
        })
        ET.SubElement(dvalue_mode, 'VALUE', {'xsi:type': 'string'}).text = 'Productionmode'

        # P_EcuState assignment
        assignment_state = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_EcuState'})
        dvalue_state = ET.SubElement(assignment_state, 'DVALUE', {
            'format-rev': '2',
            'xsi:type': 'valueBaseExpression'
        })
        ET.SubElement(dvalue_state, 'VALUE', {'xsi:type': 'string'}).text = 'Set'

        # ALTERNATIVE-MAPPING-SPACE
        ET.SubElement(test_step_else, 'ALTERNATIVE-MAPPING-SPACE', {
            'format-rev': '1',
            'xsi:type': 'mappingSpace'
        })

        # Optional: update mapping list
        if 'GEN_SetEcuMode' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('GEN_SetEcuMode')

        """Generate a TsBlock with action 'Wait until EDR initialize' and wait 6000ms"""
        testStep2 = ET.SubElement(then_block, 'TESTSTEP', {
            'format-rev': '3',
            'id': str(uuid.uuid4()),
            'name': 'TsBlock',
            'xsi:type': 'utility-2752ad1e-4fef-11dc-81d4-0013728784ee'
        })

        # ACTION block
        self.LibraryManager.Helpers_Lib.add_action_element(testStep2,'Wait until EDR initialize')

        # Nested TESTSTEP: GEN_wait_ms
        wait_step = ET.SubElement(testStep2, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })

        ET.SubElement(wait_step, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'GEN_wait_ms'

        param_assignments = ET.SubElement(wait_step, 'PARAM-ASSIGNMENTS')
        wait_assignment = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_waitTime'})
        dvalue = ET.SubElement(wait_assignment, 'DVALUE', {
            'format-rev': '2',
            'xsi:type': 'valueBaseExpression'
        })
        ET.SubElement(dvalue, 'VALUE', {'xsi:type': 'integer'}).text = '6000'

        ET.SubElement(wait_step, 'ALTERNATIVE-MAPPING-SPACE', {
            'format-rev': '1',
            'xsi:type': 'mappingSpace'
        })

        if 'GEN_wait_ms' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('GEN_wait_ms')

        """Generate a TsBlock to remove Plant Mode and wait 6000ms"""
        testStep3 = ET.SubElement(then_block, 'TESTSTEP', {
            'format-rev': '3',
            'id': str(uuid.uuid4()),
            'name': 'TsBlock',
            'xsi:type': 'utility-2752ad1e-4fef-11dc-81d4-0013728784ee'
        })

        # ACTION: Remove Plant Mode
        self.LibraryManager.Helpers_Lib.add_action_element(testStep3,'Remove Plant Mode')      

        # First TESTSTEP: GEN_SetEcuMode with "Remove"
        step_set_mode = ET.SubElement(testStep3, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })
        ET.SubElement(step_set_mode, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'GEN_SetEcuMode'
        param_assignments1 = ET.SubElement(step_set_mode, 'PARAM-ASSIGNMENTS')

        assign_mode = ET.SubElement(param_assignments1, 'ASSIGNMENT', {'dkey': 'P_EcuMode'})
        dvalue_mode = ET.SubElement(assign_mode, 'DVALUE', {
            'format-rev': '2',
            'xsi:type': 'valueBaseExpression'
        })
        ET.SubElement(dvalue_mode, 'VALUE', {'xsi:type': 'string'}).text = 'Productionmode'

        assign_state = ET.SubElement(param_assignments1, 'ASSIGNMENT', {'dkey': 'P_EcuState'})
        dvalue_state = ET.SubElement(assign_state, 'DVALUE', {
            'format-rev': '2',
            'xsi:type': 'valueBaseExpression'
        })
        ET.SubElement(dvalue_state, 'VALUE', {'xsi:type': 'string'}).text = 'Remove'

        ET.SubElement(step_set_mode, 'ALTERNATIVE-MAPPING-SPACE', {
            'format-rev': '1',
            'xsi:type': 'mappingSpace'
        })

        # Second TESTSTEP: GEN_wait_ms with 6000ms
        step_wait = ET.SubElement(testStep3, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })
        ET.SubElement(step_wait, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'GEN_wait_ms'
        param_assignments2 = ET.SubElement(step_wait, 'PARAM-ASSIGNMENTS')
        assign_wait = ET.SubElement(param_assignments2, 'ASSIGNMENT', {'dkey': 'P_waitTime'})
        dvalue_wait = ET.SubElement(assign_wait, 'DVALUE', {
            'format-rev': '2',
            'xsi:type': 'valueBaseExpression'
        })
        ET.SubElement(dvalue_wait, 'VALUE', {'xsi:type': 'integer'}).text = '6000'

        ET.SubElement(step_wait, 'ALTERNATIVE-MAPPING-SPACE', {
            'format-rev': '1',
            'xsi:type': 'mappingSpace'
        })

        """Generate Check EDR initialize"""
        testStep4 = ET.SubElement(then_block, 'TESTSTEP', {
            'format-rev': '3',
            'id': str(uuid.uuid4()),
            'name': 'TsBlock',
            'xsi:type': 'utility-2752ad1e-4fef-11dc-81d4-0013728784ee'
        })

        # ACTION: Check again EDR initialize
        self.LibraryManager.Helpers_Lib.add_action_element(testStep4,'Check again EDR initialize')

        # First TESTSTEP: PSDIAG_Read_Memory 
        step_set_mode = ET.SubElement(testStep4, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })
        ET.SubElement(step_set_mode, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'PSDIAG_Read_Memory'
        
        #Add Job in to the list to add path 
        if 'PSDIAG_Read_Memory' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('PSDIAG_Read_Memory')

        param_assignments1 = ET.SubElement(step_set_mode, 'PARAM-ASSIGNMENTS')

        # VARIABLE-REFS
        variable_refs = ET.SubElement(step_set_mode, 'VARIABLE-REFS')
        variable_name = ET.SubElement(variable_refs, 'VARIABLE-NAME', {'dkey': 'R_result'})
        ET.SubElement(variable_name, 'DVALUE', {'xsi:type': 'string'}).text = 'edr_expected_init_value'

        # PARAM-ASSIGNMENTS
        param_assignments = ET.SubElement(step_set_mode, 'PARAM-ASSIGNMENTS')

        # P_labelOrAddress
        assign_label = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_labelOrAddress'})
        dvalue_label = ET.SubElement(assign_label, 'DVALUE', {
            'format-rev': '2',
            'xsi:type': 'valueBaseExpression'
        })
        ET.SubElement(dvalue_label, 'VALUE', {'xsi:type': 'string'}).text = 'rb_dcbm_FirstStartUpIndication_u16'

        # P_memoryContentsAsInteger
        assign_mem = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_memoryContentsAsInteger'})
        dvalue_mem = ET.SubElement(assign_mem, 'DVALUE', {
            'format-rev': '2',
            'xsi:type': 'valueBaseExpression'
        })
        ET.SubElement(dvalue_mem, 'VALUE', {'xsi:type': 'boolean'}).text = 'True'

        # ALTERNATIVE-MAPPING-SPACE
        ET.SubElement(step_set_mode, 'ALTERNATIVE-MAPPING-SPACE', {
            'format-rev': '1',
            'xsi:type': 'mappingSpace'
        })

        """Generate If-Then-Else condition to check edr_expected_init_value != 0x5555 and is not empty"""
        stepcheck = ET.SubElement(testStep4, 'TESTSTEP', {
            'id': str(uuid.uuid4()),
            'name': 'TsIfThenElse',
            'xsi:type': 'utility-3609c41e-4fef-11dc-899a-0013728784ee'
        })

        # CONDITION block
        condition = ET.SubElement(stepcheck, 'CONDITION', {'xsi:type': 'andBaseExpression'})

        # First comparison: is not (empty)
        first_cmp = ET.SubElement(condition, 'FIRST-COMPONENT', {'xsi:type': 'compareOpBaseExpression'})
        ET.SubElement(first_cmp, 'NAME', {'xsi:type': 'string'}).text = 'is not'
        first_var = ET.SubElement(first_cmp, 'FIRST-COMPONENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(first_var, 'NAME', {'xsi:type': 'string'}).text = 'edr_expected_init_value'
        ET.SubElement(first_cmp, 'SECOND-COMPONENT', {
            'format-rev': '2',
            'xsi:type': 'valueBaseExpression'
        })

        # Second comparison: != 0x5555
        second_cmp = ET.SubElement(condition, 'SECOND-COMPONENT', {'xsi:type': 'compareOpBaseExpression'})
        ET.SubElement(second_cmp, 'NAME', {'xsi:type': 'string'}).text = '!='
        second_var = ET.SubElement(second_cmp, 'FIRST-COMPONENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(second_var, 'NAME', {'xsi:type': 'string'}).text = 'edr_expected_init_value'
        second_val = ET.SubElement(second_cmp, 'SECOND-COMPONENT', {
            'format-rev': '2',
            'xsi:type': 'valueBaseExpression'
        })
        ET.SubElement(second_val, 'VALUE', {'xsi:type': 'integer'}).text = '0x5555'

        # THEN block (TsExit)
        then = ET.SubElement(stepcheck, 'THEN', {
            'id': str(uuid.uuid4()),
            'xsi:type': 'ifThenElseNode'
        })

        ts_exit = ET.SubElement(then, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'name': 'TsExit',
            'xsi:type': 'utility-c6aa4f70-f037-11dc-9d16-001b24fa84be'
        })
        ET.SubElement(ts_exit, 'EXIT-RESULT', {'xsi:type': 'string'}).text = 'ERROR'
        ET.SubElement(ts_exit, 'ABORT', {'xsi:type': 'boolean'}).text = 'True'
        comment_expr = ET.SubElement(ts_exit, 'COMMENT-EXPR', {
            'format-rev': '2',
            'xsi:type': 'valueBaseExpression'
        })
        ET.SubElement(comment_expr, 'VALUE', {'xsi:type': 'string'}).text = 'Abort test'

        # ELSE block (empty)
        ET.SubElement(stepcheck, 'ELSE', {
            'id': str(uuid.uuid4()),
            'xsi:type': 'ifThenElseNode'
        })

        # ELSE block (empty)
        ET.SubElement(else_step1, 'ELSE', {
            'id': str(uuid.uuid4()),
            'xsi:type': 'ifThenElseNode'
        })

        # ELSE block (empty)
        ET.SubElement(else_step1, 'ELSE', {
            'id': str(uuid.uuid4()),
            'xsi:type': 'ifThenElseNode'
        })

    def GenXML_EDR_InjectSimulation_Crash(self,parent, varValueTypeCrash):
        # Outer TESTSTEP (TsBlock)
        subStep1 = ET.SubElement(parent,"TESTSTEP", {
            "format-rev": "3",
            "id": str(uuid.uuid4()),
            "name": "TsBlock",
            "xsi:type": "utility-2752ad1e-4fef-11dc-81d4-0013728784ee"
        })

        # ACTION
        self.LibraryManager.Helpers_Lib.add_action_element(subStep1,"Input the type of crash")

        # Inner TESTSTEP (tsPackageCall)
        inner_step = ET.SubElement(subStep1, "TESTSTEP", {
            "format-rev": "1",
            "id": str(uuid.uuid4()),
            "xsi:type": "tsPackageCall"
        })

        ET.SubElement(inner_step, "MAPPING-REF", {"xsi:type": "string"}).text = "PSDIAG_Write_Memory"
        if 'PSDIAG_Write_Memory' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('PSDIAG_Write_Memory')
        
        # PARAM-ASSIGNMENTS
        param_assign = ET.SubElement(inner_step, "PARAM-ASSIGNMENTS")

        # Assignment 1
        assign1 = ET.SubElement(param_assign, "ASSIGNMENT", {"dkey": "P_labelOrAddress"})
        dval1 = ET.SubElement(assign1, "DVALUE", {"format-rev": "2", "xsi:type": "valueBaseExpression"})
        val1 = ET.SubElement(dval1, "VALUE", {"xsi:type": "string"})
        val1.text = "rb_evmt_InputSelection_u8"

        # Assignment 2
        assign2 = ET.SubElement(param_assign, "ASSIGNMENT", {"dkey": "P_memoryContents"})
        dval2 = ET.SubElement(assign2, "DVALUE", {"xsi:type": "varBaseExpression"})
        name = ET.SubElement(dval2, "NAME", {"xsi:type": "string"})
        name.text = varValueTypeCrash

        # ALTERNATIVE-MAPPING-SPACE
        ET.SubElement(inner_step, "ALTERNATIVE-MAPPING-SPACE", {
            "format-rev": "1",
            "xsi:type": "mappingSpace"
        })


        # TsBlock wrapper
        subStep2 = ET.SubElement(parent,"TESTSTEP", {
            'format-rev': '3',
            'id': str(uuid.uuid4()),
            'name': 'TsBlock',
            'xsi:type': 'utility-2752ad1e-4fef-11dc-81d4-0013728784ee'
        })

        # ACTION
        self.LibraryManager.Helpers_Lib.add_action_element(subStep2,"Trigger the crash")

        # tsPackageCall step
        inner_step = ET.SubElement(subStep2, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })
        ET.SubElement(inner_step, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'PSDIAG_Write_Memory'
        param_assignments = ET.SubElement(inner_step, 'PARAM-ASSIGNMENTS')

        self.LibraryManager.Helpers_Lib.add_parameter_assignment(param_assignments, 'P_labelOrAddress', 'rb_evmt_CrashSimulationTrigger_u8','valueBaseExpression')
        self.LibraryManager.Helpers_Lib.add_parameter_assignment(param_assignments, 'P_memoryContents', '1', 'valueBaseExpression', value_type='integer')

        ET.SubElement(inner_step, 'ALTERNATIVE-MAPPING-SPACE', {
            'format-rev': '1',
            'xsi:type': 'mappingSpace'
        })

        # GenXML loop check
        subStep3 = ET.SubElement(parent,"TESTSTEP", {
        "id": str(uuid.uuid4()),
        "name": "TsLoop",
        "xsi:type": "utility-3da58cf0-4fef-11dc-be56-0013728784ee"
        })

        # First inner TESTSTEP - PSDIAG_Read_Memory
        ts1 = ET.SubElement(subStep3, "TESTSTEP", {
            "format-rev": "1",
            "id": str(uuid.uuid4()),
            "xsi:type": "tsPackageCall"
        })
        ET.SubElement(ts1, "MAPPING-REF", {"xsi:type": "string"}).text = "PSDIAG_Read_Memory"
        if 'PSDIAG_Read_Memory' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('PSDIAG_Read_Memory')

        var_refs = ET.SubElement(ts1, "VARIABLE-REFS")
        var_name = ET.SubElement(var_refs, "VARIABLE-NAME", {"dkey": "R_result"})
        ET.SubElement(var_name, "DVALUE", {"xsi:type": "string"}).text = "statusTrigger"

        param_assign1 = ET.SubElement(ts1, "PARAM-ASSIGNMENTS")

        self.LibraryManager.Helpers_Lib.add_parameter_assignment(param_assign1, 'P_labelOrAddress', 'rb_dcrm_StateOfDCS_en','valueBaseExpression')
        self.LibraryManager.Helpers_Lib.add_parameter_assignment(param_assign1, 'P_memoryContentsAsInteger', 'True','valueBaseExpression', value_type="boolean")

        ET.SubElement(ts1, "ALTERNATIVE-MAPPING-SPACE", {
            "format-rev": "1",
            "xsi:type": "mappingSpace"
        })

        self.LibraryManager.Diag_Lib.GenXML_GEN_wait_ms(subStep3,'1000')

        # LOOP-COUNT, START-VALUE, STEP-SIZE
        loop_count = ET.SubElement(subStep3, "LOOP-COUNT", {
            "format-rev": "2",
            "xsi:type": "valueBaseExpression"
        })
        ET.SubElement(loop_count, "VALUE", {"xsi:type": "integer"}).text = "30"

        start_value = ET.SubElement(subStep3, "START-VALUE", {
            "format-rev": "2",
            "xsi:type": "valueBaseExpression"
        })
        ET.SubElement(start_value, "VALUE", {"xsi:type": "integer"}).text = "0"

        step_size = ET.SubElement(subStep3, "STEP-SIZE", {
            "format-rev": "2",
            "xsi:type": "valueBaseExpression"
        })
        ET.SubElement(step_size, "VALUE", {"xsi:type": "integer"}).text = "1"

        # STOP-CONDITION
        stop_cond = ET.SubElement(subStep3, "STOP-CONDITION", {"xsi:type": "compareOpBaseExpression"})
        ET.SubElement(stop_cond, "NAME", {"xsi:type": "string"}).text = "=="
        first_comp = ET.SubElement(stop_cond, "FIRST-COMPONENT", {"xsi:type": "varBaseExpression"})
        ET.SubElement(first_comp, "NAME", {"xsi:type": "string"}).text = "statusTrigger"
        second_comp = ET.SubElement(stop_cond, "SECOND-COMPONENT", {
            "format-rev": "2",
            "xsi:type": "valueBaseExpression"
        })
        ET.SubElement(second_comp, "VALUE", {"xsi:type": "integer"}).text = "6"

    def GenXML_ReadNVM_Variable(self, parent, varNvmName,varExpectData, varByte, varLength):
        # Generate Read NVM variable
        teststep = ET.SubElement(parent,"TESTSTEP", {
        'format-rev': "1",
        'id': str(uuid.uuid4()),
        'xsi:type': "tsPackageCall"
        })

        # MAPPING-REF
        mapping_ref = ET.SubElement(teststep, "MAPPING-REF", {"xsi:type": "string"})
        mapping_ref.text = "PSDIAG_Read_ECU_NVM"
        if 'PSDIAG_Read_ECU_NVM' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('PSDIAG_Read_ECU_NVM')

        # VARIABLE-REFS
        var_refs = ET.SubElement(teststep, "VARIABLE-REFS")
        var_name = ET.SubElement(var_refs, "VARIABLE-NAME", {"dkey": "R_result"})
        dvalue = ET.SubElement(var_name, "DVALUE", {"xsi:type": "string"})
        dvalue.text = 'nvmValue'

        # PARAM-ASSIGNMENTS
        param_assign = ET.SubElement(teststep, "PARAM-ASSIGNMENTS")
        assignment = ET.SubElement(param_assign, "ASSIGNMENT", {"dkey": "P_nvmConfigDict"})
        dval = ET.SubElement(assignment, "DVALUE", {"xsi:type": "dictBaseExpression"})
        expr_dict = ET.SubElement(dval, "EXPRESSION-DICT")
        item = ET.SubElement(expr_dict, "ITEM", {"xsi:type": "expressionDictItem"})

        key = ET.SubElement(item, "KEY", {"format-rev": "2", "xsi:type": "valueBaseExpression"})
        key_val = ET.SubElement(key, "VALUE", {"xsi:type": "string"})
        key_val.text = "block_name"

        val = ET.SubElement(item, "VALUE", {'xsi:type': 'varBaseExpression'})
        val_val = ET.SubElement(val, "NAME", {"xsi:type": "string"})
        val_val.text = varNvmName

        # ALTERNATIVE-MAPPING-SPACE
        ET.SubElement(teststep, "ALTERNATIVE-MAPPING-SPACE", {
            "format-rev": "1",
            "xsi:type": "mappingSpace"
        })

        #Generate evaluate the NVM value
        ts_elem = ET.SubElement(parent,"TESTSTEP", {
        'format-rev': '3',
        'id': str(uuid.uuid4()),
        'name': 'TsCalculation',
        'xsi:type': 'utility-4115fa00-5f3c-11df-8a53-001c233b3528'
        })

        # FORMULA
        formula = ET.SubElement(ts_elem, 'FORMULA', {'xsi:type': 'functionBaseExpression'})
        str_component = ET.SubElement(formula, 'COMPONENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(str_component, 'NAME', {'xsi:type': 'string'}).text = 'str'

        args = ET.SubElement(formula, 'ARGUMENTS')
        argument = ET.SubElement(args, 'ARGUMENT', {'xsi:type': 'sliceBaseExpression'})

        component = ET.SubElement(argument, 'COMPONENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(component, 'NAME', {'xsi:type': 'string'}).text = 'nvmValue'

        start = ET.SubElement(argument, 'START', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(start, 'NAME', {'xsi:type': 'string'}).text = 'Byte'

        stop = ET.SubElement(argument, 'STOP', {'xsi:type': 'binaryOpBaseExpression'})
        ET.SubElement(stop, 'NAME', {'xsi:type': 'string'}).text = 'BINARY_ADD'
        first = ET.SubElement(stop, 'FIRST-COMPONENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(first, 'NAME', {'xsi:type': 'string'}).text = varByte
        second = ET.SubElement(stop, 'SECOND-COMPONENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(second, 'NAME', {'xsi:type': 'string'}).text = varLength

        # EXPECTATION-OPTION
        exp = ET.SubElement(ts_elem, 'EXPECTATION-OPTION', {'xsi:type': 'timelessOption'})
        expr = ET.SubElement(exp, 'EXPRESSION', {'xsi:type': 'builtStringExpression'})
        ET.SubElement(expr, 'CASE-SENSITIVE', {'xsi:type': 'boolean'}).text = 'False'
        base_expr = ET.SubElement(expr, 'BASE-EXPRESSION', {'xsi:type': 'functionBaseExpression'})
        base_comp = ET.SubElement(base_expr, 'COMPONENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(base_comp, 'NAME', {'xsi:type': 'string'}).text = 'str'
        args = ET.SubElement(base_expr, 'ARGUMENTS')
        arg = ET.SubElement(args, 'ARGUMENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(arg, 'NAME', {'xsi:type': 'string'}).text = varExpectData

        # INSTANCE-NAME
        ET.SubElement(ts_elem, 'INSTANCE-NAME', {'xsi:type': 'string'}).text = 'Evaluate the NVM value'

    def GenXML_Diag_Request_Binary_Add(self, parent, request_params: list,  response_params: list, var_Result='',mode ='relax'):
        diag_step = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })

        ET.SubElement(diag_step, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'DIAG_Request'
        if 'DIAG_Request' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('DIAG_Request')

        if var_Result != '':
            # VARIABLE-REFS
            variable_refs = ET.SubElement(diag_step, "VARIABLE-REFS")
            var_name = ET.SubElement(variable_refs, "VARIABLE-NAME", {"dkey": "R_detected_response"})
            ET.SubElement(var_name, "DVALUE", {"xsi:type": "string"}).text = var_Result

        param_assignments = ET.SubElement(diag_step, 'PARAM-ASSIGNMENTS')

        # === P_Mode ===
        self.LibraryManager.Helpers_Lib.add_parameter_assignment(param_assignments, 'P_Mode', mode, 'valueBaseExpression')

        # === P_expected_response ===
        response_expr = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_expected_response'})

        var_list = []
        def is_hex_number(s):
            # Check if s is a valid hex string (e.g. '2E', '16')
            try:
                int(s, 16)
                return True
            except ValueError:
                return False
        for var in response_params:
            if var.isdigit() or is_hex_number(var):
                var_list.append(('valueBaseExpression',var))
            else:
                var_list.append(('varBaseExpression',var))
            var_list.append(('valueBaseExpression', ' '))
        if var_list:            
            var_list.pop()

        dvalue = self.LibraryManager.Diag_Lib.build_binary_add_expression(var_list)
        response_expr.append(dvalue)

        # === P_request_data ===
        request_expr = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_request_data'})

        var_list = []
        for var in request_params:
            if var.isdigit() or is_hex_number(var):
                var_list.append(('valueBaseExpression',var))
            else:
                var_list.append(('varBaseExpression',var))
            var_list.append(('valueBaseExpression', ' '))
        if var_list:            
            var_list.pop()

        dvalue = self.LibraryManager.Diag_Lib.build_binary_add_expression(var_list)
        request_expr.append(dvalue)

        # === ALTERNATIVE-MAPPING-SPACE ===
        ET.SubElement(diag_step, 'ALTERNATIVE-MAPPING-SPACE', {
            'format-rev': '1',
            'xsi:type': 'mappingSpace'
        })

    def GenXML_ReadCrash_By_CD(self,parent,varDID, varExpectData_EDID , varPosition,varLength ):

        #Generate the test step send Diag service
        self.GenXML_Diag_Request_Binary_Add(parent,['22',varDID],['62',varDID], var_Result='crashData')

        # Generate the evaluate read crash data
        teststep = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '3',
            'id': str(uuid.uuid4()),
            'name': 'TsCalculation',
            'xsi:type': 'utility-4115fa00-5f3c-11df-8a53-001c233b3528'
        })

        formula = ET.SubElement(teststep, 'FORMULA', {'xsi:type': 'functionBaseExpression'})

        component = ET.SubElement(formula, 'COMPONENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(component, 'NAME', {'xsi:type': 'string'}).text = 'Func_EvaluateEdrCDData'

        arguments = ET.SubElement(formula, 'ARGUMENTS')
        for arg_name in ['crashData', varExpectData_EDID, varPosition, varLength]:
            argument = ET.SubElement(arguments, 'ARGUMENT', {'xsi:type': 'varBaseExpression'})
            ET.SubElement(argument, 'NAME', {'xsi:type': 'string'}).text = arg_name

        expectation_option = ET.SubElement(teststep, 'EXPECTATION-OPTION', {'xsi:type': 'timelessOption'})
        expression = ET.SubElement(expectation_option, 'EXPRESSION', {'xsi:type': 'builtNumericExpression'})
        ET.SubElement(expression, 'RELATION', {'xsi:type': 'string'}).text = '=='

        value = ET.SubElement(expression, 'VALUE', {
            'format-rev': '2',
            'xsi:type': 'valueBaseExpression'
        })
        ET.SubElement(value, 'VALUE', {'xsi:type': 'boolean'}).text = 'True'

        ET.SubElement(teststep, 'INSTANCE-NAME', {'xsi:type': 'string'}).text ='Evaluate the crash data in position with length'

    def GenXML_ReadCrash_By_PD(self, parent,varDID, varExpectData, varEDID,varExpectLength,varPosition):
        # Generate Get Report Folder
        teststep = ET.SubElement(parent, 'TESTSTEP', {
        'format-rev': '3',
        'id': str(uuid.uuid4()),
        'name': 'TsCalculation',
        'xsi:type': 'utility-4115fa00-5f3c-11df-8a53-001c233b3528'
        })

        # Create VARIABLE-REFS và VARIABLE-NAME
        var_refs = ET.SubElement(teststep, 'VARIABLE-REFS')
        var_name = ET.SubElement(var_refs, 'VARIABLE-NAME', {'dkey': 'default'})
        dvalue = ET.SubElement(var_name, 'DVALUE', {'xsi:type': 'string'})
        dvalue.text = 'reportPath'

        # Create FORMULA type functionBaseExpression
        formula = ET.SubElement(teststep, 'FORMULA', {'xsi:type': 'functionBaseExpression'})

        component = ET.SubElement(formula, 'COMPONENT', {'xsi:type': 'varBaseExpression'})
        name = ET.SubElement(component, 'NAME', {'xsi:type': 'string'})
        name.text = 'Func_Get_ReportEDRFolder'

        arguments = ET.SubElement(formula, 'ARGUMENTS')
        argument = ET.SubElement(arguments, 'ARGUMENT', {'xsi:type': 'varBaseExpression'})
        arg_name = ET.SubElement(argument, 'NAME', {'xsi:type': 'string'})
        arg_name.text = 'P_crashtype'

        # INSTANCE-NAME
        instance = ET.SubElement(teststep, 'INSTANCE-NAME', {'xsi:type': 'string'})
        instance.text = 'Get Report Folder'

        # Get crash title
        teststep = ET.SubElement(parent, 'TESTSTEP', {
        'format-rev': '3',
        'id': str(uuid.uuid4()),
        'name': 'TsCalculation',
        'xsi:type': 'utility-4115fa00-5f3c-11df-8a53-001c233b3528'
        })

        # VARIABLE-REFS
        var_refs = ET.SubElement(teststep, 'VARIABLE-REFS')
        var_name = ET.SubElement(var_refs, 'VARIABLE-NAME', {'dkey': 'default'})
        dvalue = ET.SubElement(var_name, 'DVALUE', {'xsi:type': 'string'})
        dvalue.text = 'crashTitle'

        # FORMULA
        formula = ET.SubElement(teststep, 'FORMULA', {'xsi:type': 'binaryOpBaseExpression'})

        name = ET.SubElement(formula, 'NAME', {'xsi:type': 'string'})
        name.text = 'BINARY_ADD'

        # FIRST-COMPONENT
        first = ET.SubElement(formula, 'FIRST-COMPONENT', {
            'format-rev': '2',
            'xsi:type': 'valueBaseExpression'
        })
        first_val = ET.SubElement(first, 'VALUE', {'xsi:type': 'string'})
        first_val.text = 'EDR_RECORD_'

        # SECOND-COMPONENT
        second = ET.SubElement(formula, 'SECOND-COMPONENT', {'xsi:type': 'functionBaseExpression'})

        component = ET.SubElement(second, 'COMPONENT', {'xsi:type': 'attributeBaseExpression'})
        inner_component = ET.SubElement(component, 'COMPONENT', {'xsi:type': 'varBaseExpression'})
        inner_name = ET.SubElement(inner_component, 'NAME', {'xsi:type': 'string'})
        inner_name.text = 'P_crashtype'

        attr_name = ET.SubElement(component, 'ATTR-NAME', {'xsi:type': 'string'})
        attr_name.text = 'replace'

        # ARGUMENTS
        arguments = ET.SubElement(second, 'ARGUMENTS')
        arg1 = ET.SubElement(arguments, 'ARGUMENT', {
            'format-rev': '2',
            'xsi:type': 'valueBaseExpression'
        })
        arg1_val = ET.SubElement(arg1, 'VALUE', {'xsi:type': 'string'})
        arg1_val.text = ';'

        arg2 = ET.SubElement(arguments, 'ARGUMENT', {
            'format-rev': '2',
            'xsi:type': 'valueBaseExpression'
        })
        arg2_val = ET.SubElement(arg2, 'VALUE', {'xsi:type': 'string'})
        arg2_val.text = '_'

        # INSTANCE-NAME
        instance = ET.SubElement(teststep, 'INSTANCE-NAME', {'xsi:type': 'string'})
        instance.text = 'Get crash title'

        #Get number of records
        step = ET.SubElement(parent, 'TESTSTEP', {
        'format-rev': '1',
        'id': str(uuid.uuid4()),
        'xsi:type': 'tsPackageCall'
        })

        ####### Generate job syc get number of records
        ET.SubElement(step, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'SYC_EDR_get_NumberOfEventsToBeStored'
        if 'SYC_EDR_get_NumberOfEventsToBeStored' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('SYC_EDR_get_NumberOfEventsToBeStored')

        variable_refs = ET.SubElement(step, 'VARIABLE-REFS')
        variable = ET.SubElement(variable_refs, 'VARIABLE-NAME', {'dkey': "R_NbrRecords"})
        ET.SubElement(variable, 'DVALUE', {'xsi:type': 'string'}).text = "numberOfRecords"

        ET.SubElement(step, 'PARAM-ASSIGNMENTS')

        ET.SubElement(step, 'ALTERNATIVE-MAPPING-SPACE', {
            'format-rev': '1',
            'xsi:type': 'mappingSpace'
        })

        step = ET.SubElement(parent, 'TESTSTEP', {
        'format-rev': '1',
        'id': str(uuid.uuid4()),
        'xsi:type': 'tsPackageCall'
        })

        # Generate Job EDR_ReadAndStoreAllRecord
        ET.SubElement(step, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'EDR_ReadAndStoreAllRecord'

        if 'EDR_ReadAndStoreAllRecord' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('EDR_ReadAndStoreAllRecord')

        param_assignments = ET.SubElement(step, 'PARAM-ASSIGNMENTS')

        assignment1 = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_DiagType'})
        dval1 = ET.SubElement(assignment1, 'DVALUE', {'format-rev': '2', 'xsi:type': 'valueBaseExpression'})
        ET.SubElement(dval1, 'VALUE', {'xsi:type': 'string'}).text = 'ProdDiag'

        assignment2 = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_FolderPath'})
        dval2 = ET.SubElement(assignment2, 'DVALUE', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(dval2, 'NAME', {'xsi:type': 'string'}).text = 'reportPath'

        assignment3 = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_RecordNumber'})
        dval3 = ET.SubElement(assignment3, 'DVALUE', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(dval3, 'NAME', {'xsi:type': 'string'}).text = 'numberOfRecords'

        assignment4 = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_TitleName'})
        dval4 = ET.SubElement(assignment4, 'DVALUE', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(dval4, 'NAME', {'xsi:type': 'string'}).text = 'crashTitle'

        ET.SubElement(step, 'ALTERNATIVE-MAPPING-SPACE', {
            'format-rev': '1',
            'xsi:type': 'mappingSpace'
        })

        # Generate evaluate the EDID data
        evalStep = ET.SubElement(parent, 'TESTSTEP', {
        'format-rev': '3',
        'id': str(uuid.uuid4()),
        'name':"TsBlock",
        'xsi:type': 'utility-2752ad1e-4fef-11dc-81d4-0013728784ee'
        }) 

        self.LibraryManager.Helpers_Lib.add_action_element(evalStep, "Evaluate the EDID data")

        #### Generate the get recoder number
        step = ET.SubElement(evalStep, 'TESTSTEP', {
        'format-rev': '3',
        'id': str(uuid.uuid4()),
        'name': 'TsCalculation',
        'xsi:type': 'utility-4115fa00-5f3c-11df-8a53-001c233b3528'
        })

        # VARIABLE-REFS
        variable_refs = ET.SubElement(step, 'VARIABLE-REFS')
        variable = ET.SubElement(variable_refs, 'VARIABLE-NAME', {'dkey': 'default'})
        ET.SubElement(variable, 'DVALUE', {'xsi:type': 'string'}).text = 'recordNumber'

        # FORMULA
        formula = ET.SubElement(step, 'FORMULA', {'xsi:type': 'binaryOpBaseExpression'})
        ET.SubElement(formula, 'NAME', {'xsi:type': 'string'}).text = 'BINARY_ADD'

        first_component = ET.SubElement(formula, 'FIRST-COMPONENT', {'xsi:type': 'functionBaseExpression'})
        attribute_expr = ET.SubElement(first_component, 'COMPONENT', {'xsi:type': 'attributeBaseExpression'})
        var_expr = ET.SubElement(attribute_expr, 'COMPONENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(var_expr, 'NAME', {'xsi:type': 'string'}).text = 'list_DID'
        ET.SubElement(attribute_expr, 'ATTR-NAME', {'xsi:type': 'string'}).text = 'index'

        arguments = ET.SubElement(first_component, 'ARGUMENTS')
        argument = ET.SubElement(arguments, 'ARGUMENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(argument, 'NAME', {'xsi:type': 'string'}).text = varDID

        second_component = ET.SubElement(formula, 'SECOND-COMPONENT', {
            'format-rev': '2',
            'xsi:type': 'valueBaseExpression'
        })
        ET.SubElement(second_component, 'VALUE', {'xsi:type': 'integer'}).text = '1'

        ET.SubElement(step, 'INSTANCE-NAME', {'xsi:type': 'string'}).text = 'Get the recoder number'


        # Generate IF-ELSE
        ifElseStep = ET.SubElement(evalStep, 'TESTSTEP', {
        'id': str(uuid.uuid4()),
        'name': 'TsIfThenElse',
        'xsi:type': 'utility-3609c41e-4fef-11dc-899a-0013728784ee'
        })

        condition = ET.SubElement(ifElseStep, 'CONDITION', {'xsi:type': 'andBaseExpression'})

        # FIRST-COMPONENT: isinstance(EDID, list)
        first_comp = ET.SubElement(condition, 'FIRST-COMPONENT', {'xsi:type': 'functionBaseExpression'})
        component_fc = ET.SubElement(first_comp, 'COMPONENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(component_fc, 'NAME', {'xsi:type': 'string'}).text = 'isinstance'

        arguments_fc = ET.SubElement(first_comp, 'ARGUMENTS')
        arg1_fc = ET.SubElement(arguments_fc, 'ARGUMENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(arg1_fc, 'NAME', {'xsi:type': 'string'}).text = varEDID

        arg2_fc = ET.SubElement(arguments_fc, 'ARGUMENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(arg2_fc, 'NAME', {'xsi:type': 'string'}).text = 'list'

        # SECOND-COMPONENT: len(EDID) > 1
        second_comp = ET.SubElement(condition, 'SECOND-COMPONENT', {'xsi:type': 'compareOpBaseExpression'})
        ET.SubElement(second_comp, 'NAME', {'xsi:type': 'string'}).text = '>'

        # FIRST-COMPONENT of SECOND-COMPONENT: len(EDID)
        fc_sc = ET.SubElement(second_comp, 'FIRST-COMPONENT', {'xsi:type': 'functionBaseExpression'})
        comp_fc_sc = ET.SubElement(fc_sc, 'COMPONENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(comp_fc_sc, 'NAME', {'xsi:type': 'string'}).text = 'len'

        args_fc_sc = ET.SubElement(fc_sc, 'ARGUMENTS')
        arg_fc_sc = ET.SubElement(args_fc_sc, 'ARGUMENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(arg_fc_sc, 'NAME', {'xsi:type': 'string'}).text = varEDID

        # SECOND-COMPONENT of SECOND-COMPONENT: 1
        sc_sc = ET.SubElement(second_comp, 'SECOND-COMPONENT', {'format-rev': '2', 'xsi:type': 'valueBaseExpression'})
        ET.SubElement(sc_sc, 'VALUE', {'xsi:type': 'integer'}).text = '1'
        
        # Generate then component
        thenStep = ET.SubElement( ifElseStep, 'THEN', {
            'id': str(uuid.uuid4()),
            'xsi:type': 'ifThenElseNode'
        })

        # Create TsLoop
        loop_step = ET.SubElement(thenStep, 'TESTSTEP', {
            'id': str(uuid.uuid4()),
            'name': 'TsLoop',
            'xsi:type': 'utility-3da58cf0-4fef-11dc-be56-0013728784ee'
        })

        # Generate a tsPackageCall step for EDR_GetRawEdidDataSamples
        stepGetEDID = ET.SubElement(loop_step, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })

        ET.SubElement(stepGetEDID, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'EDR_GetRawEdidDataSamples'
        if 'EDR_GetRawEdidDataSamples' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('EDR_GetRawEdidDataSamples')

        # VARIABLE-REFS
        variable_refs = ET.SubElement(stepGetEDID, 'VARIABLE-REFS')
        variable = ET.SubElement(variable_refs, 'VARIABLE-NAME', {'dkey': 'R_EdidData'})
        ET.SubElement(variable, 'DVALUE', {'xsi:type': 'string'}).text = 'detectedEDIDvalue'

        # PARAM-ASSIGNMENTS
        param_assignments = ET.SubElement(stepGetEDID, 'PARAM-ASSIGNMENTS')

        assignment1 = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_CrashLabel'})
        dvalue1 = ET.SubElement(assignment1, 'DVALUE', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(dvalue1, 'NAME', {'xsi:type': 'string'}).text = 'P_crashtype'

        assignment2 = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_DiagType'})
        dvalue2 = ET.SubElement(assignment2, 'DVALUE', {'format-rev': '2', 'xsi:type': 'valueBaseExpression'})
        ET.SubElement(dvalue2, 'VALUE', {'xsi:type': 'string'}).text = 'ProdDiag'

        # P_EDIDnr: binary operation BINARY_SUBSCR(EDID, BINARY_SUBTRACT(EDIDIndex,1))
        assignment3 = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_EDIDnr'})
        dvalue = ET.SubElement(assignment3, 'DVALUE', {'xsi:type': 'binaryOpBaseExpression'})
        ET.SubElement(dvalue, 'NAME', {'xsi:type': 'string'}).text = 'BINARY_SUBSCR'

        first_component = ET.SubElement(dvalue, 'FIRST-COMPONENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(first_component, 'NAME', {'xsi:type': 'string'}).text = varEDID

        second_component = ET.SubElement(dvalue, 'SECOND-COMPONENT', {'xsi:type': 'binaryOpBaseExpression'})
        ET.SubElement(second_component, 'NAME', {'xsi:type': 'string'}).text = 'BINARY_SUBTRACT'

        first_sub = ET.SubElement(second_component, 'FIRST-COMPONENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(first_sub, 'NAME', {'xsi:type': 'string'}).text = 'EDIDIndex'

        second_sub = ET.SubElement(second_component, 'SECOND-COMPONENT', {'format-rev': '2', 'xsi:type': 'valueBaseExpression'})
        ET.SubElement(second_sub, 'VALUE', {'xsi:type': 'integer'}).text = '1'

        assignment4 = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_RecordNumber'})
        dvalue4 = ET.SubElement(assignment4, 'DVALUE', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(dvalue4, 'NAME', {'xsi:type': 'string'}).text = 'recordNumber'

        assignment5 = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_ReportPath'})
        dvalue5 = ET.SubElement(assignment5, 'DVALUE', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(dvalue5, 'NAME', {'xsi:type': 'string'}).text = 'reportPath'

        ET.SubElement(stepGetEDID, 'ALTERNATIVE-MAPPING-SPACE', {
            'format-rev': '1',
            'xsi:type': 'mappingSpace'
        })

        # Generate the Calculation Func_EvaluateEdrPDData
        
        ts = ET.SubElement(loop_step, 'TESTSTEP', {
        'format-rev': '3',
        'id': str(uuid.uuid4()),
        'name': 'TsCalculation',
        'xsi:type': 'utility-4115fa00-5f3c-11df-8a53-001c233b3528'
        })

        # FORMULA
        formula = ET.SubElement(ts, 'FORMULA', {'xsi:type': 'functionBaseExpression'})
        component = ET.SubElement(formula, 'COMPONENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(component, 'NAME', {'xsi:type': 'string'}).text = 'Func_EvaluateEdrPDData'

        arguments = ET.SubElement(formula, 'ARGUMENTS')

        # ARGUMENT 1
        arg1 = ET.SubElement(arguments, 'ARGUMENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(arg1, 'NAME', {'xsi:type': 'string'}).text = 'detectedEDIDvalue'

        # ARGUMENT 2
        arg2 = ET.SubElement(arguments, 'ARGUMENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(arg2, 'NAME', {'xsi:type': 'string'}).text = varExpectData

        # ARGUMENT 3
        arg3 = ET.SubElement(arguments, 'ARGUMENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(arg3, 'NAME', {'xsi:type': 'string'}).text = varPosition

        # ARGUMENT 4: binaryOpBaseExpression (BINARY_SUBTRACT)
        arg4 = ET.SubElement(arguments, 'ARGUMENT', {'xsi:type': 'binaryOpBaseExpression'})
        ET.SubElement(arg4, 'NAME', {'xsi:type': 'string'}).text = 'BINARY_SUBTRACT'

        first_comp = ET.SubElement(arg4, 'FIRST-COMPONENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(first_comp, 'NAME', {'xsi:type': 'string'}).text = 'EDIDIndex'

        second_comp = ET.SubElement(arg4, 'SECOND-COMPONENT', {'format-rev': '2', 'xsi:type': 'valueBaseExpression'})
        ET.SubElement(second_comp, 'VALUE', {'xsi:type': 'integer'}).text = '1'

        # EXPECTATION-OPTION
        exp_option = ET.SubElement(ts, 'EXPECTATION-OPTION', {'xsi:type': 'timelessOption'})
        expression = ET.SubElement(exp_option, 'EXPRESSION', {'xsi:type': 'builtNumericExpression'})
        ET.SubElement(expression, 'RELATION', {'xsi:type': 'string'}).text = '=='

        value = ET.SubElement(expression, 'VALUE', {'format-rev': '2', 'xsi:type': 'valueBaseExpression'})
        ET.SubElement(value, 'VALUE', {'xsi:type': 'boolean'}).text = 'True'

        # INSTANCE-NAME
        ET.SubElement(ts, 'INSTANCE-NAME', {'xsi:type': 'string'}).text = 'Evaluate the EDR data from PD'


        # VARIABLE-REFS
        var_refs = ET.SubElement(loop_step, 'VARIABLE-REFS')
        var_name = ET.SubElement(var_refs, 'VARIABLE-NAME', {'dkey': 'default'})
        ET.SubElement(var_name, 'DVALUE', {'xsi:type': 'string'}).text = 'EDIDIndex'

        # LOOP-COUNT
        loop_count = ET.SubElement(loop_step, 'LOOP-COUNT', {'xsi:type': 'functionBaseExpression'})
        comp = ET.SubElement(loop_count, 'COMPONENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(comp, 'NAME', {'xsi:type': 'string'}).text = 'len'

        args = ET.SubElement(loop_count, 'ARGUMENTS')
        arg = ET.SubElement(args, 'ARGUMENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(arg, 'NAME', {'xsi:type': 'string'}).text = varEDID

        # Else compoment
        elseStep = ET.SubElement(ifElseStep, 'ELSE', {
            'id': str(uuid.uuid4()),
            'xsi:type': 'ifThenElseNode'
        })

        # Generate a tsPackageCall step for EDR_GetRawEdidDataSamples
        stepGetEDID = ET.SubElement(elseStep, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })

        ET.SubElement(stepGetEDID, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'EDR_GetRawEdidDataSamples'
        if 'EDR_GetRawEdidDataSamples' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('EDR_GetRawEdidDataSamples')

        # VARIABLE-REFS
        variable_refs = ET.SubElement(stepGetEDID, 'VARIABLE-REFS')
        variable = ET.SubElement(variable_refs, 'VARIABLE-NAME', {'dkey': 'R_EdidData'})
        ET.SubElement(variable, 'DVALUE', {'xsi:type': 'string'}).text = 'detectedEDIDvalue'

        # PARAM-ASSIGNMENTS
        param_assignments = ET.SubElement(stepGetEDID, 'PARAM-ASSIGNMENTS')

        assignment1 = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_CrashLabel'})
        dvalue1 = ET.SubElement(assignment1, 'DVALUE', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(dvalue1, 'NAME', {'xsi:type': 'string'}).text = 'P_crashtype'

        assignment2 = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_DiagType'})
        dvalue2 = ET.SubElement(assignment2, 'DVALUE', {'format-rev': '2', 'xsi:type': 'valueBaseExpression'})
        ET.SubElement(dvalue2, 'VALUE', {'xsi:type': 'string'}).text = 'ProdDiag'

        assignment3 = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_EDIDnr'})
        dvalue3 = ET.SubElement(assignment3, 'DVALUE', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(dvalue3, 'NAME', {'xsi:type': 'string'}).text = varEDID

        assignment4 = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_RecordNumber'})
        dvalue4 = ET.SubElement(assignment4, 'DVALUE', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(dvalue4, 'NAME', {'xsi:type': 'string'}).text = 'recordNumber'

        assignment5 = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_ReportPath'})
        dvalue5 = ET.SubElement(assignment5, 'DVALUE', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(dvalue5, 'NAME', {'xsi:type': 'string'}).text = 'reportPath'

        ET.SubElement(stepGetEDID, 'ALTERNATIVE-MAPPING-SPACE', {
            'format-rev': '1',
            'xsi:type': 'mappingSpace'
        })

        # Generate the Calculation Func_EvaluateEdrPDData
        ts = ET.SubElement(elseStep, 'TESTSTEP', {
        'format-rev': '3',
        'id': str(uuid.uuid4()),
        'name': 'TsCalculation',
        'xsi:type': 'utility-4115fa00-5f3c-11df-8a53-001c233b3528'
        })

        # FORMULA
        formula = ET.SubElement(ts, 'FORMULA', {'xsi:type': 'functionBaseExpression'})
        component = ET.SubElement(formula, 'COMPONENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(component, 'NAME', {'xsi:type': 'string'}).text = 'Func_EvaluateEdrPDData'

        arguments = ET.SubElement(formula, 'ARGUMENTS')

        # ARGUMENT 1
        arg1 = ET.SubElement(arguments, 'ARGUMENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(arg1, 'NAME', {'xsi:type': 'string'}).text = 'detectedEDIDvalue'

        # ARGUMENT 2
        arg2 = ET.SubElement(arguments, 'ARGUMENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(arg2, 'NAME', {'xsi:type': 'string'}).text = varExpectData

        # ARGUMENT 3
        arg3 = ET.SubElement(arguments, 'ARGUMENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(arg3, 'NAME', {'xsi:type': 'string'}).text = varPosition

        # EXPECTATION-OPTION
        exp_option = ET.SubElement(ts, 'EXPECTATION-OPTION', {'xsi:type': 'timelessOption'})
        expression = ET.SubElement(exp_option, 'EXPRESSION', {'xsi:type': 'builtNumericExpression'})
        ET.SubElement(expression, 'RELATION', {'xsi:type': 'string'}).text = '=='

        value = ET.SubElement(expression, 'VALUE', {'format-rev': '2', 'xsi:type': 'valueBaseExpression'})
        ET.SubElement(value, 'VALUE', {'xsi:type': 'boolean'}).text = 'True'

        # INSTANCE-NAME
        ET.SubElement(ts, 'INSTANCE-NAME', {'xsi:type': 'string'}).text = 'Evaluate the EDR data from PD'

        # Generate the function check the length of the EDR response
        # TESTSTEP IfThenElse
        teststep = ET.SubElement(evalStep, "TESTSTEP", {
            "id": str(uuid.uuid4()),
            "name": "TsIfThenElse",
            "xsi:type": "utility-3609c41e-4fef-11dc-899a-0013728784ee"
        })

        # CONDITION Expected_Length != "NA"
        condition = ET.SubElement(teststep, "CONDITION", {"xsi:type": "compareOpBaseExpression"})
        ET.SubElement(condition, "NAME", {"xsi:type": "string"}).text = "!="

        first_comp = ET.SubElement(condition, "FIRST-COMPONENT", {"xsi:type": "varBaseExpression"})
        ET.SubElement(first_comp, "NAME", {"xsi:type": "string"}).text = varExpectLength

        second_comp = ET.SubElement(condition, "SECOND-COMPONENT", {"format-rev": "2", "xsi:type": "valueBaseExpression"})
        ET.SubElement(second_comp, "VALUE", {"xsi:type": "string"}).text = "NA"

        # THEN
        then_node = ET.SubElement(teststep, "THEN", {
            "id": str(uuid.uuid4()),
            "xsi:type": "ifThenElseNode"
        })

        # TESTSTEP package call
        ts_pkg = ET.SubElement(then_node, "TESTSTEP", {
            "format-rev": "1",
            "id": str(uuid.uuid4()),
            "xsi:type": "tsPackageCall"
        })
        ET.SubElement(ts_pkg, "MAPPING-REF", {"xsi:type": "string"}).text = "EDR_PD_ReadEDR"
        if 'EDR_PD_ReadEDR' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('EDR_PD_ReadEDR')

        # VARIABLE-REFS
        var_refs = ET.SubElement(ts_pkg, "VARIABLE-REFS")
        var_name = ET.SubElement(var_refs, "VARIABLE-NAME", {"dkey": "R_Response"})
        ET.SubElement(var_name, "DVALUE", {"xsi:type": "string"}).text = "edrResponse"

        # PARAM-ASSIGNMENTS
        param_assignments = ET.SubElement(ts_pkg, "PARAM-ASSIGNMENTS")
        assign = ET.SubElement(param_assignments, "ASSIGNMENT", {"dkey": "P_DIDNumber"})
        dvalue = ET.SubElement(assign, "DVALUE", {"xsi:type": "varBaseExpression"})
        ET.SubElement(dvalue, "NAME", {"xsi:type": "string"}).text = varDID

        ET.SubElement(ts_pkg, "ALTERNATIVE-MAPPING-SPACE", {"format-rev": "1", "xsi:type": "mappingSpace"})

        # TESTSTEP Calculation
        ts_calc = ET.SubElement(then_node, "TESTSTEP", {
            "format-rev": "3",
            "id": str(uuid.uuid4()),
            "name": "TsCalculation",
            "xsi:type": "utility-4115fa00-5f3c-11df-8a53-001c233b3528"
        })

        formula = ET.SubElement(ts_calc, "FORMULA", {"xsi:type": "binaryOpBaseExpression"})
        ET.SubElement(formula, "NAME", {"xsi:type": "string"}).text = "BINARY_SUBTRACT"

        # FIRST-COMPONENT: len(edrResponse)
        fc = ET.SubElement(formula, "FIRST-COMPONENT", {"xsi:type": "functionBaseExpression"})
        comp = ET.SubElement(fc, "COMPONENT", {"xsi:type": "varBaseExpression"})
        ET.SubElement(comp, "NAME", {"xsi:type": "string"}).text = "len"
        args = ET.SubElement(fc, "ARGUMENTS")
        arg = ET.SubElement(args, "ARGUMENT", {"xsi:type": "varBaseExpression"})
        ET.SubElement(arg, "NAME", {"xsi:type": "string"}).text = "edrResponse"

        # SECOND-COMPONENT: 5
        sc = ET.SubElement(formula, "SECOND-COMPONENT", {"format-rev": "2", "xsi:type": "valueBaseExpression"})
        ET.SubElement(sc, "VALUE", {"xsi:type": "integer"}).text = "5"

        # EXPECTATION-OPTION
        expect_opt = ET.SubElement(ts_calc, "EXPECTATION-OPTION", {"xsi:type": "timelessOption"})
        expr = ET.SubElement(expect_opt, "EXPRESSION", {"xsi:type": "builtNumericExpression"})
        ET.SubElement(expr, "RELATION", {"xsi:type": "string"}).text = "=="
        val = ET.SubElement(expr, "VALUE", {"xsi:type": "varBaseExpression"})
        ET.SubElement(val, "NAME", {"xsi:type": "string"}).text = varExpectLength

        ET.SubElement(ts_calc, "INSTANCE-NAME", {"xsi:type": "string"}).text = "Evaluate the length of the EDR response"

        # ELSE (empty)
        ET.SubElement(teststep, "ELSE", {
            "id": str(uuid.uuid4()),
            "xsi:type": "ifThenElseNode"
        })


    def GenXML_EDR_Inject_RealCrash(self,parent, varCrashType, varPathMDS):
        # Generate TsCalculation for sensorLSBPath
        teststep = ET.SubElement(parent, "TESTSTEP", {
        "format-rev": "3",
        "id": str(uuid.uuid4()),
        "name": "TsCalculation",
        "xsi:type": "utility-4115fa00-5f3c-11df-8a53-001c233b3528"
        })

        # VARIABLE-REFS
        variable_refs = ET.SubElement(teststep, "VARIABLE-REFS")
        var_name = ET.SubElement(variable_refs, "VARIABLE-NAME", {"dkey": "default"})
        ET.SubElement(var_name, "DVALUE", {"xsi:type": "string"}).text = "sensorLSBPath"

        # FORMULA
        formula = ET.SubElement(teststep, "FORMULA", {"xsi:type": "binaryOpBaseExpression"})
        ET.SubElement(formula, "NAME", {"xsi:type": "string"}).text = "BINARY_ADD"

        first_lv1 = ET.SubElement(formula, "FIRST-COMPONENT", {"xsi:type": "binaryOpBaseExpression"})
        ET.SubElement(first_lv1, "NAME", {"xsi:type": "string"}).text = "BINARY_ADD"

        first_lv2 = ET.SubElement(first_lv1, "FIRST-COMPONENT", {"xsi:type": "binaryOpBaseExpression"})
        ET.SubElement(first_lv2, "NAME", {"xsi:type": "string"}).text = "BINARY_ADD"

        first_lv3 = ET.SubElement(first_lv2, "FIRST-COMPONENT", {"xsi:type": "varBaseExpression"})
        ET.SubElement(first_lv3, "NAME", {"xsi:type": "string"}).text = varPathMDS

        second_lv3 = ET.SubElement(first_lv2, "SECOND-COMPONENT", {
            "format-rev": "2", "xsi:type": "valueBaseExpression"
        })
        ET.SubElement(second_lv3, "VALUE", {"xsi:type": "string"}).text = "/"

        second_lv2 = ET.SubElement(first_lv1, "SECOND-COMPONENT", {"xsi:type": "varBaseExpression"})
        ET.SubElement(second_lv2, "NAME", {"xsi:type": "string"}).text = varCrashType

        second_lv1 = ET.SubElement(formula, "SECOND-COMPONENT", {
            "format-rev": "2", "xsi:type": "valueBaseExpression"
        })
        ET.SubElement(second_lv1, "VALUE", {"xsi:type": "string"}).text = "_LSB.csv"

        # INSTANCE-NAME
        ET.SubElement(teststep, "INSTANCE-NAME", {"xsi:type": "string"}).text = "Get Sensor Data LSB"

        # Check LSB Sensor Data Exist
        teststep1 = ET.SubElement(parent, 'TESTSTEP', {
        "format-rev": "3",
        "id": str(uuid.uuid4()),
        "name": "TsCalculation",
        "xsi:type": "utility-4115fa00-5f3c-11df-8a53-001c233b3528"
        })

        # FORMULA
        formula = ET.SubElement(teststep1, "FORMULA", {
            "xsi:type": "functionBaseExpression"
        })

        # COMPONENT (nested 5 levels)
        comp1 = ET.SubElement(formula, "COMPONENT", {"xsi:type": "attributeBaseExpression"})
        comp2 = ET.SubElement(comp1, "COMPONENT", {"xsi:type": "attributeBaseExpression"})
        comp3 = ET.SubElement(comp2, "COMPONENT", {"xsi:type": "attributeBaseExpression"})
        comp4 = ET.SubElement(comp3, "COMPONENT", {"xsi:type": "attributeBaseExpression"})
        comp5 = ET.SubElement(comp4, "COMPONENT", {"xsi:type": "varBaseExpression"})

        ET.SubElement(comp5, "NAME", {"xsi:type": "string"}).text = "libraries"
        ET.SubElement(comp4, "ATTR-NAME", {"xsi:type": "string"}).text = "TestArea_EDR"
        ET.SubElement(comp3, "ATTR-NAME", {"xsi:type": "string"}).text = "user"
        ET.SubElement(comp2, "ATTR-NAME", {"xsi:type": "string"}).text = "DR_General"
        ET.SubElement(comp1, "ATTR-NAME", {"xsi:type": "string"}).text = "ResolveFilePathRelativeToWorkspace"

        # ARGUMENTS
        arguments = ET.SubElement(formula, "ARGUMENTS")
        argument = ET.SubElement(arguments, "ARGUMENT", {"xsi:type": "varBaseExpression"})
        ET.SubElement(argument, "NAME", {"xsi:type": "string"}).text = "sensorLSBPath"

        # INSTANCE-NAME
        ET.SubElement(teststep1, "INSTANCE-NAME", {"xsi:type": "string"}).text = "Check LSB Sensor Data Exist"

        # Generate CSI trigger
        teststep = ET.SubElement(parent, 'TESTSTEP', {
        "format-rev": "1", 
        "id": str(uuid.uuid4()),
        "xsi:type": "tsPackageCall"
        })

        # MAPPING-REF
        ET.SubElement(teststep, "MAPPING-REF", {"xsi:type": "string"}).text = "CSI_Trigger"
        if 'CSI_Trigger' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('CSI_Trigger')

        # VARIABLE-REFS
        variable_refs = ET.SubElement(teststep, "VARIABLE-REFS")
        variable_name = ET.SubElement(variable_refs, "VARIABLE-NAME", {"dkey": "R_CSITime"})
        dvalue_var = ET.SubElement(variable_name, "DVALUE", {"xsi:type": "string"})
        dvalue_var.text = "triggerTime"

        # PARAM-ASSIGNMENTS
        param_assignments = ET.SubElement(teststep, "PARAM-ASSIGNMENTS")
        assignment = ET.SubElement(param_assignments, "ASSIGNMENT", {"dkey": "P_crashFile"})
        dvalue_expr = ET.SubElement(assignment, "DVALUE", {"xsi:type": "varBaseExpression"})
        ET.SubElement(dvalue_expr, "NAME", {"xsi:type": "string"}).text = "sensorLSBPath"

        # ALTERNATIVE-MAPPING-SPACE
        ET.SubElement(teststep, "ALTERNATIVE-MAPPING-SPACE", {
            "format-rev": "1",
            "xsi:type": "mappingSpace"
        })

        # Generate if else
        teststep = ET.SubElement(parent, 'TESTSTEP', {
        'id': str(uuid.uuid4()),
        'name': 'TsIfThenElse',
        'xsi:type': 'utility-3609c41e-4fef-11dc-899a-0013728784ee'
        })

        # CONDITION
        condition = ET.SubElement(teststep, 'CONDITION', {'xsi:type': 'compareOpBaseExpression'})
        ET.SubElement(condition, 'NAME', {'xsi:type': 'string'}).text = 'is'
        
        first_comp = ET.SubElement(condition, 'FIRST-COMPONENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(first_comp, 'NAME', {'xsi:type': 'string'}).text = 'triggerTime'
        
        ET.SubElement(condition, 'SECOND-COMPONENT', {
            'format-rev': '2',
            'xsi:type': 'valueBaseExpression'
        })

        # THEN
        then_node = ET.SubElement(teststep, 'THEN', {
            'id': str(uuid.uuid4()),
            'xsi:type': 'ifThenElseNode'
        })

        exit_step = ET.SubElement(then_node, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'name': 'TsExit',
            'xsi:type': 'utility-c6aa4f70-f037-11dc-9d16-001b24fa84be'
        })

        ET.SubElement(exit_step, 'EXIT-RESULT', {'xsi:type': 'string'}).text = 'FAILED'

        comment_expr = ET.SubElement(exit_step, 'COMMENT-EXPR', {
            'format-rev': '2',
            'xsi:type': 'valueBaseExpression'
        })
        ET.SubElement(comment_expr, 'VALUE', {'xsi:type': 'string'}).text = 'Cannot trigger crash simulation'

        # ELSE
        ET.SubElement(teststep, 'ELSE', {
            'id': str(uuid.uuid4()),
            'xsi:type': 'ifThenElseNode'
        })

        # Generate Wait DCS
        teststep = ET.SubElement(parent, 'TESTSTEP', {
        'format-rev': '1',
        'id': str(uuid.uuid4()),
        'xsi:type': 'tsPackageCall'
        })

        ET.SubElement(teststep, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'EDR_WaitDCSIdle'
        if 'EDR_WaitDCSIdle' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('EDR_WaitDCSIdle')

        ET.SubElement(teststep, 'PARAM-ASSIGNMENTS')
        ET.SubElement(teststep, 'ALTERNATIVE-MAPPING-SPACE', {
            'format-rev': '1',
            'xsi:type': 'mappingSpace'
        })

        # Check Roll
        teststep = ET.SubElement(parent, 'TESTSTEP', {
        'id': str(uuid.uuid4()),
        'name': 'TsIfThenElse',
        'xsi:type': 'utility-3609c41e-4fef-11dc-899a-0013728784ee'
        })

        # CONDITION
        condition = ET.SubElement(teststep, 'CONDITION', {'xsi:type': 'orBaseExpression'})

        first_or = ET.SubElement(condition, 'FIRST-COMPONENT', {'xsi:type': 'orBaseExpression'})

        # FIRST-COMPONENT of inner orBaseExpression
        first_comp1 = ET.SubElement(first_or, 'FIRST-COMPONENT', {'xsi:type': 'compareOpBaseExpression'})
        ET.SubElement(first_comp1, 'NAME', {'xsi:type': 'string'}).text = 'in'

        first_val1 = ET.SubElement(first_comp1, 'FIRST-COMPONENT', {
            'format-rev': '2',
            'xsi:type': 'valueBaseExpression'
        })
        ET.SubElement(first_val1, 'VALUE', {'xsi:type': 'string'}).text = 'Roll'

        second_val1 = ET.SubElement(first_comp1, 'SECOND-COMPONENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(second_val1, 'NAME', {'xsi:type': 'string'}).text = varCrashType

        # SECOND-COMPONENT of inner orBaseExpression
        second_comp1 = ET.SubElement(first_or, 'SECOND-COMPONENT', {'xsi:type': 'compareOpBaseExpression'})
        ET.SubElement(second_comp1, 'NAME', {'xsi:type': 'string'}).text = 'in'

        first_val2 = ET.SubElement(second_comp1, 'FIRST-COMPONENT', {
            'format-rev': '2',
            'xsi:type': 'valueBaseExpression'
        })
        ET.SubElement(first_val2, 'VALUE', {'xsi:type': 'string'}).text = 'Parallel_EDR_AccelerationSensorRange'

        second_val2 = ET.SubElement(second_comp1, 'SECOND-COMPONENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(second_val2, 'NAME', {'xsi:type': 'string'}).text = varCrashType

        # SECOND-COMPONENT of top-level orBaseExpression
        second_comp2 = ET.SubElement(condition, 'SECOND-COMPONENT', {'xsi:type': 'compareOpBaseExpression'})
        ET.SubElement(second_comp2, 'NAME', {'xsi:type': 'string'}).text = 'in'

        first_val3 = ET.SubElement(second_comp2, 'FIRST-COMPONENT', {
            'format-rev': '2',
            'xsi:type': 'valueBaseExpression'
        })
        ET.SubElement(first_val3, 'VALUE', {'xsi:type': 'string'}).text = 'Ro'

        second_val3 = ET.SubElement(second_comp2, 'SECOND-COMPONENT', {'xsi:type': 'varBaseExpression'})
        ET.SubElement(second_val3, 'NAME', {'xsi:type': 'string'}).text = varCrashType

        # THEN branch
        then_node = ET.SubElement(teststep, 'THEN', {
            'id': str(uuid.uuid4()),
            'xsi:type': 'ifThenElseNode'
        })

        # Inner TESTSTEP in THEN
        inner_step = ET.SubElement(then_node, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })

        ET.SubElement(inner_step, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'GEN_wait_ms'

        param_assignments = ET.SubElement(inner_step, 'PARAM-ASSIGNMENTS')
        assignment = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_waitTime'})
        dvalue = ET.SubElement(assignment, 'DVALUE', {
            'format-rev': '2',
            'xsi:type': 'valueBaseExpression'
        })
        ET.SubElement(dvalue, 'VALUE', {'xsi:type': 'integer'}).text = '20000'

        ET.SubElement(inner_step, 'ALTERNATIVE-MAPPING-SPACE', {
            'format-rev': '1',
            'xsi:type': 'mappingSpace'
        })

        if 'GEN_wait_ms' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('GEN_wait_ms')

        # ELSE branch (empty)
        ET.SubElement(teststep, 'ELSE', {
            'id': str(uuid.uuid4()),
            'xsi:type': 'ifThenElseNode'
        })

        # Generate PSDIAG_Read_Fault_Memory
        teststep = ET.SubElement(parent, 'TESTSTEP', {
        'format-rev': '1',
        'id': str(uuid.uuid4()),
        'xsi:type': 'tsPackageCall'
        })

        ET.SubElement(teststep, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'PSDIAG_Read_Fault_Memory'
        if 'PSDIAG_Read_Fault_Memory' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('PSDIAG_Read_Fault_Memory')

        param_assignments = ET.SubElement(teststep, 'PARAM-ASSIGNMENTS')

        assignment = ET.SubElement(param_assignments, 'ASSIGNMENT', {'dkey': 'P_memoryType'})
        dvalue = ET.SubElement(assignment, 'DVALUE', {
            'format-rev': '2',
            'xsi:type': 'valueBaseExpression'
        })
        ET.SubElement(dvalue, 'VALUE', {'xsi:type': 'string'}).text = 'PRIMARY'

        ET.SubElement(teststep, 'ALTERNATIVE-MAPPING-SPACE', {
            'format-rev': '1',
            'xsi:type': 'mappingSpace'
        })

    def GenXML_EDR_Finalization(self,parent):
        """Generate a DIAG_Start_CyclicTesterPresent test step"""
        step = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '1',
            'id': str(uuid.uuid4()),
            'xsi:type': 'tsPackageCall'
        })

        ET.SubElement(step, 'MAPPING-REF', {'xsi:type': 'string'}).text = 'EDR_Finalization'

        if 'EDR_Finalization' not in ShareBase.mapping_Path_Job_List:
            ShareBase.mapping_Path_Job_List.append('EDR_Finalization')

        ET.SubElement(step, 'PARAM-ASSIGNMENTS')
        ET.SubElement(step, 'ALTERNATIVE-MAPPING-SPACE', {
            'format-rev': '1',
            'xsi:type': 'mappingSpace'
        })