import openpyxl
import re

class ExcelPackageExtractor():
    def extract_all_data(self,file_path):
        wb = openpyxl.load_workbook(file_path, data_only=True)
        sheet = wb.active  # or sheet = wb['TestCases'] if you know the sheet name

        # Tìm cột "Execution planning" (header ở dòng 4)
        max_column = sheet.max_column
        exec_plan_col = None
        for col in range(1, max_column + 1):
            val = sheet.cell(row=4, column=col).value
            if isinstance(val, str) and val.strip().lower() == "execution planning":
                exec_plan_col = col
                break

        if exec_plan_col is None:
            raise ValueError("Không tìm thấy cột 'Execution planning' trong header")

        test_steps = {}
        expected_results = {}
        parameters = {}
        ID = []

        max_row = sheet.max_row

        def get_cell(row, col):
            val = sheet.cell(row=row, column=col).value
            return val.strip() if isinstance(val, str) else val

        # Hàm thêm hậu tố _1, _2,... cho param key nếu đã tồn tại trong test case
        def get_unique_key(base_key, existing_keys):
            if base_key not in existing_keys:
                return base_key
            suffix = 1
            while f"{base_key}_{suffix}" in existing_keys:
                suffix += 1
            return f"{base_key}_{suffix}"

        # Hàm thay thế placeholder trong description với số lần xuất hiện param key
        # param_count: dict đếm số lần xuất hiện của param key trong test case
        def replace_placeholders(desc, param_count):
            def repl(m):
                key = m.group(1)
                count = param_count.get(key, 0)
                if count > 1:
                    # Nếu param xuất hiện nhiều lần, thay bằng key_1, key_2,...
                    # Lấy lần xuất hiện hiện tại và tăng lên 1
                    # Ở đây ta thay toàn bộ placeholder thành dạng key_1, key_2,... theo thứ tự
                    # Vì desc là duy nhất cho bước, ta giả sử lần đầu là _1
                    # Để đơn giản, ta sẽ thay theo thứ tự lần xuất hiện trong desc
                    # Nhưng desc chỉ có 1 placeholder mỗi param key nên thay thành key_1
                    return f"{key}_1"
                else:
                    return key
            # Thay thế {Param} thành {Param_1} nếu cần
            # Ta sẽ thay toàn bộ {Param} thành {Param_1} nếu param_count[key]>1
            # Để giữ nguyên dấu ngoặc {}, ta thay cả dấu ngoặc
            pattern = re.compile(r"\{(\w+?)\}")
            # Đổi từng placeholder theo param_count
            # Ở đây ta xử lý bằng cách duyệt từng placeholder
            # Nhưng vì desc chỉ có 1 placeholder mỗi param (theo ví dụ), nên ta dùng hàm này
            new_desc = desc
            for key in param_count:
                if param_count[key] > 1:
                    # Thay {key} thành {key_1} trong new_desc
                    new_desc = re.sub(rf"\{{{key}\}}", f"{{{key}_1}}", new_desc)
            return new_desc

        row = 2  # assuming row 1 is header
        while row <= max_row:
            id_cell = get_cell(row, 1)
            if id_cell and isinstance(id_cell, str) and id_cell.startswith("SITS_DT"):
                # Kiểm tra giá trị ở cột Execution planning của test case này
                exec_plan_val = get_cell(row, exec_plan_col)
                if exec_plan_val is None:
                    exec_plan_val = ""
                exec_plan_val = exec_plan_val.strip().lower()

                # Chỉ xử lý nếu value là "new/changed" hoặc "regression"
                if exec_plan_val in ["new change", "regression"]:
                    current_id = id_cell
                    ID.append(current_id)
                    test_steps[current_id] = {'Precondition': {}, 'Action': {}, 'Postcondition': {}}
                    expected_results[current_id] = {}
                    parameters[current_id] = {'Action': {}, 'Postcondition': {}, 'Precondition': {}}

                    section = None  # None, 'PRECONDITION', 'ACTION', 'POSTCONDITION'
                    precondition_step = 1
                    action_step = 1
                    postcondition_step = 1

                    # Đếm số lần xuất hiện param trong test case (dùng để đặt hậu tố)
                    param_count_precondition = {}
                    param_count_action = {}
                    param_count_postcondition = {}

                    row += 1  # start reading next line after ID

                    while row <= max_row:
                        row_id_cell = get_cell(row, 1)
                        if row_id_cell and isinstance(row_id_cell, str) and row_id_cell.startswith("SITS_DT"):
                            # Next test case begins
                            break

                        col3_val = get_cell(row, 3)  # Test Procedure description or section header
                        param_key_1 = get_cell(row, 5)  # Input param name
                        param_val_1 = get_cell(row, 6)  # Input param value
                        param_key_2 = get_cell(row, 7)  # Output param name or second input param name
                        param_val_2 = get_cell(row, 8)  # Output param value or second input param value

                        if col3_val:
                            val_upper = col3_val.strip().upper()
                            if val_upper == "PRECONDITION":
                                section = 'PRECONDITION'
                                row += 1
                                continue
                            elif val_upper == "ACTION":
                                section = 'ACTION'
                                row += 1
                                continue
                            elif val_upper == "POSTCONDITION":
                                section = 'POSTCONDITION'
                                row += 1
                                continue

                        if section == 'PRECONDITION':
                            if col3_val:
                                step_key = str(precondition_step)
                                desc = col3_val.strip()

                                # Đếm param keys trong precondition
                                keys_in_step = []
                                if param_key_1:
                                    param_count_precondition[param_key_1] = param_count_precondition.get(param_key_1, 0) + 1
                                    keys_in_step.append(param_key_1)
                                if param_key_2:
                                    param_count_precondition[param_key_2] = param_count_precondition.get(param_key_2, 0) + 1
                                    keys_in_step.append(param_key_2)

                                # Thay placeholder trong desc tương ứng
                                for key in keys_in_step:
                                    count = param_count_precondition[key]
                                    if count > 1:
                                        desc = re.sub(rf"\{{{key}\}}", f"{{{key}_{count-1}}}", desc)

                                if not re.match(r"^\d+\.", desc):
                                    desc = f"{step_key}.{desc}"
                                test_steps[current_id]['Precondition'][step_key] = desc

                                param_dict = {}

                                if param_key_1 and param_val_1 is not None:
                                    count = param_count_precondition[param_key_1]
                                    unique_key = param_key_1 if count == 1 else f"{param_key_1}_{count-1}"
                                    param_dict[unique_key] = str(param_val_1).strip()

                                if param_key_2 and param_val_2 is not None:
                                    count = param_count_precondition[param_key_2]
                                    unique_key = param_key_2 if count == 1 else f"{param_key_2}_{count-1}"
                                    param_dict[unique_key] = str(param_val_2).strip()

                                parameters[current_id]['Precondition'][step_key] = param_dict

                                precondition_step += 1

                            else:
                                # Dòng không có mô tả, có param thì gán cho bước trước
                                step_key = str(precondition_step - 1) if precondition_step > 1 else '1'
                                param_dict = parameters[current_id]['Precondition'].get(step_key, {})

                                if param_key_1 and param_val_1 is not None:
                                    param_count_precondition[param_key_1] = param_count_precondition.get(param_key_1, 0) + 1
                                    count = param_count_precondition[param_key_1]
                                    unique_key = param_key_1 if count == 1 else f"{param_key_1}_{count-1}"
                                    param_dict[unique_key] = str(param_val_1).strip()

                                if param_key_2 and param_val_2 is not None:
                                    param_count_precondition[param_key_2] = param_count_precondition.get(param_key_2, 0) + 1
                                    count = param_count_precondition[param_key_2]
                                    unique_key = param_key_2 if count == 1 else f"{param_key_2}_{count-1}"
                                    param_dict[unique_key] = str(param_val_2).strip()

                                parameters[current_id]['Precondition'][step_key] = param_dict

                        elif section == 'ACTION':
                            if col3_val:
                                step_key = str(action_step)
                                desc = col3_val.strip()
                                # Đếm param keys xuất hiện để xử lý hậu tố
                                # Tăng param_count_action cho các param_key_1, param_key_2
                                # Đếm từng key nếu có
                                keys_in_step = []
                                if param_key_1:
                                    param_count_action[param_key_1] = param_count_action.get(param_key_1, 0) + 1
                                    keys_in_step.append(param_key_1)
                                if param_key_2:
                                    param_count_action[param_key_2] = param_count_action.get(param_key_2, 0) + 1
                                    keys_in_step.append(param_key_2)

                                # Thay placeholder trong desc tương ứng
                                for key in keys_in_step:
                                    count = param_count_action[key]
                                    if count > 1:
                                        # Thay {key} thành {key_count-1}, ví dụ {Request} thành {Request_1}
                                        desc = re.sub(rf"\{{{key}\}}", f"{{{key}_{count-1}}}", desc)

                                # Thêm số bước nếu chưa có
                                if not re.match(r"^\d+\.", desc):
                                    desc = f"{step_key}.{desc}"
                                test_steps[current_id]['Action'][step_key] = desc

                                # Xử lý parameters cho step
                                param_dict = {}

                                if param_key_1 and param_val_1 is not None:
                                    # Tạo key có hậu tố nếu cần
                                    unique_key = param_key_1
                                    count = param_count_action[param_key_1]
                                    if count > 1:
                                        unique_key = f"{param_key_1}_{count-1}"
                                    param_dict[unique_key] = str(param_val_1).strip()

                                if param_key_2 and param_val_2 is not None:
                                    unique_key = param_key_2
                                    count = param_count_action[param_key_2]
                                    if count > 1:
                                        unique_key = f"{param_key_2}_{count-1}"
                                    param_dict[unique_key] = str(param_val_2).strip()

                                parameters[current_id]['Action'][step_key] = param_dict

                                # Xử lý expected_results
                                # Lấy param_key_2 làm placeholder expected_result
                                if param_key_2 and param_val_2 is not None:
                                    unique_key = param_key_2
                                    count = param_count_action[param_key_2]
                                    if count > 1:
                                        unique_key = f"{param_key_2}_{count-1}"
                                    expected_results[current_id][step_key] = f"{{{unique_key}}}"

                                action_step += 1

                            else:
                                # Dòng không có mô tả, có thể có param hoặc expected result, gán cho bước trước
                                step_key = str(action_step - 1) if action_step > 1 else '1'
                                param_dict = parameters[current_id]['Action'].get(step_key, {})

                                if param_key_1 and param_val_1 is not None:
                                    param_count_action[param_key_1] = param_count_action.get(param_key_1, 0) + 1
                                    count = param_count_action[param_key_1]
                                    unique_key = param_key_1 if count == 1 else f"{param_key_1}_{count-1}"
                                    param_dict[unique_key] = str(param_val_1).strip()

                                if param_key_2 and param_val_2 is not None:
                                    param_count_action[param_key_2] = param_count_action.get(param_key_2, 0) + 1
                                    count = param_count_action[param_key_2]
                                    unique_key = param_key_2 if count == 1 else f"{param_key_2}_{count-1}"
                                    param_dict[unique_key] = str(param_val_2).strip()

                                parameters[current_id]['Action'][step_key] = param_dict

                                if param_key_2 and param_val_2 is not None:
                                    count = param_count_action[param_key_2]
                                    unique_key = param_key_2 if count == 1 else f"{param_key_2}_{count-1}"
                                    expected_results[current_id][step_key] = f"{{{unique_key}}}"

                        elif section == 'POSTCONDITION':
                            if col3_val:
                                step_key = str(postcondition_step)
                                desc = col3_val.strip()

                                # Đếm param keys trong postcondition
                                keys_in_step = []
                                if param_key_1:
                                    param_count_postcondition[param_key_1] = param_count_postcondition.get(param_key_1, 0) + 1
                                    keys_in_step.append(param_key_1)
                                if param_key_2:
                                    param_count_postcondition[param_key_2] = param_count_postcondition.get(param_key_2, 0) + 1
                                    keys_in_step.append(param_key_2)

                                # Thay placeholder trong desc tương ứng
                                for key in keys_in_step:
                                    count = param_count_postcondition[key]
                                    if count > 1:
                                        desc = re.sub(rf"\{{{key}\}}", f"{{{key}_{count-1}}}", desc)

                                if not re.match(r"^\d+\.", desc):
                                    desc = f"{step_key}.{desc}"
                                test_steps[current_id]['Postcondition'][step_key] = desc

                                param_dict = {}

                                if param_key_1 and param_val_1 is not None:
                                    count = param_count_postcondition[param_key_1]
                                    unique_key = param_key_1 if count == 1 else f"{param_key_1}_{count-1}"
                                    param_dict[unique_key] = str(param_val_1).strip()

                                if param_key_2 and param_val_2 is not None:
                                    count = param_count_postcondition[param_key_2]
                                    unique_key = param_key_2 if count == 1 else f"{param_key_2}_{count-1}"
                                    param_dict[unique_key] = str(param_val_2).strip()

                                parameters[current_id]['Postcondition'][step_key] = param_dict

                                postcondition_step += 1

                            else:
                                # Dòng không có mô tả, có param thì gán cho bước trước
                                step_key = str(postcondition_step - 1) if postcondition_step > 1 else '1'
                                param_dict = parameters[current_id]['Postcondition'].get(step_key, {})

                                if param_key_1 and param_val_1 is not None:
                                    param_count_postcondition[param_key_1] = param_count_postcondition.get(param_key_1, 0) + 1
                                    count = param_count_postcondition[param_key_1]
                                    unique_key = param_key_1 if count == 1 else f"{param_key_1}_{count-1}"
                                    param_dict[unique_key] = str(param_val_1).strip()

                                if param_key_2 and param_val_2 is not None:
                                    param_count_postcondition[param_key_2] = param_count_postcondition.get(param_key_2, 0) + 1
                                    count = param_count_postcondition[param_key_2]
                                    unique_key = param_key_2 if count == 1 else f"{param_key_2}_{count-1}"
                                    param_dict[unique_key] = str(param_val_2).strip()

                                parameters[current_id]['Postcondition'][step_key] = param_dict

                        row += 1
                else:
                    # Bỏ qua test case có Execution planning là "No execution" hoặc khác
                    row += 1
                    # Nhảy tới test case tiếp theo (tìm dòng id tiếp theo)
                    while row <= max_row:
                        next_id_cell = get_cell(row, 1)
                        if next_id_cell and isinstance(next_id_cell, str) and next_id_cell.startswith("SITS_DT"):
                            break
                        row += 1

            else:
                row += 1

        return test_steps, expected_results, parameters, ID