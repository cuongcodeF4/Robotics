import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import os
import threading
import datetime
import sys

from Extract_data_Excel import ExcelPackageExtractor
from Component_Generate_ECU_TEST_Packages import Generate_XML_Package_ECUTEST
from Component_Generate_ECU_TEST_Project import Generate_XML_Project_ECUTEST

class ECUTestGeneratorUI:
    def __init__(self, root):
        self.root = root
        self.setup_window()
        self.setup_variables()
        self.setup_styles()
        self.create_widgets()
        self.setup_layout()
        
    def setup_window(self):
        """Configure main window"""
        self.root.title("ECU-TEST Package Generator")
        self.root.geometry("800x800")
        self.root.minsize(750, 550)
        
        # Set icon and configure window
        self.root.configure(bg='#f0f0f0')
        
        # Center window on screen
        self.root.geometry("+{}+{}".format(
            (self.root.winfo_screenwidth() // 2) - 400,
            (self.root.winfo_screenheight() // 2) - 420
        ))
        
    def setup_variables(self):
        """Initialize variables"""
        self.excel_path = tk.StringVar()
        self.package_path = tk.StringVar()
        self.project_path = tk.StringVar()
        self.is_running = False
        
    def setup_styles(self):
        """Configure styles for ttk widgets"""
        self.style = ttk.Style()
        self.style.theme_use('clam')
        
        # Style for buttons
        self.style.configure('Action.TButton',
                           background='#4CAF50',
                           foreground='white',
                           borderwidth=0,
                           focuscolor='none',
                           font=('Arial', 10, 'bold'))
        
        self.style.map('Action.TButton',
                      background=[('active', '#45a049')])
        
        # Style for browse buttons
        self.style.configure('Browse.TButton',
                           background='#2196F3',
                           foreground='white',
                           borderwidth=0,
                           focuscolor='none',
                           font=('Arial', 9))
        
        self.style.map('Browse.TButton',
                      background=[('active', '#1976D2')])
        
        # Style for generate button
        self.style.configure('Generate.TButton',
                           background='#FF9800',
                           foreground='white',
                           borderwidth=0,
                           focuscolor='none',
                           font=('Arial', 12, 'bold'))
        
        self.style.map('Generate.TButton',
                      background=[('active', '#F57C00')])
        
        # Configure the style for the progress bar
        self.style.configure("custom.Horizontal.TProgressbar",
                troughcolor='white',      # Background of the progress bar
                background='Orange',       # The color of the progress itself
                thickness=20)             # Optional: make it thicker if desired
        
    def create_widgets(self):
        """Create widgets"""
        # Main container
        self.main_frame = ttk.Frame(self.root, padding="20")
        
        # Title
        self.title_label = tk.Label(self.main_frame, 
                                   text="ECU-TEST Package Generator",
                                   font=('Arial', 18, 'bold'),
                                   bg='#DDDBD6',
                                   fg='#333333')
        
        # Separator
        self.separator1 = ttk.Separator(self.main_frame, orient='horizontal')
        
        # Input section frame
        self.input_frame = ttk.LabelFrame(self.main_frame, text="Input Configuration", padding="15")
        
        # Excel file selection
        self.excel_label = tk.Label(self.input_frame, text="SIT Excel File (.xlsm):", 
                                   font=('Arial', 10, 'bold'), bg='#DDDBD6')
        self.excel_entry = ttk.Entry(self.input_frame, textvariable=self.excel_path, 
                                    font=('Arial', 10), width=50)
        self.excel_button = ttk.Button(self.input_frame, text="Browse", 
                                      command=self.browse_excel_file, style='Browse.TButton')
        
        # Package path selection
        self.package_label = tk.Label(self.input_frame, text="Packages Path:", 
                                     font=('Arial', 10, 'bold'), bg='#DDDBD6')
        self.package_entry = ttk.Entry(self.input_frame, textvariable=self.package_path, 
                                      font=('Arial', 10), width=50)
        self.package_button = ttk.Button(self.input_frame, text="Browse", 
                                        command=self.browse_package_path, style='Browse.TButton')
        
        # Project path selection
        self.project_label = tk.Label(self.input_frame, text="Project Path:", 
                                     font=('Arial', 10, 'bold'), bg='#DDDBD6')
        self.project_entry = ttk.Entry(self.input_frame, textvariable=self.project_path, 
                                      font=('Arial', 10), width=50)
        self.project_button = ttk.Button(self.input_frame, text="Browse", 
                                        command=self.browse_project_path, style='Browse.TButton')
        
        # Generate button
        self.generate_button = ttk.Button(self.main_frame, text="Generate ECU-TEST Package", 
                                         command=self.start_generation, style='Generate.TButton')
        
        # Progress bar
        self.progress_var = tk.DoubleVar()
        self.progress_bar = ttk.Progressbar(self.main_frame, variable=self.progress_var, style="custom.Horizontal.TProgressbar",
                                           maximum=100, length=400)
        
        # Separator
        self.separator2 = ttk.Separator(self.main_frame, orient='horizontal')
        
        # Log section
        self.log_frame = ttk.LabelFrame(self.main_frame, text="Process Log", padding="10")
        
        # Log text area with scrollbar
        self.log_text = tk.Text(self.log_frame, height=12, width=80, 
                               font=('Consolas', 9), bg='#2d2d2d', fg='#ffffff',
                               insertbackground='white')
        self.log_scrollbar = ttk.Scrollbar(self.log_frame, orient="vertical", 
                                          command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=self.log_scrollbar.set)
        
        # Clear log button
        self.clear_log_button = ttk.Button(self.log_frame, text="Clear Log", 
                                          command=self.clear_log, style='Action.TButton')
        
    def setup_layout(self):
        """Setup layout"""
        # Main frame
        self.main_frame.pack(fill='both', expand=True)
        
        # Title
        self.title_label.pack(pady=(0, 10))
        self.separator1.pack(fill='x', pady=(0, 20))
        
        # Input frame
        self.input_frame.pack(fill='x', pady=(0, 20))
        
        # Excel file row
        self.excel_label.grid(row=0, column=0, sticky='w', pady=(0, 10))
        self.excel_entry.grid(row=1, column=0, sticky='ew', padx=(0, 10))
        self.excel_button.grid(row=1, column=1, sticky='w')
        
        # Package path row
        self.package_label.grid(row=2, column=0, sticky='w', pady=(15, 5))
        self.package_entry.grid(row=3, column=0, sticky='ew', padx=(0, 10))
        self.package_button.grid(row=3, column=1, sticky='w')
        
        # Project path row
        self.project_label.grid(row=4, column=0, sticky='w', pady=(15, 5))
        self.project_entry.grid(row=5, column=0, sticky='ew', padx=(0, 10))
        self.project_button.grid(row=5, column=1, sticky='w')
        
        # Configure grid weights
        self.input_frame.columnconfigure(0, weight=1)
        
        # Generate button and progress bar
        self.generate_button.pack(pady=20)
        self.progress_bar.pack(pady=(0, 20))
        
        self.separator2.pack(fill='x', pady=(0, 20))
        
        # Log frame
        self.log_frame.pack(fill='both', expand=True)
        
        # Log text and scrollbar
        self.log_text.pack(side='left', fill='both', expand=True)
        self.log_scrollbar.pack(side='right', fill='y')
        
        # Clear log button
        self.clear_log_button.pack(pady=(10, 0))
        
    def browse_excel_file(self):
        """Browse for Excel file"""
        filename = filedialog.askopenfilename(
            title="Select Excel File",
            filetypes=[("Excel files", "*.xlsm"), ("All files", "*.*")]
        )
        if filename:
            self.excel_path.set(filename)
            self.log_message(f"Excel file selected: {filename}")
    
    def browse_package_path(self):
        """Browse for package path"""
        dirname = filedialog.askdirectory(title="Select Package Directory")
        if dirname:
            self.package_path.set(dirname)
            self.log_message(f"Package path selected: {dirname}")
    
    def browse_project_path(self):
        """Browse for project path"""
        dirname = filedialog.askdirectory(title="Select Project Directory")
        if dirname:
            self.project_path.set(dirname)
            self.log_message(f"Project path selected: {dirname}")
    
    def validate_inputs(self):
        """Validate input paths"""
        if not self.excel_path.get():
            messagebox.showerror("Error", "Please select an Excel file!")
            return False
        
        if not self.package_path.get():
            messagebox.showerror("Error", "Please select a package path!")
            return False
        
        if not self.project_path.get():
            messagebox.showerror("Error", "Please select a project path!")
            return False
        
        if not os.path.exists(self.excel_path.get()):
            messagebox.showerror("Error", "Excel file does not exist!")
            return False
        
        if not os.path.exists(self.package_path.get()):
            messagebox.showerror("Error", "Package path does not exist!")
            return False
        
        if not os.path.exists(self.project_path.get()):
            messagebox.showerror("Error", "Project path does not exist!")
            return False
        
        return True
    
    def start_generation(self):
        """Start the generation process"""
        if not self.validate_inputs():
            return
        
        if self.is_running:
            messagebox.showwarning("Warning", "Generation is already in progress!")
            return
        
        # Run in separate thread to avoid blocking UI
        self.is_running = True
        self.generate_button.configure(state='disabled')
        self.progress_var.set(0)
        self.generate_package()
    
    def generate_package(self):
        """Generate package process"""
        try:
            self.log_message("Starting ECU-TEST package generation...")
            self.log_message(f"Excel file: {self.excel_path.get()}")
            self.log_message(f"Package path: {self.package_path.get()}")
            self.log_message(f"Project path: {self.project_path.get()}")
            self.log_message("-" * 60)

            # Extract data from SIT excel file
            self.log_message("Reading Excel file...")
            self.progress_var.set(10)
            SIT_Data = ExcelPackageExtractor()
            test_steps, expected_results, parameters, ID = SIT_Data.extract_all_data(self.excel_path.get())
            self.log_message("Extract test cases from Excel file completed...")
            self.progress_var.set(30)
            import pprint
            pp = pprint.PrettyPrinter(indent=2)
            print("test_steps =")
            pp.pprint(test_steps)
            print("\nexpected_results =")
            pp.pprint(expected_results)
            print("\nparameters =")
            pp.pprint(parameters)
            print("\nID =")
            pp.pprint(ID)

            #Generate ECU_TEST packages
            self.log_message("Generating package structure...")

            # Loop all the test case in the SIT file
            for idx,id in enumerate(ID):

                # Initialize the package file for generation 
                package = Generate_XML_Package_ECUTEST(test_steps[id],expected_results[id], parameters[id])

                # Create the name of the package file
                name_package = id + '.pkg'
                output_pakages = os.path.join(self.package_path.get(),name_package )

                # Start generate the xml
                package.Gen_package_xml(output_pakages)

                #Update the progress of package generation process
                progress = ((idx + 1) / len(ID) * 50) + 30
                self.progress_var.set(progress)
            
            self.log_message("Generate ECU-TEST packages completed...")

            #Generate ECU_TEST project
            self.log_message("Configuring parameters...")
            project = Generate_XML_Project_ECUTEST(ID, parameters,self.package_path.get())         
            output_project = os.path.join(self.project_path.get(),"Xpeng_Project_AutoGen.prj")
            project.Gen_project_xml( output_file_project = output_project)
            os.startfile(self.project_path.get())
            self.log_message("Generation completed successfully!")
            self.progress_var.set(100)
            self.log_message("=" * 60)
            self.log_message("Package generation completed successfully!")
            # Show completion message
            self.root.after(0, lambda: messagebox.showinfo("Success", 
                                                            "ECU-TEST package generated successfully!"))                
            
        except Exception as e:
            error_msg = str(e)
            self.log_message(f"Error during generation: {error_msg}")
            self.root.after(0, lambda: messagebox.showerror("Error", 
                                                           f"Generation failed: {error_msg}"))
        finally:
            self.is_running = False
            self.root.after(0, lambda: self.generate_button.configure(state='normal'))
    
    def log_message(self, message):
        """Add message to log"""
        timestamp = datetime.datetime.now().strftime("%H:%M:%S")
        log_entry = f"[{timestamp}] {message}\n"
        
        # Update UI from main thread
        self.root.after(0, lambda: self._update_log(log_entry))
    
    def _update_log(self, message):
        """Update log text (runs in main thread)"""
        self.log_text.insert(tk.END, message)
        self.log_text.see(tk.END)
        self.root.update_idletasks()
    
    def clear_log(self):
        """Clear log"""
        self.log_text.delete(1.0, tk.END)
        self.log_message("Log cleared.")

def main():
    root = tk.Tk()
    app = ECUTestGeneratorUI(root)
    root.mainloop()

if __name__ == "__main__":
    main()