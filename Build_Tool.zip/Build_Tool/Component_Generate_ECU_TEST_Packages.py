import tkinter as tk
from tkinter import filedialog, messagebox, ttk

import xml.etree.ElementTree as ET
from xml.dom import minidom
import uuid
import Library_Create_XMLTestJob
from Function_Code_Lib import Func_library
import json
import re
import xml.dom.minidom
import os
import sys
import ast

class Generate_XML_Package_ECUTEST():
    def __init__(self,test_Step:dict, expected_result: dict, parameter: dict):
        self.test_Step = test_Step
        self.expected_result = expected_result
        self.parameters = parameter
        #self.testcase_Name = testcase_Name
        self.MAPPING_JOB_PATH = 'Mapping_Path_Job.json'
        self.MAPPING_TESTJOB_XML = 'Mapping_TestStep_TestJobXML.json'
        self.params_with_step = []
        self.temp_params_mapping = {}
        self.mapping_parent = None
        self.variable_parent = None

        self.Library_XML = Library_Create_XMLTestJob.LibraryManager()
        self.all_Lib_Objects = [self.Library_XML.Com_Lib, self.Library_XML.Diag_Lib,self.Library_XML.EDR_Lib, self.Library_XML.General_Lib]

        self.function_code = Func_library()
        self.mapping_Job_Path = Library_Create_XMLTestJob.ShareBase.mapping_Path_Job_List   

        # Define namespaces
        self.NS = {
        'xsi': 'http://www.w3.org/2001/XMLSchema-instance',
        None: 'http://www.tracetronic.de/xml/ecu-test'}

    def Gen_package_xml(self, output_file):
        """
        Generate ECU-TEST XML from test steps dictionary
        
        Args:
            output_file: Output XML file name
        """
        # Register namespaces
        ET.register_namespace('', self.NS[None])
        ET.register_namespace('xsi', self.NS['xsi'])

        # Create root PACKAGE element
        package = ET.Element('PACKAGE', {
            'format-rev': '7',
            'prog-version': '2024.3.0.156114+c108ea21784a',
            'xmlns': self.NS[None],
            'xmlns:xsi': self.NS['xsi'],
            'xsi:schemaLocation': 'http://www.tracetronic.de/xml/ecu-test package.xsd'
        })

        # Add sections
        self.add_information_section(package)
        self.add_variables_section(package, self.parameters)
        self.add_mapping_section(package)
        self.add_teststeps_section(package)
        self.add_mapping_section_full()
        self.add_temp_variables_section() 

        # Write to file
        tree = ET.ElementTree(package)
        tree.write(output_file, encoding='utf-8', xml_declaration=True)
        self.pretty_print_xml_file(output_file)
        # self.write_formatted_xml(tree, output_file)
        print(f"ECU-TEST XML packge file created: {output_file}")
        return tree

    def add_information_section(self, package):
        """Add INFORMATION section"""
        info = ET.SubElement(package, 'INFORMATION', {'format-rev': '2', 'xsi:type': 'packageInfo'})
        
        # Add TAGS
        tags = ET.SubElement(info, 'TAGS')
        tag = ET.SubElement(tags, 'TAG', {'xsi:type': 'string'})
        tag.text = 'TESTCASE'
        
        # Add other information fields
        for field in ['DESCRIPTION', 'VERSION', 'ALTERNATE-CALL-REPRESENTATION-ACTION-FIELD-TEMPLATE', 
                      'ALTERNATE-CALL-REPRESENTATION-EXPECTATION-FIELD-TEMPLATE']:
            ET.SubElement(info, field, {'xsi:type': 'string'})

    def detect_type(self, value):
        lower_val = value.lower()
        if lower_val == 'true' or lower_val == 'false':
            return bool
        
        try:
            int(value)
            return int
        except ValueError:
            pass

        try:
            float(value)
            return float
        except ValueError:
            pass

        try:
            evaluated = ast.literal_eval(value)
            if isinstance(evaluated, list):
                return list
            elif isinstance(evaluated, dict):
                return dict
            elif isinstance(evaluated, tuple):
                return tuple
            else:
                return str
        except (ValueError, SyntaxError):
            return str
    
    def create_new_format_parameter(self,parameters):
        result = {}

        # Get params from Action
        actions = parameters.get('Action', {})
        for action_step in actions.values():
            result.update(action_step)

        # Get params from Postcondition
        postconditions = parameters.get('Postcondition', {})
        for post_step in postconditions.values():
            result.update(post_step)

        # Get params from Precondition
        preconditions = parameters.get('Precondition', {})
        for pre_step in preconditions.values():
            result.update(pre_step)
        return result
    
    def add_variables_section(self, package, parameters):
        """Add VARIABLES section"""
        new_parameters = {}
        new_parameters = self.create_new_format_parameter(parameters)

        self.variable_parent = ET.SubElement(package, 'VARIABLES', {'xsi:type': 'variableContainer'})
        
        # Add basic variables
        for var_name in new_parameters:
            self.add_string_variable(self.variable_parent, var_name, new_parameters.get(var_name, ''), is_input=True)

    def add_temp_variables_section(self):
        for var_name in self.temp_params_mapping:
            self.add_string_variable(self.variable_parent, var_name, self.temp_params_mapping.get(var_name, ''), is_input=False)
    
    def add_string_variable(self, variables, name, value, is_input=False, description=''):
        """Add a string variable"""
        var_attrs = {'format-rev': '1', 'xsi:type': 'variable'}
        if is_input:
            var_attrs['in'] = 'true'
        
        var_elem = ET.SubElement(variables, 'VARIABLE', var_attrs)
        
        # Name
        name_elem = ET.SubElement(var_elem, 'NAME', {'xsi:type': 'string'})
        name_elem.text = name
        
        # Description
        desc_elem = ET.SubElement(var_elem, 'DESCRIPTION', {'xsi:type': 'string'})
        desc_elem.text = description

        # Default value
        type_var = self.detect_type(value)
        if value == '':
            type_var = 'undefined'
        elif value == 'function':
            type_var = 'function'
            
        # This condition help press type for parameter name must be string in ECU TEST 
        pattern = r"_\d+$"  # matches underscore + digits at the end
        name_check = re.sub(pattern, "", name)
        special_parameter_name = ['Request_ReadDID', 'Response_ReadDID','Request','Response','EDID']
        if name_check in special_parameter_name:
            if name_check == 'EDID' and type_var == list:
                pass
            else:
                type_var = str

        if type_var == int:
            default_value_elem = ET.SubElement(var_elem, 'DEFAULT-VALUE', {'format-rev': '1', 'xsi:type': 'value'})
            ET.SubElement(default_value_elem, 'DATA', {'xsi:type': 'integer'}).text = str(value)
            ET.SubElement(default_value_elem, 'TEXTDATA', {'xsi:type': 'string'}).text = str(value)
        elif type_var == float:
            default_value_elem = ET.SubElement(var_elem, 'DEFAULT-VALUE', {'format-rev': '1', 'xsi:type': 'value'})
            ET.SubElement(default_value_elem, 'DATA', {'xsi:type': 'float'}).text = str(value)
            ET.SubElement(default_value_elem, 'TEXTDATA', {'xsi:type': 'string'}).text = str(value)
        elif type_var == 'function':
            default_value_elem = ET.SubElement(var_elem, 'DEFAULT-VALUE', {'xsi:type': 'function'})
            code_elem = ET.SubElement(default_value_elem, 'CODE', {'xsi:type': 'string'})
            code_elem.text = self.function_code.get_func_code(name)
        elif type_var == str:
            if value.startswith('"') and value.endswith('"'):
                value = value.strip('"')
            default_value = ET.SubElement(var_elem, 'DEFAULT-VALUE', {'format-rev': '1', 'xsi:type': 'value'})
            complex_data = ET.SubElement(default_value, 'COMPLEX-DATA', {'xsi:type': 'I18NItem'})
            multil = ET.SubElement(complex_data, 'MULTILANGDATA')
            elem = ET.SubElement(multil, 'ELEMENT', {'dkey': 'en_US'})
            dval = ET.SubElement(elem, 'DVALUE', {'xsi:type': 'string'})
            dval.text = value
            ET.SubElement(complex_data, 'INITIAL-LANGUAGE', {'xsi:type': 'string'}).text = 'en_US'
        elif type_var == bool:
            default_value_elem = ET.SubElement(var_elem, 'DEFAULT-VALUE', {'xsi:type': 'aBoolean'})
            object_elem = ET.SubElement(default_value_elem, 'OBJECT', {'xsi:type': 'string'})
            object_elem.text = value
        elif type_var == list:
            default_value_elem = ET.SubElement(var_elem, 'DEFAULT-VALUE', {'xsi:type': 'pyObject'})
            object_elem = ET.SubElement(default_value_elem, 'OBJECT', {'xsi:type': 'string'})
            object_elem.text = value
        elif type_var == 'undefined':
            ET.SubElement(var_elem, 'DEFAULT-VALUE', {'xsi:type': 'undefined'}) 

    def get_resource_path(self,relative_path):
        """
        Get absolute path to resource, works for dev and for PyInstaller
        """
        try:
            # PyInstaller creates a temp folder and stores path in _MEIPASS
            base_path = sys._MEIPASS
        except Exception:
            # Normal Python execution
            base_path = os.path.abspath(".")
        
        return os.path.join(base_path, relative_path)

    def get_job_path(self, needed_job:list):
        json_path = self.get_resource_path(self.MAPPING_JOB_PATH)
        with open(json_path, 'r', encoding='utf-8') as f:
            mappings = json.load(f)

        # Extract only the needed paths
        selected_mappings = {key: mappings[key] for key in needed_job if key in mappings}
        return selected_mappings

    def add_mapping_section(self, package):
        """Add MAPPING section"""
        self.mapping_parent = ET.SubElement(package, 'MAPPING', {'format-rev': '1', 'xsi:type': 'localMappingSpace'})
        
        mappings = self.get_job_path(['GEN_PrepareNoFault'])
        
        for id_, path in mappings.items():
            item = ET.SubElement(self.mapping_parent, 'MAPPING-ITEM', {'format-rev': '2', 'xsi:type': 'mappingItem'})
            ET.SubElement(item, 'ID', {'xsi:type': 'string'}).text = id_
            xacc = ET.SubElement(item, 'XACCESS', {'xsi:type': 'xaPackage'})
            ET.SubElement(xacc, 'PATH', {'xsi:type': 'string'}).text = path

    def add_mapping_section_full(self):
        """Add MAPPING section full after have list path of job"""        

        mappings = self.get_job_path(self.mapping_Job_Path)
        
        for id_, path in mappings.items():
            item = ET.SubElement(self.mapping_parent, 'MAPPING-ITEM', {'format-rev': '2', 'xsi:type': 'mappingItem'})
            ET.SubElement(item, 'ID', {'xsi:type': 'string'}).text = id_
            xacc = ET.SubElement(item, 'XACCESS', {'xsi:type': 'xaPackage'})
            ET.SubElement(xacc, 'PATH', {'xsi:type': 'string'}).text = path

    def add_teststeps_section(self, package):
        """Add TESTSTEPS section"""
        teststeps = ET.SubElement(package, 'TESTSTEPS', {'xsi:type': 'testCase'})
        
        # Add Precondition
        precond_data = self.test_Step.get('Precondition', {})
        if precond_data:
            self.add_precondition_block(teststeps, precond_data)
        else:
            self.add_precondition_empty(teststeps)
        
        # Add Action steps
        action_data = self.test_Step.get('Action', {})
        if action_data:
            self.add_action_block(teststeps, action_data)
        
        # Add Postcondition
        postcond_data = self.test_Step.get('Postcondition', {})
        if postcond_data:
            self.add_postcondition_block(teststeps, postcond_data)
        else:
            self.add_postcondition_empty(teststeps)

    def add_precondition_empty(self,parent):
        ts_precond = ET.SubElement(parent, 'TESTSTEP', {
        "format-rev": "3",
        "id": '515',
        "name": "TsPrecondBlock",
        "xsi:type": "utility-fd32d18b-c16d-45ca-9934-f8bffe11fcc3"
        })

        action = ET.SubElement(ts_precond, "ACTION", {"xsi:type": "I18NItem"})
        multilanguage = ET.SubElement(action, "MULTILANGDATA")
        ET.SubElement(multilanguage, "ELEMENT", {"dkey": "de_DE"}).append(
            ET.Element("DVALUE", {"xsi:type": "string"}, text="Precondition")
        )
        ET.SubElement(multilanguage, "ELEMENT", {"dkey": "en_US"}).append(
            ET.Element("DVALUE", {"xsi:type": "string"}, text="Precondition")
        )
        ET.SubElement(action, "INITIAL-LANGUAGE", {"xsi:type": "string"}).text = "de_DE"

    def add_postcondition_empty(self,parent):
        ts_postcond = ET.SubElement(parent, 'TESTSTEP', {
        "format-rev": "2",
        "id": "517",
        "name": 'TsPostcondBlock',
        "xsi:type": "utility-0d2ac4dc-1d8f-4182-81d1-a5d5ca74a44f"
        })

        action = ET.SubElement(ts_postcond, "ACTION", {"xsi:type": "I18NItem"})
        multilang = ET.SubElement(action, "MULTILANGDATA")

        for lang in ["de_DE", "en_US"]:
            element = ET.SubElement(multilang, "ELEMENT", {"dkey": lang})
            dvalue = ET.SubElement(element, "DVALUE", {"xsi:type": "string"})
            dvalue.text = "Postcondition"

        ET.SubElement(action, "INITIAL-LANGUAGE", {"xsi:type": "string"}).text = "de_DE"
        ET.SubElement(ts_postcond, "EFFECT-TEST-RESULT", {"xsi:type": "boolean"}).text = "False"

    def add_precondition_block(self, teststeps,pre_data):
        """Add precondition test step block"""
        ts_precond = ET.SubElement(teststeps, 'TESTSTEP', {
            'format-rev': '3', 'id': str(uuid.uuid4()), 'name': 'TsPrecondBlock',
            'xsi:type': 'utility-fd32d18b-c16d-45ca-9934-f8bffe11fcc3'
        })
        
        self.add_action_element(ts_precond, 'Precondition')
        self.params_with_step = self.extract_params_dict(self.parameters['Precondition'])
        
        # Process each action step
        for step_num, step_desc in pre_data.items():
            self.add_test_step_element(ts_precond, step_desc,step_num)

    def add_postcondition_block(self, teststeps,pos_data):
        """Add postcondition test step block"""
        ts_postcond = ET.SubElement(teststeps, 'TESTSTEP', {
            'format-rev': '2', 'id': str(uuid.uuid4()), 'name': 'TsPostcondBlock',
            'xsi:type': 'utility-0d2ac4dc-1d8f-4182-81d1-a5d5ca74a44f'
        })
        
        self.add_action_element(ts_postcond, 'Postcondition')
        if pos_data:
            self.params_with_step = self.extract_params_dict(self.parameters['Postcondition'])
            # Process each action step
            for step_num, step_desc in pos_data.items():
                self.add_test_step_element(ts_postcond, step_desc,step_num)
        else:
            ET.SubElement(ts_postcond, 'EFFECT-TEST-RESULT', {'xsi:type': 'boolean'}).text = 'False'

    def extract_variables(self,text):
        return re.findall(r'{(\w+)}', text)
    
    def extract_params_dict(self,params_dict):
        if params_dict:
            # Determine the max index (int(key) - 1)
            max_index = max(int(k.split(".")[-1]) for k in params_dict.keys()) - 1

            # Initialize result list with empty lists
            params_list = [[] for _ in range(max_index + 1)]

            # Fill it using (int(key) - 1) as index
            for k, v in params_dict.items():
                index = int(k) - 1
                params_list[index] = list(v.keys())
            return params_list

    def add_action_block(self, teststeps, action_data):
        """Add action test step block"""
        ts_action = ET.SubElement(teststeps, 'TESTSTEP', {
            'format-rev': '3', 'id': str(uuid.uuid4()), 'name': 'TsBlock',
            'xsi:type': 'utility-2752ad1e-4fef-11dc-81d4-0013728784ee'
        })
        
        self.add_action_element(ts_action, 'Action')
        self.params_with_step = self.extract_params_dict(self.parameters['Action'])

        # Process each action step
        for step_num, step_desc in action_data.items():
            self.add_test_step_element(ts_action, step_desc,step_num)

    def add_test_step_element(self, parent, step_desc,step_num):
        """Add action test step"""
        step_block = ET.SubElement(parent, 'TESTSTEP', {
            'format-rev': '3', 'id': str(uuid.uuid4()), 'name': 'TsBlock',
            'xsi:type': 'utility-2752ad1e-4fef-11dc-81d4-0013728784ee'
        })
        
        self.add_action_element(step_block, step_desc)
        self.add_testjob_xml_mapping(step_block,step_desc,step_num)

    def add_testjob_xml_mapping(self,parent,test_step,step_num):
        testjob_mapping = self.load_testjob_mapping(self.MAPPING_TESTJOB_XML)
        self.execute_genxml_test_step(test_step, parent,testjob_mapping,step_num)

    def load_testjob_mapping(self,filename="Mapping_TestStep_TestJobXML.json"):
        json_path = self.get_resource_path(filename)
        with open(json_path, 'r', encoding='utf-8') as f:
            return json.load(f)
        
    def generate_regex(self,template):
        regex = re.escape(template)
        regex = re.sub(r'\\{(\w+)\\}', r'(?P<\1>.+)', regex)
        return f"^{regex}$"
    
    def find_method_in_objects(self,objects, func_name):
        for obj in objects:
            method = getattr(obj, func_name, None)
            if callable(method):
                return method, obj
        return None, None
    
    def normalize_step_text(self,step_text):
        step_text = re.sub(r'\[.*?\]', '', step_text)
        step_text = re.sub(r'\{.*?\}', '', step_text)
        return re.sub(r'^\d+\.\s*', '', step_text).strip()  
    
    def is_step_match(self, str1, str2):
        words1 = str1.split()
        words2 = str2.split()
        return words1 == words2

    def execute_genxml_test_step(self, step_text, parent, mappings,step_num):
        normalized = self.normalize_step_text(step_text)
        params = self.params_with_step[int(step_num)-1]
        for mapping in mappings:
            test_step = mapping['testStep']
            regex = self.normalize_step_text(test_step)
            # regex = self.generate_regex(test_step)
            match = self.is_step_match(regex, normalized)
            first_idx = 0
            second_idx = 0
            if match:
                for func in mapping['functions']:
                    func_name = func['name']
                    self.temp_params_mapping.update(func['paramsTemporary'])
                
                    method, owner = self.find_method_in_objects(self.all_Lib_Objects, func_name)
                    if method:
                        # Get the corresponding arguments with the function 
                        num_args = method.__code__.co_argcount -1  # -1 for argument self
                        first_idx = second_idx
                        second_idx = num_args + first_idx -1 # -1 for argument parent
                        method(parent, *params[first_idx:second_idx])
                    else:
                        print(f"Method {func_name} not found")
                return True  # Successfully matched and executed

        print(f"No mapping matched for: {step_text}")
        return False

    def add_action_element(self, parent, text):
        """Add action element with multilanguage support"""
        action = ET.SubElement(parent, 'ACTION', {'xsi:type': 'I18NItem'})
        multil = ET.SubElement(action, 'MULTILANGDATA')
        
        elem = ET.SubElement(multil, 'ELEMENT', {'dkey': 'en_US'})
        dval = ET.SubElement(elem, 'DVALUE', {'xsi:type': 'string'})
        dval.text = text
        
        ET.SubElement(action, 'INITIAL-LANGUAGE', {'xsi:type': 'string'}).text = 'de_DE'

    def write_formatted_xml(self, tree, filename):
        """Write XML with proper formatting"""
        rough_string = ET.tostring(tree.getroot(), 'utf-8')
        reparsed = minidom.parseString(rough_string)
        xml_str = reparsed.toprettyxml(indent="  ", encoding=None)
        xml_str = '<?xml version="1.0" encoding="utf-8"?>\n' + '\n'.join(xml_str.split('\n')[1:])
        
        json_path = self.get_resource_path(filename)
        with open(json_path, 'w', encoding='utf-8') as f:
            f.write(xml_str)

    def pretty_print_xml_file(self,filename):
        # Read the raw XML
        xml_path = self.get_resource_path(filename)
        with open(xml_path, 'r', encoding='utf-8') as f:
            xml_str = f.read()
        # Parse and pretty print
        dom = xml.dom.minidom.parseString(xml_str)
        pretty_xml_as_str = dom.toprettyxml(indent="    ")  # 4 spaces
        # Remove blank lines
        pretty_xml_as_str = '\n'.join([line for line in pretty_xml_as_str.split('\n') if line.strip()])
        
        # Remove the default XML declaration (first line)
        lines = pretty_xml_as_str.split('\n')
        if lines[0].startswith('<?xml'):
            lines = lines[1:]

        # Add your own XML declaration with encoding
        xml_declaration = '<?xml version="1.0" encoding="utf-8"?>'
        pretty_xml_as_str = xml_declaration + '\n' + '\n'.join(lines)

        # Overwrite the file
        xml_path = self.get_resource_path(filename)
        with open(xml_path, 'w', encoding='utf-8') as f:
            f.write(pretty_xml_as_str)
