import tkinter as tk
from tkinter import filedialog, messagebox, ttk

import xml.etree.ElementTree as ET
from xml.dom import minidom
import uuid
import Library_Create_XMLTestJob
from Function_Code_Lib import Func_library
import json
import re
import xml.dom.minidom
import os
import sys
import ast

class Generate_XML_Project_ECUTEST():
    def __init__(self,ID,parameter,path_packages):
        self.IDs = ID
        self.parameter = parameter
        self.PATH_OF_PACKAGE = path_packages+'/'
        self.NS = {
            'xsi': 'http://www.w3.org/2001/XMLSchema-instance'    
        }
    
    def Gen_project_xml(self, subproject_name = 'Testcases', output_file_project ="Xpeng_DSM_Automation.prj"):
        """
        Generate ECU-TEST XML from test steps dictionary
        
        Args:
            output_file: Output XML file project name
        """
        # Register namespaces
        ET.register_namespace('xsi', self.NS['xsi'])

        # Create root PROJECT element
        project = ET.Element('PROJECT', {
            'format-rev': '11',
            'xmlns:xsi': self.NS['xsi']
        })

        ET.SubElement(project, 'NAME', {'xsi:type': 'string'}).text = 'Project'
        ET.SubElement(project, 'ENABLED', {'xsi:type': 'boolean'}).text = 'True'
        ET.SubElement(project, 'REPORTING', {'xsi:type': 'boolean'}).text = 'True'
        ET.SubElement(project, 'ID', {'xsi:type': 'string'}).text = self._generate_id()

        components_root = ET.SubElement(project, 'COMPONENTS')
        subproject = self._create_subproject(subproject_name, self.IDs)
        components_root.append(subproject)

        tree = ET.ElementTree(project)
        tree.write(output_file_project, encoding='utf-8', xml_declaration=True)
        self.pretty_print_xml_file(output_file_project)
        print(f"ECU-TEST XML prject file created: {output_file_project}")

    def get_resource_path(self,relative_path):
        """
        Get absolute path to resource, works for dev and for PyInstaller
        """
        try:
            # PyInstaller creates a temp folder and stores path in _MEIPASS
            base_path = sys._MEIPASS
        except Exception:
            # Normal Python execution
            base_path = os.path.abspath(".")
        
        return os.path.join(base_path, relative_path)
    
    def extract_params(self,parameters):
        result = {}

        # Get params from Action
        actions = parameters.get('Action', {})
        for action_step in actions.values():
            result.update(action_step)

        # Get params from Postcondition
        postconditions = parameters.get('Postcondition', {})
        for post_step in postconditions.values():
            result.update(post_step)

        # Get params from Precondition
        preconditions = parameters.get('Precondition', {})
        for pre_step in preconditions.values():
            result.update(pre_step)
        return result
    
    def _create_subproject(self, subproject_name, IDs):
        subproject = ET.Element('COMPONENT', {'format-rev': '11', 'xsi:type': 'subproject'})
        ET.SubElement(subproject, 'NAME', {'xsi:type': 'string'}).text = subproject_name
        ET.SubElement(subproject, 'ENABLED', {'xsi:type': 'boolean'}).text = 'True'
        ET.SubElement(subproject, 'REPORTING', {'xsi:type': 'boolean'}).text = 'True'
        ET.SubElement(subproject, 'ID', {'xsi:type': 'string'}).text = self._generate_id()

        components_elem = ET.SubElement(subproject, 'COMPONENTS')
        for pkg in IDs:
            components_elem.append(self._create_package_component(pkg))

        return subproject

    def _create_package_component(self, pkg):
        pkg_component = ET.Element('COMPONENT', {'format-rev': '6', 'xsi:type': 'packageTest'})
        ET.SubElement(pkg_component, 'NAME', {'xsi:type': 'string'}).text = pkg
        ET.SubElement(pkg_component, 'ENABLED', {'xsi:type': 'boolean'}).text = 'True'
        ET.SubElement(pkg_component, 'REPORTING', {'xsi:type': 'boolean'}).text = 'True'
        ET.SubElement(pkg_component, 'ID', {'xsi:type': 'string'}).text = self._generate_id()

        # Add param record
        pkg_components_sub = ET.SubElement(pkg_component, 'COMPONENTS')
        pkg_components_sub.append(self._create_param_record(pkg,self.parameter[pkg]))

        # Add PACKAGE-REF
        pkg_ref = ET.SubElement(pkg_component, 'PACKAGE-REF', {'xsi:type': 'expressionref'})
        path_expr = ET.SubElement(pkg_ref, 'PATH-EXPRESSION', {'format-rev': '2', 'xsi:type': 'valueBaseExpression'})
        
        path_pkg = self.PATH_OF_PACKAGE + pkg+'.pkg'
        ET.SubElement(path_expr, 'VALUE', {'xsi:type': 'string'}).text = path_pkg

        return pkg_component

    def detect_type(self, value):
        lower_val = value.lower()
        if lower_val == 'true' or lower_val == 'false':
            return bool
        
        try:
            int(value)
            return int
        except ValueError:
            pass

        try:
            float(value)
            return float
        except ValueError:
            pass

        try:
            evaluated = ast.literal_eval(value)
            if isinstance(evaluated, list):
                return list
            elif isinstance(evaluated, dict):
                return dict
            elif isinstance(evaluated, tuple):
                return tuple
            else:
                return str
        except (ValueError, SyntaxError):
            return str

    def _create_param_record(self, pkg,parameters):
        
        param_record = ET.Element('COMPONENT', {'format-rev': '4', 'xsi:type': 'paramRecord'})
        ET.SubElement(param_record, 'NAME', {'xsi:type': 'string'}).text = pkg
        ET.SubElement(param_record, 'ENABLED', {'xsi:type': 'boolean'}).text = 'True'
        ET.SubElement(param_record, 'REPORTING', {'xsi:type': 'boolean'}).text = 'True'
        ET.SubElement(param_record, 'ID', {'xsi:type': 'string'}).text = self._generate_id()

        param_data = ET.SubElement(param_record, 'PARAMETER-DATA', {'xsi:type': 'packageParameterData'})
        
        parameters = self.extract_params(parameters)
        for name, value in parameters.items():

            param = ET.SubElement(param_data, 'PARAMETER', {'xsi:type': 'parameterEntry'})
            ET.SubElement(param, 'NAME', {'xsi:type': 'string'}).text = name

            type_var = self.detect_type(value)

            # This condition help press type for parameter name must be string in ECU TEST 
            pattern = r"_\d+$"  # matches underscore + digits at the end
            name_check = re.sub(pattern, "", name)
            special_parameter_name = ['Request_ReadDID', 'Response_ReadDID','Request','Response','EDID']
            if name_check in special_parameter_name:      
                if name_check == 'EDID' and type_var == list:
                    pass
                else:
                    type_var = str
            if type_var == int:
                val_expr = ET.SubElement(param, 'VALUE', {'format-rev': '2', 'xsi:type': 'valueBaseExpression'})
                ET.SubElement(val_expr, 'VALUE', {'xsi:type': 'integer'}).text = value
            elif type_var == float:
                val_expr = ET.SubElement(param, 'VALUE', {'format-rev': '2', 'xsi:type': 'valueBaseExpression'})
                ET.SubElement(val_expr, 'VALUE', {'xsi:type': 'float'}).text = value
            elif type_var == str:
                if value.startswith('"') and value.endswith('"'):
                    value = value.strip('"')
                val_expr = ET.SubElement(param, 'VALUE', {'format-rev': '2', 'xsi:type': 'valueBaseExpression'})
                ET.SubElement(val_expr, 'VALUE', {'xsi:type': 'string'}).text = value
            elif type_var == bool:
                val_expr = ET.SubElement(param, 'VALUE', {'format-rev': '2', 'xsi:type': 'valueBaseExpression'})
                ET.SubElement(val_expr, 'VALUE', {'xsi:type': 'boolean'}).text = value
            elif type_var == list:
                value_elem = ET.SubElement(param,'VALUE', {'xsi:type': 'listOrTupleBaseExpression'})

                ET.SubElement(value_elem, 'IS-LIST', {'xsi:type': 'boolean'}).text = 'True'
                expr_list_elem = ET.SubElement(value_elem, 'EXPRESSION-LIST')

                for num in ast.literal_eval(value):
                    if isinstance(num, list):
                        base_expr = ET.SubElement(expr_list_elem, 'BASE-EXPRESSION', {'xsi:type': 'listOrTupleBaseExpression'})
                        ET.SubElement(base_expr, 'IS-LIST', {'xsi:type': 'boolean'}).text = 'True'

                        expr_list_elem = ET.SubElement(base_expr, 'EXPRESSION-LIST')

                        for child_num in num: 
                            base_expr = ET.SubElement(expr_list_elem, 'BASE-EXPRESSION', {
                                'format-rev': '2',
                                'xsi:type': 'valueBaseExpression'
                            })
                            if isinstance(child_num, int):
                                ET.SubElement(base_expr, 'VALUE', {'xsi:type': 'integer'}).text = str(child_num)
                            elif isinstance(child_num, str):
                                ET.SubElement(base_expr, 'VALUE', {'xsi:type': 'string'}).text = str(child_num)
                    else:
                        base_expr = ET.SubElement(expr_list_elem, 'BASE-EXPRESSION', {
                            'format-rev': '2',
                            'xsi:type': 'valueBaseExpression'
                        })
                        if isinstance(num, int):
                            ET.SubElement(base_expr, 'VALUE', {'xsi:type': 'integer'}).text = str(num)
                        elif isinstance(num, str):
                            ET.SubElement(base_expr, 'VALUE', {'xsi:type': 'string'}).text = str(num)
                    

            else:
                val_expr = ET.SubElement(param, 'VALUE', {'format-rev': '2', 'xsi:type': 'valueBaseExpression'})
                ET.SubElement(val_expr, 'VALUE', {'xsi:type': 'string'}).text = value

        ET.SubElement(param_record, 'TM-INFO', {'format-rev': '1', 'xsi:type': 'testManagementInfo'})
        return param_record

    def _generate_id(self):
        return uuid.uuid4().hex
    
    def pretty_print_xml_file(self,filename):
        # Read the raw XML
        xml_path = self.get_resource_path(filename)
        with open(xml_path, 'r', encoding='utf-8') as f:
            xml_str = f.read()

        # Parse and pretty print
        dom = xml.dom.minidom.parseString(xml_str)
        pretty_xml_as_str = dom.toprettyxml(indent="    ")  # 4 spaces
        # Remove blank lines
        pretty_xml_as_str = '\n'.join([line for line in pretty_xml_as_str.split('\n') if line.strip()])
        
        # Remove the default XML declaration (first line)
        lines = pretty_xml_as_str.split('\n')
        if lines[0].startswith('<?xml'):
            lines = lines[1:]

        # Add your own XML declaration with encoding
        xml_declaration = '<?xml version="1.0" encoding="utf-8"?>'
        pretty_xml_as_str = xml_declaration + '\n' + '\n'.join(lines)

        # Overwrite the file
        xml_path = self.get_resource_path(filename)
        with open(xml_path, 'w', encoding='utf-8') as f:
            f.write(pretty_xml_as_str)
